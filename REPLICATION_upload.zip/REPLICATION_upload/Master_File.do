***************************Master File Liquidity Lines**************************

/* 

This code is the master file for the paper "The Global Network of Liquidity Lines" 
Saleem Bahaj, Ricardo Reis, Marie Fuchs. 


13/01/2025 initial replication version 
25/12/2025 update new network December 2025
05/03/2026 removed extra outputs for JIE final submission

*/

************************************************************************

*   STEPS:

*   STEP 1: Prepare Environment

*   STEP 2: Generate Adjacency Vectors and Ceilings

*   STEP 3: Generate Panel of Liquidity Line Caps

*   STEP 4: Solve Shortest Path Problem (MATLAB)

*   STEP 5: Solve Centrality Problem (MATLAB)

*   STEP 6: Coverage Graphs      - Paper Sections 3.1-3.3, 5.1, 6.2

*   STEP 7: Centrality Graphs    - Paper Section 5.2 (and appendix centrality figures)

*   STEP 8: Map Graphs           - Paper Sections 3.4 and 5.1

*   STEP 9: Reserve Analysis     - Paper Sections 7.1-7.3

*   STEP 10: CIP Analysis        - Paper Section 6

*   STEP 11: CIP Event Study     - Paper Section 7.4


********************************************************************************

* REQUIREMENTS:

* NB: Running this code requries the following software: 
		* STATA (written with version SE18.0)
		* MATLAB (written with version R2024a) 
		* R

********************************************************************************


*************************STEP 1: Prepare Environment****************************

/* 
NB: This section installs all necessary packages and sets global paths 

*/

***Set up baseline environment
set more off
set seed 1111

***Set filepath
***File Path Home Workstation (Windows)
global root="/Users/..."
cd $root


***SETUP STATA
***PACKAGES - GENERAL:
ssc install distinct
ssc install carryforward

net install mdqr, 			from("https://raw.githubusercontent.com/bmelly/Stata/main/")
ssc install winsor
net install colorscheme, 	from("https://raw.githubusercontent.com/matthieugomez/colorscheme/master/")
ssc install reghdfe
net install qrprocess, 		from("https://raw.githubusercontent.com/bmelly/Stata/main/")
ssc install moremata 
net install parallel, 		from("https://raw.github.com/gvegayon/parallel/stable/")

***SETUP MATLAB
***Check path existence
!ls -l "/Applications/MATLAB_R2025b.app/bin/matlab"
***Set global matlab path
global MATLAB "/Applications/MATLAB_R2025b.app/bin/matlab"


***SETUP R
***Set R binary
global R_BIN "/usr/local/bin/Rscript"

!"$R_BIN" --version
!"$R_BIN" -e "cat('Rscript OK\n')"


***Set current network
global 	liqlines "$root/Data/liquidity_lines.xlsx"

***Import network
global 	liqlines "$root/Data/liquidity_lines.xlsx"
import 	excel "$liqlines", sheet("LiquidityLines") firstrow clear

***Set up folder structure
capture mkdir "Data/Interim"
capture mkdir "Data/Interim/dates"
capture mkdir "Output/figures"
capture mkdir "Output/figures/eventstudies"
capture mkdir "Output/tables"
capture mkdir "Output/temp"
capture mkdir "Output/temp/ecdf"
capture mkdir "Output/temp/qreg"


**************** STEP 2: Generate Adjacency Vectors and Ceilings ***************

/*
NB: This script constructs the baseline network inputs used in later Stata and MATLAB steps.
It:
    - creates country-code mappings,
    - builds a cleaned liquidity-lines panel,
    - generates monthly adjacency vectors,
    - computes and exports ceiling measures for MATLAB.
*/

run Code/stata/generate_baseline.do



**************** STEP 3: Generate caps *****************************************

/* 
NB: This code generates cap-based inputs for the replication. We proceed as follows:
    - compute cap measures for all liquidity lines
    - construct cap variables used in downstream analysis
    - produce summary statistics by cap size
*/


run Code/stata/generate_caps.do


**************** STEP 4: Shortest Path Problem *********************************

/* 
NB: This section solves the monthly shortest-path problem in MATLAB and
builds the Stata path datasets used downstream.

We proceed as follows:
    - run monthly_shortestpath.m for each target central bank (EA, USA, CHN)
      under bilateral and full-network settings
    - import MATLAB outputs (monthly_full_data_*.xlsx)
    - compile bilateral path measures into Paths_bilateral.dta
    - compile full-network path measures into Paths_all.dta
    - merge both and country identifiers to create Paths.dta
*/

***Run Matlab Code
***Setup on MAC
global MATLAB "/Applications/MATLAB_R2025b.app/bin/matlab"

foreach b in yes no {
    foreach t in EA USA CHN {
        di as txt "Running monthly_shortestpath: bilateral=`b', target=`t'"
        !"$MATLAB" -r "cd('$root/Code'); addpath('$root/Code/matlab'); bilateral='`b''; target_country_str='`t''; monthly_shortestpath; exit"
    }
}


******
***Combine bilateral distance results 
******

import excel "Data/Interim/monthly_full_data_yes_USA_reduced.xlsx", firstrow clear
keep country_ID Year Month dist* ceiling*
save Data/Interim/USA_paths.dta, replace

import excel "Data/Interim/monthly_full_data_yes_EA_reduced.xlsx", firstrow clear
keep country_ID Year Month dist* ceiling*
save Data/Interim/EA_paths.dta, replace

import excel "Data/Interim/monthly_full_data_yes_CHN_reduced.xlsx", firstrow clear
keep country_ID Year Month dist* ceiling*
save Data/Interim/CHN_paths.dta, replace

merge 1:1 country_ID Year Month using Data/Interim/USA_paths.dta
drop _merge
merge 1:1 country_ID Year Month using Data/Interim/EA_paths.dta
drop _merge

rename dist_CHN dist_CHN_bilateral
rename dist_EA dist_EA_bilateral
rename dist_USA dist_USA_bilateral
rename ceiling_CHN ceiling_CHN_bilateral
rename ceiling_EA ceiling_EA_bilateral
rename ceiling_USA ceiling_USA_bilateral

compress
save Data/Interim/Paths_bilateral.dta, replace

******
***Combine all distance results 
******

import excel "Data/Interim/monthly_full_data_no_USA_reduced.xlsx", firstrow clear
keep country_ID Year Month dist* ceiling*
save Data/Interim/USA_paths.dta, replace

import excel "Data/Interim/monthly_full_data_no_EA_reduced.xlsx", firstrow clear
keep country_ID Year Month dist* ceiling*
save Data/Interim/EA_paths.dta, replace

import excel "Data/Interim/monthly_full_data_no_CHN_reduced.xlsx", firstrow clear
keep country_ID Year Month dist* ceiling*
save Data/Interim/CHN_paths.dta, replace

merge 1:1 country_ID Year Month using Data/Interim/USA_paths.dta
drop _merge
merge 1:1 country_ID Year Month using Data/Interim/EA_paths.dta
drop _merge

rename dist_CHN dist_CHN_all
rename dist_EA dist_EA_all
rename dist_USA dist_USA_all
rename ceiling_CHN ceiling_CHN_all
rename ceiling_EA ceiling_EA_all
rename ceiling_USA ceiling_USA_all

compress
save Data/Interim/Paths_all.dta, replace

merge 1:1 Year Month country_ID using Data/Interim/Paths_bilateral.dta
drop _merge

merge m:1 country_ID using Data/Interim/country_codes_ordered.dta
drop _merge

save Data/Interim/Paths.dta, replace



**************** STEP 5: Solve Centrality Problem MATLAB ***********************

/* 
NB: This section computes centrality and intermediation measures in MATLAB.

We proceed as follows:
    - run centrality_intermediation.m for EA, USA, and CHN in the bilateral network
    - run centrality_allpaths.m to compute all-path measures (baseline)
    - construct the low-cap exclusion list (cap_pct <= 0.5)
    - rerun centrality_intermediation_cap.m for EA, USA, and CHN
    - rerun centrality_allpaths_cap.m with low-cap lines excluded

These outputs are later used in the centrality graphing and appendix analyses.
*/

***Run Matlab Code
***Run centrality_intermediation for all three
foreach t in EA USA CHN {
    !"$MATLAB" -r "cd('$root/Code'); addpath('$root/Code/matlab'); bilateral='yes'; target_country_str='`t''; centrality_intermediation; exit"
}

***Run all paths without small cap lines
!"$MATLAB" -r "cd('$root/Code'); addpath('$root/Code/matlab'); bilateral='yes'; target_country_str='USA'; centrality_allpaths; exit"


**********
***Run with dropping cap < .5 lines
**********

***NB: For generating data underlying Appendix figure B.4

use Data/Interim/cap_data.dta, replace
***For MATLAB: save very small deals 
keep if cap_pct <= .5 & !mi(cap_pct)
keep deal_ID
save Data/Interim/cap_dealID.dta, replace
export delimited Data/Interim/cap_dealID.csv, replace

***Run Matlab Code
foreach t in EA USA CHN {
    !"$MATLAB" -r "cd('$root/Code'); addpath('$root/Code/matlab'); bilateral='yes'; target_country_str='`t''; centrality_intermediation_cap; exit"
}

!"$MATLAB" -r "cd('$root/Code'); addpath('$root/Code/matlab'); bilateral='yes'; target_country_str='USA'; centrality_allpaths_cap; exit"



**************** STEP 6: Coverage Graphs ***************************************

/* 
NB: This code generates baseline coverage graphs for liquidity lines, including:

    - coverage by number of lines and share of world GDP (Sections 3.1–3.3)
    - GDP coverage by connection degree in the bilateral network (Section 5.1)
    - scatter plots of connection degree against implied ceilings (Section 6.2)

Additional outputs are used in appendix figures.
*/

run Code/stata/coverage_graphs.do


**************** STEP 7: Centrality Graphs *************************************



/* 
NB: This code generates centrality graphs used in Sections 5.1 and 5.2, including:

    - average path length under leave-one-out exercises
    - number/GDP share of connected countries under leave-one-out exercises
    - intermediation measures (shortest paths facilitated)
    - betweenness measures

Additional variants (unweighted and cap-adjusted) are used in appendix figures.
*/


run Code/stata/centrality_graphs.do

*Same code but for subnetwork without small cap lines
run Code/stata/centrality_graphs_cap.do

**************** STEP 8: Map Graphs ********************************************


/* 
NB: This code generates the map figures used in the paper. It:

    - plots line-based network maps in `plot_linemap.R`
    - plots area/coverage maps in `plot_areamap.R`
    - exports map outputs to the `Output` figure folders used by the manuscript

Note: This step calls R scripts from Stata via shell commands, so `Rscript` must be available in your system PATH.

*/


***Plot worldmap with lines
!"$R_BIN" "$root/Code/r/plot_linemap.R" "$root/Code"

***Plot worldmap with area shading
!"$R_BIN" "$root/Code/r/plot_areamap.R" "$root/Code"



**************** STEP 9: Reserve Analysis *************************************

/* 
NB: This code runs the reserve analysis for Section 7. It:

    - prepares and cleans the monthly reserves panel
    - constructs liquidity-line action and distance-change event indicators
    - standardizes reserve measures and builds the event-study working file
    - estimates stacked event-study specifications around network-improvement events
    - exports reserve event-study figures and regression tables

*/


run Code/stata/reserve_analysis.do 


**************** STEP 10: CIP Analysis *****************************************

/* 
NB: This code runs the CIP analysis for Section 6. It:

    - prepares the CIP panel by merging CIP deviations with network-distance measures
    - generates empirical CDF figures that compare CIP tails by connection degree
    - estimates baseline quantile/LPM CIP specifications
    - runs fixed-effects and controlled CIP specifications with bootstrap inference
    - exports regression tables used in the paper:
        - `CIP_analysis.do` -> Table 1
        - `CIP_FE_analysis.do` -> Table 2

*/


run Code/stata/CIP_analysis.do 

run Code/stata/CIP_FE_analysis.do 


**************** STEP 11: CIP Event Study **************************************

/* 
NB: This code implements the CIP event-study analysis (Section 7.4). It:

    - merges CIP, reserves, and network-distance data into an event-study panel
    - defines network-improvement events using `define_events.do`
    - constructs matched control groups from pre-event macro/financial characteristics (including pre-event CIP)
    - estimates stacked event-study regressions for CIP deviations around event dates
    - exports event-study figures and regression tables to `Output/figures/eventstudies`

*/


run Code/stata/reserve_analysis_cip.do 




*end of do-file 

