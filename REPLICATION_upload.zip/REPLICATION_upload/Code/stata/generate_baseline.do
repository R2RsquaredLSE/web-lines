***************************Generate Adjacency Vectors and Ceilings**************************

/* 

This code builds baseline network inputs for downstream Stata and MATLAB analyses.

We proceed as follows:
	- create country-code mappings (ordered for MATLAB, unordered for adjacency construction)
	- compile a cleaned liquidity-lines panel with line-type flags
	- generate monthly adjacency vectors (bilateral, dual, all, unidirectional) and a stacked panel
	- assign implied ceilings and export MATLAB-ready ceiling inputs

Main outputs:
	- Data/Interim/country_codes_ordered.dta
	- Data/Interim/liquidity_lines_stata.dta
	- Data/Interim/stacked_adjacency_vectors.dta
	- Data/Interim/MATLAB_ceilings.csv


09/01/2025 initial replication version 
25/12/2025 update 

 

*/

************************************************************************

*	STEP 1: Create Country Code Maps

*	STEP 2: Build Clean Liquidity-Lines Panel

*	STEP 3: Generate Monthly Adjacency Vectors and Stacked Panel

*	STEP 4: Assign Ceilings and Export MATLAB Inputs


************************************************************************

set seed 1111

*****************************STEP 1: Create Country Code Maps ************

*******
***Store baseline country IDs for MATLAB problem
*******

***NB: Shorest path problem in MATLAB requires specific country order to run without error for all time periods. Thus, country IDs here are not arbitrary. 


***Import liquidity lines list for country IDs
global liqlines "$root/Data/liquidity_lines.xlsx"
import excel "$liqlines", sheet("List") firstrow clear

***Keep only relevant variables
keep country_code country_ID

***Save country list
save "Data/Interim/country_codes_ordered.dta", replace
clear


*******
***Store baseline country codes for generating adjacency vectors
*******

***Import data 
***NB: current file without links and notes
import excel "$liqlines", sheet("LiquidityLines") firstrow clear

***Create country list
keep ISO_source
duplicates drop

***Add the countries that never act as a source and only recipient to get full ist of countries
foreach j in AFG AND BGR BTN EST HRV LVA MDV MKD MNE NPL POL ROU SMR XKX COL GHA {
insobs 1
replace ISO_source="`j'" if ISO_source==""

}

duplicates drop

***Count unique countries
local q = _N

***Generate country pairs
expand _N
sort ISO_source
gen ISO_recipient=""
forvalues i=1(1)`q'{
	forvalues j=1(1)`q'{
		local k=`i'-1
		local m=1+(`j'-1)*`q'
		replace ISO_recipient=ISO_source[`m'] if _n==`j'+`q'*`k'
	}
}


***Generate numerical ids
***NB: These are different IDs than the one used for the MATLAB problem, here order can be arbitrary
preserve
keep ISO_recipient
duplicates drop
egen country_id=group(ISO_recipient)
rename ISO_recipient country_code
save Data/Interim/country_codes_unordered.dta, replace
restore


***Add codes to recipients
rename ISO_recipient country_code
merge m:1 country_code using Data/Interim/country_codes_unordered.dta
rename country_code ISO_recipient
rename country_id recipient_id
drop _merge

***Add codes to sources
rename ISO_source country_code
merge m:1 country_code using Data/Interim/country_codes_unordered.dta
rename country_code ISO_source
rename country_id source_id
drop if _merge==2
drop _merge

***Generate Country Pairsountry pair
gen country_pair_id=(source_id+5)^2*(recipient_id+5)^2+(source_id+100)*(recipient_id+100)

***Save data
save Data/Interim/base_template.dta, replace



*****************************STEP 2: Build Clean Liquidity-Lines Panel *****

***Import Data
import excel "$liqlines", sheet("LiquidityLines") firstrow clear
drop deal_ID reciprocal_deal

* add codes to recipients
rename ISO_recipient country_code
merge m:1 country_code using Data/Interim/country_codes_unordered.dta
rename country_code ISO_recipient
rename country_id recipient_id
drop if _merge==2
drop _merge

* add codes to sources** some codes here are not matched => correct bec some countries are never source
rename ISO_source country_code
merge m:1 country_code using Data/Interim/country_codes_unordered.dta
rename country_code ISO_source
rename country_id source_id
drop if _merge==2
drop _merge

* add pair id's ** also many not matched => also okay bec pair codes for all possible connections not all actual connenctions
merge m:1 ISO_source ISO_recipient using Data/Interim/base_template.dta
drop if _merge==2
drop _merge

* clean the dates
*generate start_date2=date(start_date,"MDY")
generate start_date2=start_date
format start_date2 %td
drop start_date
rename start_date2 start_date

*generate end_date2=date(end_date,"MDY")
generate end_date2=end_date
format end_date2 %td
drop end_date
rename end_date2 end_date


** line types
gen multilateral=0
replace multilateral=1 if deal_type=="pooled fund"
replace multilateral=1 if initiative == "SAARC"
replace multilateral=1 if initiative == "BRICS_CRA"
replace multilateral=1 if initiative == "CMIM"
replace multilateral=1 if initiative == "ASEAN"
replace multilateral=1 if initiative == "Miyazawa"

gen pooled_fund=0 
replace pooled_fund=1 if deal_type=="pooled fund"

gen unidirectional=0 
replace unidirectional=1 if deal_type=="unidirectional"

gen PBOC_line = 0 
replace PBOC_line = 1 if ISO_source == "CHN"
replace PBOC_line = 1 if ISO_recipient == "CHN"

save Data/Interim/liquidity_lines_stata.dta, replace


*****************************STEP 3: Generate Monthly Adjacency Vectors and Stacked Panel *****


* Adjacency vectors by month:
forvalues yy=2000(1)2025{
	forvalues mm=1(1)12{
		use Data/Interim/liquidity_lines_stata.dta, clear
		drop deal_type currency_of_deal deal_currency_amount  USD_amount unlimited initiative existence_previous_deal deal_action previous_deal note framework collateral	
			
		keep if (year(start_date)<`yy') | (year(start_date)==`yy' & month(start_date)<=`mm')
		keep if (year(end_date)>`yy') | (year(end_date)==`yy' & month(end_date)>=`mm')

		preserve
		keep country_pair_id
		duplicates drop
		save Data/Interim/dates/year`yy'_month`mm'_all.dta, replace
		restore
		
		preserve
		keep country_pair_id multilateral
		duplicates drop
		sort country_pair_id
		by country_pair_id: gen dual = _N == 2 & multilateral[1] == 0 & multilateral[_N] == 1
		keep if dual == 1
		drop dual multilateral 
		if _N > 0 {
			duplicates drop
		}
		save Data/Interim/dates/year`yy'_month`mm'_dual.dta, replace
		restore
		
		drop if multilateral==1
		preserve
		keep country_pair_id
		duplicates drop
		save Data/Interim/dates/year`yy'_month`mm'.dta, replace
		restore

		drop if unidirectional == 0
		keep country_pair_id
		duplicates drop
		save Data/Interim/dates/year`yy'_month`mm'_unidi.dta, replace
		
	}
}

** building matrix for active lines
* Matrix of adjacency vectors 
* just bilateral

use Data/Interim/base_template.dta, replace
forvalues yy=2000(1)2025{
	forvalues mm=1(1)12{
		merge m:1 country_pair_id using Data/Interim/dates/year`yy'_month`mm'.dta
		gen year_`yy'_month_`mm'=0
		replace year_`yy'_month_`mm'=1 if _merge==3
		drop _merge
	}
}
*
save Data/Interim/adjacency_vectors.dta, replace

* just dual
use Data/Interim/base_template.dta, replace
forvalues yy=2000(1)2025{
	forvalues mm=1(1)12{
		merge m:1 country_pair_id using Data/Interim/dates/year`yy'_month`mm'_dual.dta
		gen year_`yy'_month_`mm'=0
		replace year_`yy'_month_`mm'=1 if _merge==3
		drop _merge
	}
}
*
save Data/Interim/adjacency_vectors_dual.dta, replace


* Including multilateral lines
use Data/Interim/base_template.dta, replace
forvalues yy=2000(1)2025{
	forvalues mm=1(1)12{
		merge m:1 country_pair_id using Data/Interim/dates/year`yy'_month`mm'_all.dta
		gen year_`yy'_month_`mm'=0
		replace year_`yy'_month_`mm'=1 if _merge==3
		drop _merge
	}
}
*
save Data/Interim/adjacency_vectors_all.dta, replace

* just unidirectional (non bilateral)
use Data/Interim/base_template.dta, replace
forvalues yy=2000(1)2025{
	forvalues mm=1(1)12{
		merge m:1 country_pair_id using Data/Interim/dates/year`yy'_month`mm'_unidi.dta
		gen year_`yy'_month_`mm'=0
		replace year_`yy'_month_`mm'=1 if _merge==3
		drop _merge
	}
}
*
save Data/Interim/adjacency_vectors_unidi.dta, replace


* stacked adjacency vectors 
forvalues yy=2000(1)2025{
	forvalues mm=1(1)12{
		use Data/Interim/base_template.dta, replace
		merge m:1 country_pair_id using Data/Interim/dates/year`yy'_month`mm'.dta
		gen year=`yy'
		gen month=`mm'
		gen connection_bilat=0
		replace connection_bilat=1 if _merge==3
		drop _merge
		merge m:1 country_pair_id using Data/Interim/dates/year`yy'_month`mm'_all.dta
		gen connection_any=0
		replace connection_any=1 if _merge==3
		drop _merge
		merge m:1 country_pair_id using Data/Interim/dates/year`yy'_month`mm'_unidi.dta
		gen connection_unidi=0
		replace connection_unidi=1 if _merge==3
		drop _merge
		merge m:1 country_pair_id using Data/Interim/dates/year`yy'_month`mm'_dual.dta
		gen connection_dual=0
		replace connection_dual=1 if _merge==3
		drop _merge
		save Data/Interim/dates/vector_year`yy'_month`mm'.dta, replace
	}
}
*

*Create single dataset for all months
use Data/Interim/dates/vector_year2000_month1.dta, replace
forvalues mm=2(1)12{
append using Data/Interim/dates/vector_year2000_month`mm'.dta
}
*
forvalues yy=2001(1)2025{
forvalues mm=1(1)12{
append using Data/Interim/dates/vector_year`yy'_month`mm'.dta
}
}

*
gen date=mdy(month,1,year)
format date %td


*add GDP share
rename ISO_recipient country_code
rename year Year
merge m:1 country_code Year using Data/Input/input_macro_short.dta, keep(matched master) keepusing(GDP)
replace GDP=0 if GDP==.
drop _merge
rename country_code ISO_recipient
rename Year year

*
save Data/Interim/stacked_adjacency_vectors.dta, replace


*****************************STEP 4: Assign Ceilings and Export MATLAB Inputs *****


** Start with the stacked panel
use Data/Interim/stacked_adjacency_vectors.dta, replace

gen ceiling=connection_bilat
drop connection_any
drop GDP


** recode all ceilings to minus one to start
replace ceiling=-1 if connection_bilat == 1  
replace ceiling=. if connection_bilat == 0

** Rule 1: Use FRB's ceiling
replace ceiling = 100 if date<date("01Dec2011","DMY") & (ISO_source == "USA" | ISO_recipient == "USA") & ceiling==-1
replace ceiling = 50 if date<date("15Mar2020","DMY") & (ISO_source == "USA" | ISO_recipient == "USA") & ceiling==-1
replace ceiling = 25 if (ISO_source == "USA" | ISO_recipient == "USA") & ceiling==-1

foreach j in EA GBR JPN CAN CHE{
foreach i in EA GBR JPN CAN CHE{
replace ceiling = 100 if date<date("01Dec2011","DMY") & (ISO_source == "`i'" & ISO_recipient == "`j'") & ceiling==-1
replace ceiling = 50 if date<date("15Mar2020","DMY") & (ISO_source == "`i'" & ISO_recipient == "`j'") & ceiling==-1
replace ceiling = 25 if (ISO_source == "USA" & ISO_recipient == "`j'") & ceiling==-1
} 
}
*
** Singapore/Korea/Japan/BoE/EA/AUS/NZL to China: "prevailing market rates means SHIBOR: https://english.moef.go.kr/pc/selectTbPressCenterDtl.do%3Bjsessionid=uHupMcDgcTDcYZfUAfMr3WjT.node20?boardCd=N0001&seq=3124"
foreach j in EA GBR JPN CAN CHE KOR SGP AUS NZL{
replace ceiling = 0 if (ISO_source == "CHN" & ISO_recipient == "`j'") & ceiling==-1
replace ceiling = 0 if (ISO_source == "`j'" & ISO_recipient == "CHN" ) & ceiling==-1
}
*
* Hong Kong, Macau to China (using HKMA spread)
foreach j in HKG MAC{
replace ceiling = 50 if  date<date("22Jul2022","DMY") & (ISO_source == "CHN" & ISO_recipient == "`j'") & ceiling==-1
replace ceiling = 25 if (ISO_source == "`j'" & ISO_recipient == "CHN") & ceiling==-1
}
*
* Remainder to China  from Horn et al
replace ceiling = 250 if  (ISO_source == "CHN") & ceiling==-1
replace ceiling = 250 if (ISO_recipient == "CHN") & ceiling==-1
*

* Iceland borrowed at 3% (assumed a 50 bp spread) from YPFS
replace ceiling = 50 if  (ISO_source == "ISL") & ceiling==-1
replace ceiling = 50 if (ISO_recipient == "ISL") & ceiling==-1
*
tab ISO_source ISO_recipient if ceiling == -1
tab ceiling


replace ceiling = 100 if ceiling == -1
replace ceiling = -1 if ceiling == .
sort date source_id recipient_id 

**Intermediate for alternative MATLAB UPLOAD
drop recipient_id source_id country_pair_id connection_bilat connection_unidi connection_dual year month

rename ISO_source country_code
merge m:1 country_code using Data/Interim/country_codes_ordered.dta
drop _merge
rename country_code ISO_source
rename ISO_recipient country_code
rename country_ID source_country_ID

merge m:1 country_code using Data/Interim/country_codes_ordered.dta
drop _merge country_code ISO_source
rename country_ID recipient_country_ID
sort date source_country_ID recipient_country_ID
drop date
order source_country_ID recipient_country_ID ceiling

save Data/Interim/MATLAB_ceilings.dta, replace
export delimited using "Data/Interim/MATLAB_ceilings.csv", replace


*end of do-file
