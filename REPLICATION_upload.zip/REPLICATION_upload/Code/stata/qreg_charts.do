*************************** QREG Chart Helper **************************

/*
NB: This helper script exports quantile-regression comparison charts from
already prepared coefficient/SE variables in memory.

Required in-memory inputs:
    - beta_12 beta_13 beta_14 beta_23 beta_24
    - se_12 se_13 se_14 se_23 se_24
    - quantile, zero_line
    - globals: root, chart_name
*/

************************************************************************

*	STEP 1: Plot 1st vs 2nd Order

*	STEP 2: Plot 1st vs Higher Order

*	STEP 3: Plot 1st vs No Connection

*	STEP 4: Plot 2nd vs Higher Order

*	STEP 5: Plot 2nd vs No Connection

************************************************************************

cap mkdir Output/temp
cap mkdir Output/temp/qreg

**************** STEP 1: Plot 1st vs 2nd Order *************************
cap drop beta
cap drop se
gen beta=beta_12
gen se=se_12
cap drop ci_*
gen ci_up=beta+1.64*se
gen ci_down=beta-1.64*se
gen ci_68up=beta+1*se
gen ci_68down=beta-1*se

twoway rarea ci_68up ci_68down quantile, color(gs12)  || line ci_up beta ci_down zero_line quantile,  lwidth(thin thick thin vthin) lpattern(- . - .) lcolor(gs1 gs0 gs1 gs0) graphregion(color(white)) legend(order(1 "68% CI" 2 "90% C.I." 3 "estimate")) xtitle("Basis quantile") yscale(alt)

cap mkdir Output/temp/qreg/connection_12
cd Output/temp/qreg/connection_12

graph export $chart_name, replace

cd $root


**************** STEP 2: Plot 1st vs Higher Order **********************
cap drop beta
cap drop se
gen beta=beta_13
gen se=se_13
cap drop ci_*
gen ci_up=beta+1.64*se
gen ci_down=beta-1.64*se
gen ci_68up=beta+1*se
gen ci_68down=beta-1*se

twoway rarea ci_68up ci_68down quantile, color(gs12)  || line ci_up beta ci_down zero_line quantile,  lwidth(thin thick thin vthin) lpattern(- . - .) lcolor(gs1 gs0 gs1 gs0) graphregion(color(white)) legend(order(1 "68% CI" 2 "90% C.I." 3 "estimate")) xtitle("Basis quantile") yscale(alt)

cap mkdir Output/temp/qreg/connection_13
cd Output/temp/qreg/connection_13

graph export $chart_name, replace

cd $root

**************** STEP 3: Plot 1st vs No Connection *********************
cap drop beta
cap drop se
gen beta=beta_14
gen se=se_14
cap drop ci_*
gen ci_up=beta+1.64*se
gen ci_down=beta-1.64*se
gen ci_68up=beta+1*se
gen ci_68down=beta-1*se

twoway rarea ci_68up ci_68down quantile, color(gs12)  || line ci_up beta ci_down zero_line quantile,  lwidth(thin thick thin vthin) lpattern(- . - .) lcolor(gs1 gs0 gs1 gs0) graphregion(color(white)) legend(order(1 "68% CI" 2 "90% C.I." 3 "estimate")) xtitle("Basis quantile") yscale(alt)

cap mkdir Output/temp/qreg/connection_14
cd Output/temp/qreg/connection_14

graph export $chart_name, replace

cd $root

**************** STEP 4: Plot 2nd vs Higher Order **********************
cap drop beta
cap drop se
gen beta=beta_23
gen se=se_23
cap drop ci_*
gen ci_up=beta+1.64*se
gen ci_down=beta-1.64*se
gen ci_68up=beta+1*se
gen ci_68down=beta-1*se

twoway rarea ci_68up ci_68down quantile, color(gs12)  || line ci_up beta ci_down zero_line quantile,  lwidth(thin thick thin vthin) lpattern(- . - .) lcolor(gs1 gs0 gs1 gs0) graphregion(color(white)) legend(order(1 "68% CI" 2 "90% C.I." 3 "estimate")) xtitle("Basis quantile") yscale(alt)
graph export "Output/temp/qreg/$chart_name_connection_23.pdf", replace

cap mkdir Output/temp/qreg/connection_23
cd Output/temp/qreg/connection_23

graph export $chart_name, replace

cd $root

**************** STEP 5: Plot 2nd vs No Connection *********************
cap drop beta
cap drop se
gen beta=beta_24
gen se=se_24
cap drop ci_*
gen ci_up=beta+1.64*se
gen ci_down=beta-1.64*se
gen ci_68up=beta+1*se
gen ci_68down=beta-1*se

twoway rarea ci_68up ci_68down quantile, color(gs12)  || line ci_up beta ci_down zero_line quantile,  lwidth(thin thick thin vthin) lpattern(- . - .) lcolor(gs1 gs0 gs1 gs0) graphregion(color(white)) legend(order(1 "68% CI" 2 "90% C.I." 3 "estimate")) xtitle("Basis quantile") yscale(alt)
graph export "Output/temp/qreg/$chart_name_connection_24.pdf", replace


cap mkdir Output/temp/qreg/connection_24
cd Output/temp/qreg/connection_24

graph export $chart_name, replace

cd $root

