
****Summary Stats / Facts for Introduction 


* 30/12/2025 - initial version
* 10/02/2026 - extended with cap calculation added


*************************STEP 1: Prepare Environment*****************************

***Set up baseline environment
set more off
set seed 1111
cd $root

********************************************************************************
global liqlines "$root/Data/liquidity_lines.xlsx"

import excel "Data/Input/raw_input/country_code_conversion.xlsx", sheet("Sheet2") firstrow clear
save Data/Input/raw_input/country_code_conversion.dta, replace



******************************** STEP 1: Prepare Raw Data **********************

*********
***GDP shares 
*********

*raw input from IMF
import excel "Data/Input/raw_input/imf-dm-export-20251228.xlsx", firstrow clear

* Rename variables to include year
local year = 1980
foreach var of varlist B-AZ {
    rename `var' gdp`year'
    local year = `year' + 1
}

drop if mi(GDPcurrentpricesPurchasing)

* Reshape to long format
reshape long gdp, i(GDPcurrentpricesPurchasing) j(year)

rename gdp PPPGDP
rename GDPcurrentpricesPurchasing Country
rename year Year


* manually correct unmatched (left = country conversion, right = IMF)
replace Country = "Brunei" 	if Country == "Brunei Darussalam"
replace Country = "China" 	if Country == "China, People's Republic of"
replace Country = "Lao People's Democratic Republic" 	if Country == "Lao P.D.R."
replace Country = "Macao" 				if Country == "Macao SAR"
replace Country = "North Macedonia" 	if Country == "North Macedonia "
replace Country = "South Korea" 		if Country == "Korea, Republic of"
replace Country = "Turkey" 				if Country == "Türkiye, Republic of"
replace Country = "UK" 					if Country == "United Kingdom"
replace Country = "USA" 				if Country == "United States"
replace Country = "Hong Kong" 			if Country == "Hong Kong SAR"
replace Country = "Bahamas (the)" if Country == "Bahamas, The"
replace Country = "Bolivia (Plurinational State of)" if Country == "Bolivia"
replace Country = "Central African Republic (the)" if Country == "Central African Republic"
replace Country = "Congo (the Democratic Republic of the)" if Country == "Democratic Republic of the Congo"
replace Country = "Congo (the)" if Country == "Republic of Congo"
replace Country = "Comoros (the)" if Country == "Comoros"
replace Country = "Czechia" if Country == "Czech Republic"
replace Country = "Dominican Republic (the)" if Country == "Dominican Republic"
replace Country = "Micronesia (Federated States of)" if Country == "Micronesia"
replace Country = "Gambia (the)" if Country == "Gambia, The"
replace Country = "Iran (Islamic Republic of)" if Country == "Iran"
replace Country = "Kyrgyzstan" if Country == "Kyrgyz Republic"
replace Country = "Moldova (the Republic of)" if Country == "Moldova"
replace Country = "Marshall Islands (the)" if Country == "Marshall Islands"
replace Country = "Niger (the)" if Country == "Niger"
replace Country = "Sudan (the)" if Country == "Sudan"
replace Country = "South Sudan" if Country == "South Sudan"
replace Country = "Sao Tome and Principe" if Country == "São Tomé and Príncipe"
replace Country = "Slovakia" if Country == "Slovak Republic"
replace Country = "Syrian Arab Republic (the)" if Country == "Syria"
replace Country = "Taiwan (Province of China)" if Country == "Taiwan Province of China"
replace Country = "Tanzania, the United Republic of" if Country == "Tanzania"
replace Country = "Kosovo" if Country == "Kosovo"
replace Country = "Venezuela (Bolivarian Republic of)" if Country == "Venezuela"
replace Country = "Palestine, State of" if Country == "West Bank and Gaza"


* change to numeric format
replace PPPGDP = "" if PPPGDP == "no data"
destring PPPGDP, replace

save Data/Input/raw_input/GDP_data_2025.dta, replace

import excel "Data/Input/raw_input/country_code_conversion.xlsx", firstrow sheet("Sheet2") clear

merge 1:m Country using Data/Input/raw_input/GDP_data_2025.dta 

rename Alpha3code ISO 
keep ISO Year PPPGDP
gduplicates drop

drop if mi(ISO)
drop if mi(Year)

save Data/Input/raw_input/GDP_data_2025.dta, replace

replace ISO = "EUR" if ISO == "HRV" | ISO == "LTU" | ISO == "LVA" | ISO == "EST" | ISO == "SVK" | ISO == "CYP" | ISO == "MLT" | ISO == "SVN" | ISO == "GRC" | ISO == "AUT" | ISO == "BEL" | ISO == "FIN" | ISO == "FRA" | ISO == "DEU" | ISO == "IRL" | ISO == "ITA" | ISO == "LUX" | ISO == "NLD" | ISO == "PRT" | ISO == "ESP"
bys Year: egen EUR_GDP = total(PPPGDP) if ISO == "EUR"
keep if ISO == "EUR"

replace PPPGDP = EUR_GDP if !mi(EUR_GDP)
drop EUR_GDP
gduplicates drop

append using Data/Input/raw_input/GDP_data_2025.dta

replace ISO = "EA" if ISO == "EUR" 
save Data/Input/raw_input/GDP_data_2025.dta, replace

***2025 missing for some countries
bysort ISO (Year): replace PPPGDP = PPPGDP[_n-1] if missing(PPPGDP)


bys Year: egen total_GDP = total(PPPGDP)
bys Year: gen PPPGDP_share = 100*PPPGDP/total_GDP

rename ISO iso3c
rename Year year
rename PPPGDP_share GDP 
drop PPP* total*

replace iso3c = "EA" if iso3c == "EUR" 


save Data/Input/input_PPP_GDP_share_new.dta, replace
export excel "Data/Input/input_PPP_GDP_share_new.xlsx", firstrow(variables) replace


**********************************************************************

*********
***Reserves 
*********

*******
***STEP 1: Import and prepare reserves data (IMF)
*******

import delimited "Data/Input/raw_input/foreignreserves_IMF_IFS_raw.csv", clear

* Drop status rows
drop if attribute == "Status"
drop v300 

* Rename m1-m12 for year 2000
forvalues i = 1/12 {
    rename m`i' reserves_2000_`i'
}

* Rename v1-v281 for years 2001-2024
local month = 1
local year = 2001
forvalues i = 18/298 {
    rename v`i' reserves_`year'_`month'
    local month = `month' + 1
    if `month' > 12 {
        local month = 1
        local year = `year' + 1
    }
}

* Keep only relevant columns
keep countryname countrycode indicatorcode reserves*
destring reserves*, replace

* Keep only total reserves and SDRs
keep if indicatorcode == "RAFA_USD" | indicatorcode == "RAFASDR_USD"

* Save for later merge
tempfile reserves_ifs
save `reserves_ifs'

*******
*** STEP 2: Import EA SDRs from IRFCL and append
*******

import delimited "Data/Input/raw_input/foreignreserves_IMF_IRFCL_raw.csv", clear

* Drop status rows
drop if attribute == "Status"
drop v292

* Rename m1-m12 for year 2000
forvalues i = 1/12 {
    rename m`i' reserves_2000_`i'
}

* Rename v1-v281 for years 2001-2024
local month = 1
local year = 2001
forvalues i = 20/291 {
    rename v`i' reserves_`year'_`month'
    local month = `month' + 1
    if `month' > 12 {
        local month = 1
        local year = `year' + 1
    }
}


* Keep only Euro Area SDRs
keep if countryname == "Euro Area" & indicatorcode == "RAFASDR_USD" & sectorcode == "MCG"

* Keep relevant columns
keep countryname countrycode indicatorcode reserves*

* Append to reserves data
append using `reserves_ifs'
rename countrycode IMF_Code
save `reserves_ifs', replace

*******
*** STEP 3: Import country codes and create mapping
*******

import excel "Data/Input/raw_input/country_code_conversion.xlsx", firstrow sheet("Sheet2") clear
keep Country Alpha3code IMF_Code
drop if mi(IMF_Code)

* Merge with country codes
merge 1:m IMF_Code using `reserves_ifs'
replace _merge = 3 if countryname == "Euro Area" 
replace Alpha3code = "EA" if countryname == "Euro Area"

drop if _merge != 3
keep countryname Alpha3code indicatorcode reserves* 

rename Alpha3code country_code


* STEP 5: Reshape reserves data from wide to long
* Reshape to long format
reshape long reserves_, i(country_code countryname indicatorcode) j(yearmonth) string

* Parse year and month
split yearmonth, parse("_") destring
rename yearmonth1 Year
rename yearmonth2 Month
drop yearmonth

rename reserves_ reserves
destring reserves, replace

* Reshape indicator codes to wide (separate columns for reserves_total and SDRs)
reshape wide reserves, i(country_code countryname Year Month) j(indicatorcode) string

rename reservesRAFA_USD reserves_total
rename reservesRAFASDR_USD SDRs

drop countryname


* STEP 6: Calculate net reserves

* If SDRs missing, use total reserves; otherwise subtract SDRs
gen net_reserves = cond(missing(SDRs), reserves_total, reserves_total - SDRs)

* Convert to millions (divide by 1,000,000)
replace net_reserves = net_reserves / 1000000
replace reserves_total = reserves_total / 1000000
replace SDRs = SDRs/1000000


tempfile reserves_main
save `reserves_main'


* STEP 7: Import and process China reserves from PBoC

import excel "Data/Input/raw_input/foreignreserves_China_PBoC.xls", clear cellrange(A5)

* Parse date (format: "January 2000")
rename A date_str
rename B Amount

* Split date string
gen Month_str = word(date_str, 1)
gen Year = real(word(date_str, 2))

* Convert month name to number
gen Month = .
replace Month = 1 if Month_str == "January"
replace Month = 2 if Month_str == "February"
replace Month = 3 if Month_str == "March"
replace Month = 4 if Month_str == "April"
replace Month = 5 if Month_str == "May"
replace Month = 6 if Month_str == "June"
replace Month = 7 if Month_str == "July"
replace Month = 8 if Month_str == "August"
replace Month = 9 if Month_str == "September"
replace Month = 10 if Month_str == "October"
replace Month = 11 if Month_str == "November"
replace Month = 12 if Month_str == "December"

* Scale amount (multiply by 100 to display in millions)
destring Amount, replace force
replace Amount = Amount * 100

keep Year Month Amount
rename Amount china_reserves

tempfile china_reserves
save `china_reserves'


* STEP 8: Merge China reserves into main data

use `reserves_main', clear
merge m:1 Year Month using `china_reserves'
keep if _merge != 2
drop _merge 

* Replace China net_reserves with PBoC data for dates <= May 2015
gen date = mdy(Month, 1, Year)
format date %td

replace net_reserves = china_reserves if country_code == "CHN" & date <= mdy(5, 30, 2015)
drop china_reserves

rename date Date

* Save 
tempfile reserves_with_china
save `reserves_with_china'

* STEP 9: Import and process imports data

import delimited "Data/Input/raw_input/Goodstrade_monthly.csv", clear

* Keep only goods imports CIF
keep if indicatorname == "Goods, Value of Imports, Cost, Insurance, Freight (CIF), US Dollars"

* Rename m1-m12 for year 2000
forvalues i = 1/12 {
    rename m`i' trade_2000_`i'
}

* Rename v1-v281 for years 2001-2024
local month = 1
local year = 2001
forvalues i = 20/298 {
    rename v`i' trade_`year'_`month'
    local month = `month' + 1
    if `month' > 12 {
        local month = 1
        local year = `year' + 1
    }
}

* Keep relevant columns
keep countryname countrycode trade*
rename countrycode IMF_Code

tempfile goods_trade
save `goods_trade'


import excel "Data/Input/raw_input/country_code_conversion.xlsx", firstrow sheet("Sheet2") clear
keep Country Alpha3code IMF_Code
drop if mi(IMF_Code)

* Merge with country codes
merge 1:m IMF_Code using `goods_trade'

replace _merge = 3 if countryname == "Euro Area"
replace Alpha3code = "EA" if countryname == "Euro Area"

drop if _merge != 3
keep countryname Alpha3code trade* 

rename Alpha3code country_code
drop if missing(country_code)

* Reshape to long format
reshape long trade_, i(countryname country_code) j(yearmonth) string

gen Year = real(substr(yearmonth, 1, 4))
gen Month = real(substr(yearmonth, 6, .))
drop yearmonth countryname

rename trade_ goods_imports
destring goods_imports, replace force

* Convert to millions
replace goods_imports = goods_imports / 1000000

tempfile imports
save `imports'




* STEP 10: Import and process exports data

import delimited "Data/Input/raw_input/Goodstrade_monthly.csv", clear

* Keep only goods imports CIF
keep if indicatorname == "Goods, Value of Exports, Free on board (FOB), US Dollars"

* Rename m1-m12 for year 2000
forvalues i = 1/12 {
    rename m`i' trade_2000_`i'
}

* Rename v1-v281 for years 2001-2024
local month = 1
local year = 2001
forvalues i = 20/298 {
    rename v`i' trade_`year'_`month'
    local month = `month' + 1
    if `month' > 12 {
        local month = 1
        local year = `year' + 1
    }
}

* Keep relevant columns
keep countryname countrycode trade*
rename countrycode IMF_Code

tempfile goods_trade
save `goods_trade'

import excel "Data/Input/raw_input/country_code_conversion.xlsx", firstrow sheet("Sheet2") clear
keep Country Alpha3code IMF_Code
drop if mi(IMF_Code)

* Merge with country codes
merge 1:m IMF_Code using `goods_trade'

replace _merge = 3 if countryname == "Euro Area"
replace Alpha3code = "EA" if countryname == "Euro Area"

drop if _merge != 3
keep countryname Alpha3code trade* 

rename Alpha3code country_code
drop if missing(country_code)

* Reshape to long format
reshape long trade_, i(countryname country_code) j(yearmonth) string

gen Year = real(substr(yearmonth, 1, 4))
gen Month = real(substr(yearmonth, 6, .))
drop yearmonth countryname

rename trade_ goods_exports
destring goods_exports, replace force

* Convert to millions
replace goods_exports = goods_exports / 1000000

tempfile exports
save `exports'


* STEP 10: Merge imports with reserves

use `reserves_with_china', clear
merge 1:1 country_code Year Month using `imports'
keep if _merge != 2
drop _merge 
merge 1:1 country_code Year Month using `exports'
keep if _merge != 2
drop _merge 


* STEP 11: Calculate reserve/import ratio
gen reserve_import_ratio = net_reserves / goods_imports if !missing(net_reserves) & !missing(goods_imports)


* STEP 12: Final cleaning

* Drop negative reserves
drop if net_reserves < 0 & !missing(net_reserves)

* Drop zero reserves
drop if net_reserves == 0 & !missing(net_reserves)

* Order variables
order country_code Year Month goods_imports reserves_total SDRs net_reserves Date reserve_import_ratio

* Sort
sort country_code Year Month


* STEP 13: Export
save "Data/Input/input_monthly_reserves.dta", replace
export delimited "Data/Input/input_monthly_reserves.csv", replace


**********************************************************************
******
***Update reserves 2025 
******

*******IMPORTS

*NB: some series discontinued, update from last available point, NOT full series
*	-> reserves last value 2024-05 / 2023-08 for EA
*	-> imports last value 2024-03

import delimited "Data/Input/raw_input/imf_goodsimports_raw_update.csv", clear
rename country_code IMF_Code

drop if IMF_Code == "#N/A" & country != "Euro Area (EA)"
replace IMF_Code = "" if country == "Euro Area (EA)"
destring IMF_Code, replace
keep IMF_Code country v* 


* Rename v22-v65
local month = 4
local year = 2024
forvalues i = 49/65 {
    rename v`i' trade_`year'_`month'
    local month = `month' + 1
    if `month' > 12 {
        local month = 1
        local year = `year' + 1
    }
}

tempfile imports
save `imports'

use Data/Input/raw_input/country_code_conversion.dta, clear
keep Country Alpha3code IMF_Code
drop if mi(IMF_Code)


merge 1:1 IMF_Code using `imports'
replace _merge = 3 if country == "Euro Area (EA)" 
replace Alpha3code = "EA" if country == "Euro Area (EA)"

drop if _merge != 3
keep Alpha3code trade* 

rename Alpha3code country_code

* Reshape to long format
reshape long trade_, i(country_code) j(yearmonth) string

* Parse year and month
split yearmonth, parse("_") destring
rename yearmonth1 Year
rename yearmonth2 Month
drop yearmonth

rename trade_ goods_imports
destring goods_imports, replace

tempfile imports
save `imports'


*** RESERVES
import delimited "Data/Input/raw_input/imf_reservesIRFCL_raw_update.csv", clear
rename country_code IMF_Code

drop if IMF_Code == "#N/A" & country != "Euro Area (EA)"
replace IMF_Code = "" if country == "Euro Area (EA)"
destring IMF_Code, replace

replace indicator = "RAFASDR_USD" if strpos(indicator, "Special Drawing Rights")
replace indicator = "RAFA_USD" if indicator != "RAFASDR_USD"

* Rename v22-v65
local month = 8
local year = 2023
forvalues i = 41/68 {
    rename v`i' reserves_`year'_`month'
    local month = `month' + 1
    if `month' > 12 {
        local month = 1
        local year = `year' + 1
    }
}

keep IMF_Code country indicator reserves* 

tempfile reserves
save `reserves'

use Data/Input/raw_input/country_code_conversion.dta, clear
keep Country Alpha3code IMF_Code
drop if mi(IMF_Code)


merge 1:m IMF_Code using `reserves'
replace _merge = 3 if country == "Euro Area (EA)" 
replace Alpha3code = "EA" if country == "Euro Area (EA)"

drop if _merge != 3
keep Alpha3code indicator reserves* 

rename Alpha3code country_code


* STEP 5: Reshape reserves data from wide to long
* Reshape to long format
reshape long reserves_, i(country_code indicator) j(yearmonth) string

* Parse year and month
split yearmonth, parse("_") destring
rename yearmonth1 Year
rename yearmonth2 Month
drop yearmonth

rename reserves_ reserves
destring reserves, replace

* Reshape indicator codes to wide (separate columns for reserves_total and SDRs)
reshape wide reserves, i(country_code Year Month) j(indicator) string

rename reservesRAFA_USD reserves_total
rename reservesRAFASDR_USD SDRs

* If SDRs missing, use total reserves; otherwise subtract SDRs
gen net_reserves = cond(missing(SDRs), reserves_total, reserves_total - SDRs)

*NB: no need to convert numbers bec already in millions

*merge with imports data
merge 1:1 country_code Year Month using `imports', nogen

gen date = mdy(Month, 1, Year)
format date %td
rename date Date

save Data/Input/raw_input/input_monthly_reserves_2025update.dta, replace




************
*** Update previous file with 2025 
************

use Data/Input/input_monthly_reserves.dta, clear

*merge update to existing data
*NB: update missing values in existing data, do not update conflict values in existing data
merge 1:1 Year Month country_code using Data/Input/raw_input/input_monthly_reserves_2025update.dta, update

*keep all observations
drop _merge 

*Update goods imports ratio
replace reserve_import_ratio = net_reserves / goods_imports if !missing(net_reserves) & !missing(goods_imports) & mi(reserve_import_ratio)

save Data/Input/input_monthly_reserves_2025.dta, replace




********************************************************************************


**********
***Import LCU GDP
**********

*raw input from IMF
import excel "Data/Input/raw_input/imf_PPP_conversionrate_2025.xls", firstrow clear

* Rename variables to include year
local year = 1980
foreach var of varlist B-AZ {
    rename `var' ppp`year'
    local year = `year' + 1
}

drop if mi(ImpliedPPPconversionrate)

* Reshape to long format
reshape long ppp, i(ImpliedPPPconversionrate) j(year)

rename ppp ppp_conversion
rename ImpliedPPPconversionrate Country
rename year Year


* manually correct unmatched (left = country conversion, right = IMF)
replace Country = "Brunei" 	if Country == "Brunei Darussalam"
replace Country = "China" 	if Country == "China, People's Republic of"
replace Country = "Lao People's Democratic Republic" 	if Country == "Lao P.D.R."
replace Country = "Macao" 				if Country == "Macao SAR"
replace Country = "North Macedonia" 	if Country == "North Macedonia "
replace Country = "South Korea" 		if Country == "Korea, Republic of"
replace Country = "Turkey" 				if Country == "Türkiye, Republic of"
replace Country = "UK" 					if Country == "United Kingdom"
replace Country = "USA" 				if Country == "United States"
replace Country = "Hong Kong" 			if Country == "Hong Kong SAR"
replace Country = "Bahamas (the)" if Country == "Bahamas, The"
replace Country = "Bolivia (Plurinational State of)" if Country == "Bolivia"
replace Country = "Central African Republic (the)" if Country == "Central African Republic"
replace Country = "Congo (the Democratic Republic of the)" if Country == "Democratic Republic of the Congo"
replace Country = "Congo (the)" if Country == "Republic of Congo"
replace Country = "Comoros (the)" if Country == "Comoros"
replace Country = "Czechia" if Country == "Czech Republic"
replace Country = "Dominican Republic (the)" if Country == "Dominican Republic"
replace Country = "Micronesia (Federated States of)" if Country == "Micronesia"
replace Country = "Gambia (the)" if Country == "Gambia, The"
replace Country = "Iran (Islamic Republic of)" if Country == "Iran"
replace Country = "Kyrgyzstan" if Country == "Kyrgyz Republic"
replace Country = "Moldova (the Republic of)" if Country == "Moldova"
replace Country = "Marshall Islands (the)" if Country == "Marshall Islands"
replace Country = "Niger (the)" if Country == "Niger"
replace Country = "Sudan (the)" if Country == "Sudan"
replace Country = "South Sudan" if Country == "South Sudan"
replace Country = "Sao Tome and Principe" if Country == "São Tomé and Príncipe"
replace Country = "Slovakia" if Country == "Slovak Republic"
replace Country = "Syrian Arab Republic (the)" if Country == "Syria"
replace Country = "Taiwan (Province of China)" if Country == "Taiwan Province of China"
replace Country = "Tanzania, the United Republic of" if Country == "Tanzania"
replace Country = "Kosovo" if Country == "Kosovo"
replace Country = "Venezuela (Bolivarian Republic of)" if Country == "Venezuela"
replace Country = "Palestine, State of" if Country == "West Bank and Gaza"

replace Country = "Hong Kong" if strpos(Country, "Hong Kong")
replace Country = "Macao" if strpos(Country, "Macao")

replace Country = regexr(Country, ",.*$", "")
drop if Country == "Congo"

* change to numeric format
replace ppp_conversion = "" if ppp_conversion == "no data"
destring ppp_conversion, replace

save Data/Input/raw_input/GDP_conversion_data_2025.dta, replace

import excel "Data/Input/raw_input/country_code_conversion.xlsx", firstrow sheet("Sheet2") clear

merge 1:m Country using Data/Input/raw_input/GDP_conversion_data_2025.dta 

rename Alpha3code ISO 
keep ISO Year ppp_conversion
gduplicates drop

drop if mi(ISO)
drop if mi(Year)

save Data/Input/raw_input/GDP_conversion_data_2025.dta, replace

/*
replace ISO = "EA" if ISO == "HRV" | ISO == "LTU" | ISO == "LVA" | ISO == "EST" | ISO == "SVK" | ISO == "CYP" | ISO == "MLT" | ISO == "SVN" | ISO == "GRC" | ISO == "AUT" | ISO == "BEL" | ISO == "FIN" | ISO == "FRA" | ISO == "DEU" | ISO == "IRL" | ISO == "ITA" | ISO == "LUX" | ISO == "NLD" | ISO == "PRT" | ISO == "ESP"
bys Year: egen EUR_GDP = total(PPPGDP) if ISO == "EUR"
keep if ISO == "EA"

replace ppp_conversion = EUR_GDP if !mi(EUR_GDP)
drop EUR_GDP
gduplicates drop

append using GDP_conversion_data_2025.dta
*/

***2025 missing for some countries, carry forward 2024
bysort ISO (Year): replace ppp_conversion = ppp_conversion[_n-1] if missing(ppp_conversion)

***Merge to GDP data 
merge 1:1 Year ISO using Data/Input/raw_input/GDP_data_2025.dta
drop _merge 

***Generate LCU GDP 
gen LCUGDP = ppp_conversion * PPPGDP

***Save
save Data/Input/GDP_LCU.dta, replace


**********
*** Import avg. FX rates from IMF
**********

*raw input from IMF
import excel "Data/Input/raw_input/imf_annualfx_2025.xls", firstrow clear

drop DATASET SERIES_CODE OBS_MEASURE TYPE_OF_TRANSFORMATION FREQUENCY SCALE
 
* Rename variables to include year
local year = 1940
foreach var of varlist I-CP {
    rename `var' fx`year'
    local year = `year' + 1
}

drop if mi(COUNTRY)

* Reshape to long format
reshape long fx, i(COUNTRY INDICATOR) j(year)

rename INDICATOR fx_target
rename COUNTRY Country
rename year Year

* manually correct unmatched (left = country conversion, right = IMF)
replace Country = "Brunei" 	if Country == "Brunei Darussalam"
replace Country = "China" 	if Country == "China, People's Republic of"
replace Country = "Lao People's Democratic Republic" 	if Country == "Lao P.D.R."
replace Country = "Macao" 				if Country == "Macao SAR"
replace Country = "North Macedonia" 	if Country == "North Macedonia "
replace Country = "South Korea" 		if Country == "Korea, Republic of"
replace Country = "Turkey" 				if Country == "Türkiye, Republic of"
replace Country = "UK" 					if Country == "United Kingdom"
replace Country = "USA" 				if Country == "United States"
replace Country = "Hong Kong" 			if Country == "Hong Kong SAR"
replace Country = "Bahamas (the)" if Country == "Bahamas, The"
replace Country = "Bolivia (Plurinational State of)" if Country == "Bolivia"
replace Country = "Central African Republic (the)" if Country == "Central African Republic"
replace Country = "Congo (the Democratic Republic of the)" if Country == "Democratic Republic of the Congo"
replace Country = "Congo (the)" if Country == "Republic of Congo"
replace Country = "Comoros (the)" if Country == "Comoros"
replace Country = "Czechia" if Country == "Czech Republic"
replace Country = "Dominican Republic (the)" if Country == "Dominican Republic"
replace Country = "Micronesia (Federated States of)" if Country == "Micronesia"
replace Country = "Gambia (the)" if Country == "Gambia, The"
replace Country = "Iran (Islamic Republic of)" if Country == "Iran"
replace Country = "Kyrgyzstan" if Country == "Kyrgyz Republic"
replace Country = "Moldova (the Republic of)" if Country == "Moldova"
replace Country = "Marshall Islands (the)" if Country == "Marshall Islands"
replace Country = "Niger (the)" if Country == "Niger"
replace Country = "Sudan (the)" if Country == "Sudan"
replace Country = "South Sudan" if Country == "South Sudan"
replace Country = "Sao Tome and Principe" if Country == "São Tomé and Príncipe"
replace Country = "Slovakia" if Country == "Slovak Republic"
replace Country = "Syrian Arab Republic (the)" if Country == "Syria"
replace Country = "Taiwan (Province of China)" if Country == "Taiwan Province of China"
replace Country = "Tanzania, the United Republic of" if Country == "Tanzania"
replace Country = "Kosovo" if Country == "Kosovo"
replace Country = "Venezuela (Bolivarian Republic of)" if Country == "Venezuela"
replace Country = "Palestine, State of" if Country == "West Bank and Gaza"

replace Country = "Hong Kong" if strpos(Country, "Hong Kong")
replace Country = "Macao" if strpos(Country, "Macao")

replace Country = regexr(Country, ",.*$", "")
drop if Country == "Congo"

* change to numeric format
destring fx, replace
drop if Year < 1980 
drop if mi(fx)

* reshape to wide again 
replace fx_target = "EUR" if strpos(fx_target, "Euros")
replace fx_target = "USD" if strpos(fx_target, "Dollar")

reshape wide fx, i(Country Year) j(fx_target) string

save Data/Input/raw_input/FX_conversion_data_2025.dta, replace

import excel "Data/Input/raw_input/country_code_conversion.xlsx", firstrow sheet("Sheet2") clear

merge 1:m Country using Data/Input/raw_input/FX_conversion_data_2025.dta 

replace Alpha3code = "EA" if Country == "Euro Area (EA)"
rename Alpha3code ISO 
keep ISO Year fx*
gduplicates drop

drop if mi(ISO)
drop if mi(Year)

save Data/Input/raw_input/FX_conversion_data_2025.dta, replace

/* Skip EUR conversion bec mostly care about "new" countries being added to network

replace ISO = "EUR" if ISO == "HRV" | ISO == "LTU" | ISO == "LVA" | ISO == "EST" | ISO == "SVK" | ISO == "CYP" | ISO == "MLT" | ISO == "SVN" | ISO == "GRC" | ISO == "AUT" | ISO == "BEL" | ISO == "FIN" | ISO == "FRA" | ISO == "DEU" | ISO == "IRL" | ISO == "ITA" | ISO == "LUX" | ISO == "NLD" | ISO == "PRT" | ISO == "ESP"
bys Year: egen EUR_GDP = total(PPPGDP) if ISO == "EUR"
keep if ISO == "EUR"

replace ppp_conversion = EUR_GDP if !mi(EUR_GDP)
drop EUR_GDP
gduplicates drop

append using GDP_conversion_data_2025.dta
*/ 

***2025 missing for some countries, carry forward 2024
bysort ISO (Year): replace fxEUR = fxEUR[_n-1] if missing(fxEUR)
bysort ISO (Year): replace fxUSD = fxUSD[_n-1] if missing(fxUSD)

***Merge to GDP data 
merge 1:1 Year ISO using Data/Input/GDP_LCU.dta
drop if _merge == 1 & ISO != "EA"
drop _merge

***Save
save Data/Input/GDP_LCU_FX.dta, replace


***********
***Correct Euro Area
***********

* Calculate GDP in LCU for the big 3
gen LCU_temp = PPPGDP * ppp_conversion if inlist(ISO, "DEU", "FRA", "ITA")

* Get sum of big 3 PPP GDP for weights
bysort Year: egen PPP_big3 = total(PPPGDP) if inlist(ISO, "DEU", "FRA", "ITA")
bysort Year: egen PPP_big3_all = max(PPP_big3)

* Get sum of big 3 LCU GDP
bysort Year: egen LCU_big3 = total(LCU_temp)
bysort Year: egen LCU_big3_all = max(LCU_big3)

* Calculate weighted average PPP factor (= total LCU / total PPP)
gen PPP_EA = LCU_big3_all / PPP_big3_all

* Convert EA GDP
replace LCUGDP = PPPGDP * PPP_EA if ISO == "EA"

* Clean up
drop LCU_temp PPP_big3 PPP_big3_all LCU_big3 LCU_big3_all PPP_EA

***Save
save Data/Input/GDP_LCU_FX.dta, replace

*********
*** Import KA openness
*********

*NB: Acc to Ito & Shinn, 2023 update

use Data/Input/raw_input/kaopen_2023.dta, replace

keep kaopen ka_open year ccode 
rename ccode 	ISO
rename year 	Year 
rename ka_open	kaopen_norm

save Data/Input/raw_input/KA_open.dta, replace

*********
*** Import IMF Financial Development
*********

*raw input from IMF
import excel "Data/Input/raw_input/IMF_findev.xls", firstrow clear

drop DATASET SERIES_CODE OBS_MEASURE FREQUENCY SCALE
 
* Rename variables to include year
local year = 2000
foreach var of varlist H-AB {
    rename `var' findev`year'
    local year = `year' + 1
}

drop if mi(COUNTRY)

* Reshape to long format
reshape long findev, i(COUNTRY INDICATOR) j(year)

rename INDICATOR fin_dev
rename COUNTRY Country
rename year Year

keep if fin_dev == "Financial Development Index" | fin_dev == "Financial Institutions Efficiency Index" | fin_dev == "Financial Markets Access Index"

replace fin_dev = "_idx" if fin_dev == "Financial Development Index" 
replace fin_dev = "_efficiency_idx" if fin_dev == "Financial Institutions Efficiency Index" 
replace fin_dev = "_access_idx" if fin_dev == "Financial Markets Access Index"

* manually correct unmatched (left = country conversion, right = IMF)
replace Country = "Brunei" 	if Country == "Brunei Darussalam"
replace Country = "China" 	if Country == "China, People's Republic of"
replace Country = "Lao People's Democratic Republic" 	if Country == "Lao P.D.R."
replace Country = "Macao" 				if Country == "Macao SAR"
replace Country = "North Macedonia" 	if Country == "North Macedonia "
replace Country = "South Korea" 		if Country == "Korea, Republic of"
replace Country = "Turkey" 				if Country == "Türkiye, Republic of"
replace Country = "UK" 					if Country == "United Kingdom"
replace Country = "USA" 				if Country == "United States"
replace Country = "Hong Kong" 			if Country == "Hong Kong SAR"
replace Country = "Bahamas (the)" if Country == "Bahamas, The"
replace Country = "Bolivia (Plurinational State of)" if Country == "Bolivia"
replace Country = "Central African Republic (the)" if Country == "Central African Republic"
replace Country = "Congo (the Democratic Republic of the)" if Country == "Democratic Republic of the Congo"
replace Country = "Congo (the)" if Country == "Republic of Congo"
replace Country = "Comoros (the)" if Country == "Comoros"
replace Country = "Czechia" if Country == "Czech Republic"
replace Country = "Dominican Republic (the)" if Country == "Dominican Republic"
replace Country = "Micronesia (Federated States of)" if Country == "Micronesia"
replace Country = "Gambia (the)" if Country == "Gambia, The"
replace Country = "Iran (Islamic Republic of)" if Country == "Iran"
replace Country = "Kyrgyzstan" if Country == "Kyrgyz Republic"
replace Country = "Moldova (the Republic of)" if Country == "Moldova"
replace Country = "Marshall Islands (the)" if Country == "Marshall Islands"
replace Country = "Niger (the)" if Country == "Niger"
replace Country = "Sudan (the)" if Country == "Sudan"
replace Country = "South Sudan" if Country == "South Sudan"
replace Country = "Sao Tome and Principe" if Country == "São Tomé and Príncipe"
replace Country = "Slovakia" if Country == "Slovak Republic"
replace Country = "Syrian Arab Republic (the)" if Country == "Syria"
replace Country = "Taiwan (Province of China)" if Country == "Taiwan Province of China"
replace Country = "Tanzania, the United Republic of" if Country == "Tanzania"
replace Country = "Kosovo" if Country == "Kosovo"
replace Country = "Venezuela (Bolivarian Republic of)" if Country == "Venezuela"
replace Country = "Palestine, State of" if Country == "West Bank and Gaza"

replace Country = "Hong Kong" if strpos(Country, "Hong Kong")
replace Country = "Macao" if strpos(Country, "Macao")

replace Country = regexr(Country, ",.*$", "")
drop if Country == "Congo"

* change to numeric format
destring findev, replace
drop if mi(findev)

*reshape wide
reshape wide findev, i(Country Year) j(fin_dev) string

save Data/Input/raw_input/fin_dev.dta, replace

import excel "Data/Input/raw_input/country_code_conversion.xlsx", firstrow sheet("Sheet2") clear

merge 1:m Country using Data/Input/raw_input/fin_dev.dta 

replace Alpha3code = "EA" if Country == "Europe"
rename Alpha3code ISO 
keep ISO Year findev*
gduplicates drop

drop if mi(ISO)
drop if mi(Year)

save Data/Input/raw_input/fin_dev.dta, replace


*********
*** International Investment Position 
*********

import delimited "Data/Input/raw_input/IMF_NIIP.csv", varnames(1) clear

keep country time_period obs_value

rename country		Country
rename time_period	Year
rename obs_value	NIIP

* manually correct unmatched (left = country conversion, right = IMF)
replace Country = "Brunei" 	if Country == "Brunei Darussalam"
replace Country = "China" 	if Country == "China, People's Republic of"
replace Country = "Lao People's Democratic Republic" 	if Country == "Lao P.D.R."
replace Country = "Macao" 				if Country == "Macao SAR"
replace Country = "North Macedonia" 	if Country == "North Macedonia "
replace Country = "South Korea" 		if Country == "Korea, Republic of"
replace Country = "Turkey" 				if Country == "Türkiye, Republic of"
replace Country = "UK" 					if Country == "United Kingdom"
replace Country = "USA" 				if Country == "United States"
replace Country = "Hong Kong" 			if Country == "Hong Kong SAR"
replace Country = "Bahamas (the)" if Country == "Bahamas, The"
replace Country = "Bolivia (Plurinational State of)" if Country == "Bolivia"
replace Country = "Central African Republic (the)" if Country == "Central African Republic"
replace Country = "Congo (the Democratic Republic of the)" if Country == "Democratic Republic of the Congo"
replace Country = "Congo (the)" if Country == "Republic of Congo"
replace Country = "Comoros (the)" if Country == "Comoros"
replace Country = "Czechia" if Country == "Czech Republic"
replace Country = "Dominican Republic (the)" if Country == "Dominican Republic"
replace Country = "Micronesia (Federated States of)" if Country == "Micronesia"
replace Country = "Gambia (the)" if Country == "Gambia, The"
replace Country = "Iran (Islamic Republic of)" if Country == "Iran"
replace Country = "Kyrgyzstan" if Country == "Kyrgyz Republic"
replace Country = "Moldova (the Republic of)" if Country == "Moldova"
replace Country = "Marshall Islands (the)" if Country == "Marshall Islands"
replace Country = "Niger (the)" if Country == "Niger"
replace Country = "Sudan (the)" if Country == "Sudan"
replace Country = "South Sudan" if Country == "South Sudan"
replace Country = "Sao Tome and Principe" if Country == "São Tomé and Príncipe"
replace Country = "Slovakia" if Country == "Slovak Republic"
replace Country = "Syrian Arab Republic (the)" if Country == "Syria"
replace Country = "Taiwan (Province of China)" if Country == "Taiwan Province of China"
replace Country = "Tanzania, the United Republic of" if Country == "Tanzania"
replace Country = "Kosovo" if Country == "Kosovo"
replace Country = "Venezuela (Bolivarian Republic of)" if Country == "Venezuela"
replace Country = "Palestine, State of" if Country == "West Bank and Gaza"

replace Country = "Hong Kong" if strpos(Country, "Hong Kong")
replace Country = "Macao" if strpos(Country, "Macao")

replace Country = regexr(Country, ",.*$", "")
drop if Country == "Congo"

* change to numeric format
destring NIIP, replace
drop if mi(NIIP)

save Data/Input/raw_input/NIIP.dta, replace

import excel "Data/Input/raw_input/country_code_conversion.xlsx", firstrow sheet("Sheet2") clear

merge 1:m Country using Data/Input/raw_input/NIIP.dta 

replace Alpha3code = "EA" if Country == "Euro Area (EA)"
rename Alpha3code ISO 
keep ISO Year NIIP*
gduplicates drop

drop if mi(ISO)
drop if mi(Year)

save Data/Input/raw_input/NIIP.dta, replace


***********
*** Population data 
***********


***********
*** FX anchor 
***********

import excel "Data/Input/raw_input/FX_anchor_monthly.xlsx", cellrange(A6) firstrow sheet("Master") clear

* Drop extra rows and columns 
drop in 1/4
drop X_* 
* Drop variables that are exactly 2 letters (Excel columns are 2 letters, ISO codes are 3)
foreach var of varlist _all {
    if length("`var'") == 2 {
        drop `var'
    }
}
rename ISO3Code time

* Rename all except the time variable:
ds time, not
rename (`r(varlist)') val_=

* Now reshape
reshape long val_, i(time) j(iso3c) string

* Clean up
rename val_ FX_anchor
replace FX_anchor = "" if FX_anchor == "n.a."

gen Year = substr(time, 1, 4)
gen Month = substr(time, 6,.)

destring Year, replace
destring Month, replace

drop time

rename iso3c ISO
drop if Year <= 1999
save "Data/Input/raw_input/FX_anchor.dta", replace

**********
*** FX regime 
**********

import excel "Data/Input/raw_input/FX_regime_monthly.xlsx", cellrange(B5) sheet("Fine") clear

* Step 1: Combine rows 1 and 2 to create proper country names
* Extract the values from rows 1 and 2 for each variable

ds B, not 
local countryvars `r(varlist)'

foreach var of local countryvars {
    * Get values from row 1 and row 2
    local row1 = `var'[1]
    local row2 = `var'[2]
	
	* Replace problematic characters BEFORE combining
    local row1 : subinstr local row1 "'" "", all
    local row2 : subinstr local row2 "'" "", all
    
    * Combine them (trim and concatenate)
    local newname = trim("`row1'") + trim("`row2'")
    
    * Clean the name to make it a valid Stata variable name
    local newname = subinstr("`newname'", " ", "_", .)
    local newname = subinstr("`newname'", ".", "", .)
    local newname = subinstr("`newname'", ",", "", .)
    local newname = subinstr("`newname'", "'", "", .)
    local newname = subinstr("`newname'", "-", "_", .)
	
    * Rename if we have a valid name
    if "`newname'" != "" {
        capture rename `var' `newname'
    }
}

* Step 2: Drop rows 1, 2, and 3 (the header rows and empty row)
drop in 1/3

* Drop variables that are exactly 2 letters (Excel columns are 2 letters, ISO codes are 3)
foreach var of varlist _all {
    if length("`var'") == 2 {
        drop `var'
    }
}

drop if mi(B)

rename B time

* Rename all except the time variable:
ds time, not
rename (`r(varlist)') val_=

* Now reshape
reshape long val_, i(time) j(country) string

* Clean up
rename val_ FX_regime
replace FX_regime = "" if FX_regime == "n.a."
destring FX_regime, replace

gen Year = substr(time, 1, 4)
gen Month = substr(time, 6,.)

destring Year, replace
destring Month, replace

drop time

*** Manual country mapping 

gen iso3c = ""
replace iso3c = "AFG" if country == "Afghanistan"
replace iso3c = "ALB" if country == "Albania"
replace iso3c = "DZA" if country == "Algeria"
replace iso3c = "AGO" if country == "Angola"
replace iso3c = "AIA" if country == "Anguilla"
replace iso3c = "ATG" if country == "Antiguaand_Barbuda"
replace iso3c = "ARG" if country == "Argentina"
replace iso3c = "ARM" if country == "Armenia"
replace iso3c = "ABW" if country == "Aruba"
replace iso3c = "AUS" if country == "Australia"
replace iso3c = "AUT" if country == "Austria"
replace iso3c = "AZE" if country == "AzerbaijanRep_of"
replace iso3c = "BHR" if country == "BahrainKingdom_of"
replace iso3c = "BGD" if country == "Bangladesh"
replace iso3c = "BRB" if country == "Barbados"
replace iso3c = "BLR" if country == "Belarus"
replace iso3c = "BEL" if country == "Belgium"
replace iso3c = "BLZ" if country == "Belize"
replace iso3c = "BEN" if country == "Benin"
replace iso3c = "BMU" if country == "Bermuda"
replace iso3c = "BTN" if country == "Bhutan"
replace iso3c = "BOL" if country == "Bolivia"
replace iso3c = "BWA" if country == "Botswana"
replace iso3c = "BIH" if country == "BosniaHerzegovina"
replace iso3c = "BRA" if country == "Brazil"
replace iso3c = "BRN" if country == "BruneiDarussalam"
replace iso3c = "BGR" if country == "Bulgaria"
replace iso3c = "BFA" if country == "BurkinaFaso"
replace iso3c = "BDI" if country == "Burundi"
replace iso3c = "CPV" if country == "CaboVerde"
replace iso3c = "KHM" if country == "Cambodia"
replace iso3c = "CMR" if country == "Cameroon"
replace iso3c = "CAN" if country == "Canada"
replace iso3c = "CAF" if country == "CentralAfrican_Rep"
replace iso3c = "TCD" if country == "Chad"
replace iso3c = "CHL" if country == "Chile"
replace iso3c = "CHN" if country == "China_PR"
replace iso3c = "COL" if country == "Colombia"
replace iso3c = "COM" if country == "Comoros"
replace iso3c = "COG" if country == "CongoRep_of"
replace iso3c = "COD" if country == "Congo_DemRep_of"
replace iso3c = "CRI" if country == "CostaRica"
replace iso3c = "CIV" if country == "CoteDIvoire"
replace iso3c = "HRV" if country == "Croatia"
replace iso3c = "CUW" if country == "Curacao"
replace iso3c = "CYP" if country == "Cyprus"
replace iso3c = "CZE" if country == "CzechRep"
replace iso3c = "DNK" if country == "Denmark"
replace iso3c = "DJI" if country == "Djibouti"
replace iso3c = "DMA" if country == "Dominica"
replace iso3c = "DOM" if country == "DominicanRepublic"
replace iso3c = "ECU" if country == "Ecuador"
replace iso3c = "EGY" if country == "Egypt"
replace iso3c = "SLV" if country == "ElSalvador"
replace iso3c = "GNQ" if country == "EquatorialGuinea"
replace iso3c = "ERI" if country == "Eritrea"
replace iso3c = "EST" if country == "Estonia"
replace iso3c = "ETH" if country == "Ethiopia"
replace iso3c = "FJI" if country == "Fiji"
replace iso3c = "FIN" if country == "Finland"
replace iso3c = "FRA" if country == "France"
replace iso3c = "GAB" if country == "Gabon"
replace iso3c = "GEO" if country == "Georgia"
replace iso3c = "DEU" if country == "Germany"
replace iso3c = "GHA" if country == "Ghana"
replace iso3c = "GRC" if country == "Greece"
replace iso3c = "GRD" if country == "Grenada"
replace iso3c = "GTM" if country == "Guatemala"
replace iso3c = "GIN" if country == "Guinea"
replace iso3c = "GNB" if country == "GuineaBissau"
replace iso3c = "GUY" if country == "Guyana"
replace iso3c = "HTI" if country == "Haiti"
replace iso3c = "HND" if country == "Honduras"
replace iso3c = "HKG" if country == "HongKong"
replace iso3c = "HUN" if country == "Hungary"
replace iso3c = "ISL" if country == "Iceland"
replace iso3c = "IND" if country == "India"
replace iso3c = "IDN" if country == "Indonesia"
replace iso3c = "IRN" if country == "Iran"
replace iso3c = "IRQ" if country == "Iraq"
replace iso3c = "IRL" if country == "Ireland"
replace iso3c = "ISR" if country == "Israel"
replace iso3c = "ITA" if country == "Italy"
replace iso3c = "JAM" if country == "Jamaica"
replace iso3c = "JPN" if country == "Japan"
replace iso3c = "JOR" if country == "Jordan"
replace iso3c = "KAZ" if country == "Kazakhstan"
replace iso3c = "KEN" if country == "Kenya"
replace iso3c = "KIR" if country == "Kiribati"
replace iso3c = "KOR" if country == "Korea"
replace iso3c = "KWT" if country == "Kuwait"
replace iso3c = "KGZ" if country == "KyrgyzRep"
replace iso3c = "LAO" if country == "LaoDem_Rep"
replace iso3c = "LVA" if country == "Latvia"
replace iso3c = "LBN" if country == "Lebanon"
replace iso3c = "LSO" if country == "Lesotho"
replace iso3c = "LBR" if country == "Liberia"
replace iso3c = "LBY" if country == "Libya"
replace iso3c = "LIE" if country == "Liechtesntein"
replace iso3c = "LTU" if country == "Lithuania"
replace iso3c = "LUX" if country == "Luxembourg"
replace iso3c = "MAC" if country == "Macao"
replace iso3c = "MKD" if country == "MacedoniaFYR"
replace iso3c = "MDG" if country == "Madagascar"
replace iso3c = "MWI" if country == "Malawi"
replace iso3c = "MYS" if country == "Malaysia"
replace iso3c = "MDV" if country == "Maldives"
replace iso3c = "MLI" if country == "Mali"
replace iso3c = "MLT" if country == "Malta"
replace iso3c = "MHL" if country == "MarshallIslands"
replace iso3c = "MRT" if country == "Mauritania"
replace iso3c = "MUS" if country == "Mauritius"
replace iso3c = "MEX" if country == "Mexico"
replace iso3c = "FSM" if country == "Micronesia"
replace iso3c = "MDA" if country == "Moldova"
replace iso3c = "MCO" if country == "Monaco"
replace iso3c = "MNG" if country == "Mongolia"
replace iso3c = "MNE" if country == "Montenegro"
replace iso3c = "MAR" if country == "Morocco"
replace iso3c = "MOZ" if country == "Mozambique"
replace iso3c = "MMR" if country == "Myanmar"
replace iso3c = "NAM" if country == "Namibia"
replace iso3c = "NPL" if country == "Nepal"
replace iso3c = "NLD" if country == "Netherlands"
replace iso3c = "ANT" if country == "NetherlandsAntilles"
replace iso3c = "NZL" if country == "NewZealand"
replace iso3c = "NIC" if country == "Nicaragua"
replace iso3c = "NER" if country == "Niger"
replace iso3c = "NGA" if country == "Nigeria"
replace iso3c = "NOR" if country == "Norway"
replace iso3c = "OMN" if country == "Oman"
replace iso3c = "PNG" if country == "PNG"
replace iso3c = "PAK" if country == "Pakistan"
replace iso3c = "PLW" if country == "Palau"
replace iso3c = "PAN" if country == "Panama"
replace iso3c = "PRY" if country == "Paraguay"
replace iso3c = "PER" if country == "Peru"
replace iso3c = "PHL" if country == "Philippines"
replace iso3c = "POL" if country == "Poland"
replace iso3c = "PRT" if country == "Portugal"
replace iso3c = "QAT" if country == "Qatar"
replace iso3c = "ROU" if country == "Romania"
replace iso3c = "RUS" if country == "Russia"
replace iso3c = "RWA" if country == "Rwanda"
replace iso3c = "WSM" if country == "Samoa"
replace iso3c = "SMR" if country == "SanMarino"
replace iso3c = "SAU" if country == "SaudiArabia"
replace iso3c = "SEN" if country == "Senegal"
replace iso3c = "SRB" if country == "SerbiaRep_of"
replace iso3c = "SYC" if country == "Seychelles"
replace iso3c = "SLE" if country == "SierraLeone"
replace iso3c = "SGP" if country == "Singapore"
replace iso3c = "SVK" if country == "SlovakRepublic"
replace iso3c = "SVN" if country == "Slovenia"
replace iso3c = "SLB" if country == "SolomonIslands"
replace iso3c = "SOM" if country == "Somalia"
replace iso3c = "ZAF" if country == "SouthAfrica"
replace iso3c = "ESP" if country == "Spain"
replace iso3c = "LKA" if country == "SriLanka"
replace iso3c = "LCA" if country == "StLucia"
replace iso3c = "KNA" if country == "St_Kittsand_Nevis"
replace iso3c = "SDN" if country == "Sudan"
replace iso3c = "SUR" if country == "Suriname"
replace iso3c = "SWZ" if country == "Swaziland"
replace iso3c = "SWE" if country == "Sweden"
replace iso3c = "CHE" if country == "Switzerland"
replace iso3c = "SYR" if country == "SyrianArab_Rep"
replace iso3c = "TJK" if country == "Tajikistan"
replace iso3c = "TZA" if country == "Tanzania"
replace iso3c = "THA" if country == "Thailand"
replace iso3c = "BHS" if country == "TheBahamas"
replace iso3c = "GMB" if country == "TheGambia"
replace iso3c = "TGO" if country == "Togo"
replace iso3c = "TON" if country == "Tonga"
replace iso3c = "TTO" if country == "TrinidadTobago"
replace iso3c = "TUN" if country == "Tunisia"
replace iso3c = "TUR" if country == "Turkey"
replace iso3c = "TKM" if country == "Turkmenistan"
replace iso3c = "ARE" if country == "UAE"
replace iso3c = "UGA" if country == "Uganda"
replace iso3c = "UKR" if country == "Ukraine"
replace iso3c = "GBR" if country == "UnitedKingdom"
replace iso3c = "USA" if country == "UnitedStates"
replace iso3c = "URY" if country == "Uruguay"
replace iso3c = "UZB" if country == "Uzbekistan"
replace iso3c = "VUT" if country == "Vanuatu"
replace iso3c = "VEN" if country == "Venezuela"
replace iso3c = "VNM" if country == "Vietnam"
replace iso3c = "PSE" if country == "West_Bankand_Gaza"
replace iso3c = "YEM" if country == "YemenRep_of"
replace iso3c = "ZMB" if country == "Zambia"
replace iso3c = "ZWE" if country == "Zimbabwe"

rename iso3c ISO 
drop country

drop if Year <= 1999
save "Data/Input/raw_input/FX_regime.dta", replace

merge 1:1 Year Month ISO using Data/Input/raw_input/FX_anchor.dta
keep if _merge == 3 | ISO == "AND"
drop _merge 

merge m:1 Year ISO using Data/Input/raw_input/NIIP.dta
drop _merge 

merge m:1 Year ISO using Data/Input/raw_input/KA_open.dta
drop _merge 

merge m:1 Year ISO using Data/Input/raw_input/fin_dev.dta
drop _merge

merge m:1 Year ISO using Data/Input/GDP_LCU_FX.dta
drop _merge

merge m:1 Year ISO using Data/Input/raw_input/POP_data_2025.dta 
drop _merge 

*gen PPPGDP_percapita = PPPGDP/POP
*gen LCUGDP_percapita = LCUGDP/POP

*drop if Year < 2000 
rename ISO country_code


keep country_code Year Month kaopen kaopen_norm LCUGDP PPPGDP POP FX_anchor fxUSD
save Data/Input/input_extended.dta, replace

   
use Data/Input/input_PPP_GDP_share_new.dta, replace
rename iso3c country_code 
rename year Year 
merge 1:m country_code Year using Data/Input/input_extended.dta, nogen

save Data/Input/input_macro.dta, replace


drop Month FX_anchor 
duplicates drop
save Data/Input/input_macro_short.dta, replace


*******************STEP 2: Calculate Section 1 & 2 stats ***********************


***Import liquidity lines list for country IDs
import excel "$liqlines", sheet("LiquidityLines") firstrow clear

***Keep only relevant variables
keep Helperpair start_date end_date ISO_source ISO_recipient initiative deal_type

/*
gen multilateral=0
replace multilateral=1 if deal_type=="pooled fund"
replace multilateral=1 if initiative == "SAARC"
replace multilateral=1 if initiative == "BRICS_CRA"
replace multilateral=1 if initiative == "CMIM"
*replace multilateral=1 if initiative == "CMI_BSA"
replace multilateral=1 if initiative == "ASEAN"
*replace multilateral=1 if initiative == "FIMA"
replace multilateral=1 if initiative == "Miyazawa"
keep if multilateral == 0 
drop initiative deal_type multilateral
*/

***Active lines end 2025
keep if start_date <= td(31dec2025) & end_date >= td(1dec2025)
drop start_date end_date
distinct Helperpair

keep ISO_recipient ISO_source
stack ISO_recipient ISO_source, into(ISO_combined) clear
drop _stack 

gduplicates drop 
distinct

/***Append Euro Area countries
*NB: no need in new data, actually merged correctly
save temp.dta, replace
***Import liquidity lines list for country IDs
import excel "Data\liquidity_lines.xlsx", sheet("EuroArea") firstrow clear 
keep country_code
rename country_code ISO_combined
append using temp.dta
erase temp.dta
*/

gduplicates drop 
***Generate the year column 
gen Year = 2025 
***Rename 
rename ISO_combined ISO 

***Merge with GDP 
*Doesn't merge monaco, vatican and kosovo which are ngligible 
*merge 1:1 Year ISO using Data/GDP_data_2025.dta

rename Year year 
rename ISO iso3c
merge 1:1 year iso3c using Data\Input\input_PPP_GDP_share_new.dta

rename year Year  
rename iso3c ISO 
rename GDP PPPGDP

keep if Year == 2025
egen total_GDP = total(PPPGDP)
gen GDP_share = PPPGDP/total_GDP

egen total_uncovered_GDP = total(PPPGDP) if _merge == 2
gen inactive_share = total_uncovered_GDP/total_GDP
gsort -inactive_share
replace inactive_share = inactive_share[_n-1] if mi(inactive_share)

egen active_GDP = total(PPPGDP) if _merge == 3
gen share = active_GDP/total_GDP

tab share

**************************

*Outreach Stats
* decrease in access if PBoc were to drop out 
* calculate outreach full network - outreach w/o PBoc for december 2025 


*SECTION 2: Stats

***Import liquidity lines list for country IDs
import excel "$liqlines", sheet("LiquidityLines") firstrow clear

***Section 2.2 characteristic
***share of swap vs repo
distinct deal_ID
	*1589 as of dec2024
	*1640 as of dec2025
distinct deal_ID if collateral == "swap"
	*1529 as of dec2024 
	*1570 as of dec2025
	
***share of pooled fund 
distinct deal_ID if deal_type == "pooled fund"
	*767 as of dec2024 and dec2025 (no change)

***bilateral share 
gen multilateral=0
replace multilateral=1 if deal_type=="pooled fund"
replace multilateral=1 if initiative == "SAARC"
replace multilateral=1 if initiative == "BRICS_CRA"
replace multilateral=1 if initiative == "CMIM"
*replace multilateral=1 if initiative == "CMI_BSA"
replace multilateral=1 if initiative == "ASEAN"
*replace multilateral=1 if initiative == "FIMA"
replace multilateral=1 if initiative == "Miyazawa"
distinct deal_ID if multilateral == 0 
	*802 as of dec2024
	*852 as of dec2025 

***non-pooled reciprocal 
distinct deal_ID if deal_type != "pooled fund"
distinct deal_ID if deal_type != "pooled fund" & deal_type == "reciprocal"
	*618/873 as of dec2025

	
	
	
	
	
	
********************************************************************************
********** 
*** Line Caps
**********

*NB: calculating committment share for pooled funds makes little sense by virtue of how data was recorded
*NB: BLR had major currency devaluation, results incorrect therefore

import excel "$liqlines", sheet("LiquidityLines") firstrow clear

gen multilateral=0
replace multilateral=1 if deal_type=="pooled fund"
replace multilateral=1 if initiative == "SAARC"
replace multilateral=1 if initiative == "BRICS_CRA"
replace multilateral=1 if initiative == "CMIM"
replace multilateral=1 if initiative == "ASEAN"
replace multilateral=1 if initiative == "Miyazawa"

***Keep key variables
keep collateral multilateral ISO* start_date end_date currency_of_deal source_currency_deal deal_currency_amount USD_amount unlimited deal_type Helperpair deal_ID 

***Generate year indicator 
gen Year = yofd(start_date)

***Amount in local currency whenever source_currency_deal & no other currency nominated
gen USD_deal = 1 
replace USD_deal = 0 if source_currency_deal == 1 & strpos(currency_of_deal, "USD") == 0

***convert amount to USD if non-USD line 
replace USD_amount = "" if USD_amount == "NA"
destring USD_amount, replace

replace deal_currency_amount = "" if deal_currency_amount == "NA"
destring deal_currency_amount, replace

******
***Merge GDP of source
******
rename ISO_source country_code
merge m:1 country_code Year using Data/Input/input_macro_short.dta, keepusing(fxUSD PPPGDP LCUGDP)
keep if _merge != 2
drop _merge 

***Reset naming convention
rename country_code ISO_source
replace USD_amount = fxUSD*deal_currency_amount if mi(USD_amount) & USD_deal == 0 

***calculate USD as share of source country GDP
gen cap_of_source = USD_amount/PPPGDP

drop *GDP fx*

******
***Merge GDP of recipient
******
rename ISO_recipient country_code
merge m:1 country_code Year using Data/Input/input_macro_short.dta, keepusing(fxUSD PPPGDP LCUGDP)
keep if _merge != 2
drop _merge 

***Reset naming convention
rename country_code ISO_recipient

***calculate USD as share of recipient country GDP
gen cap_of_recipient = USD_amount/PPPGDP

***calculate nominal GDP
gen NOMGDP = LCUGDP *fxUSD

***calculate nom GDP based cap 
gen cap_of_recipient_nom = USD_amount/NOMGDP
gen cap_pct = 100*cap_of_recipient_nom

***Drop Belarus bec outlier 
drop if ISO_source == "BLR"

***Sumstats or paper 
*NB: 	overall mean 2.5
sum cap_pct, detail

*NB: 	China mean 3.6
sum cap_pct if ISO_source =="CHN", detail

save Data/Interim/cap_data.dta, replace


*end of do-file
