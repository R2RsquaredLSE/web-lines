*************************** CIP Analysis **************************

/*
NB: This script prepares the CIP-distance panel, generates distribution plots,
and estimates CIP regressions/tables.

Inputs:
    - Data/Input/input_CIP_randomized.dta
    - Data/Interim/Paths.dta
    - Code/stata/LPM_charts.do
    - Code/stata/qreg_charts.do

Main outputs:
    - Output/temp/ecdf/xx.pdf
    - Output/tables/Table.tex
    - Output/tables/Table_alt_Boot2.tex
    - Output/tables/boot_percentiles.tex
*/

************************************************************************

*	STEP 1: Data Preparation

*	STEP 2: Generate Empirical CDF

*	STEP 3: LPM Regressions (archive block)

*	STEP 4: Panel Quantile Regressions (archive block)

*	STEP 5: Compile Regression Table No Bootstrap (archive block)

*	STEP 6: Compile Regression Table With Bootstrap

************************************************************************

************************************************************************
* Preliminaries
************************************************************************
***Set path
cd $root
set seed 1111

*****************************STEP 1: Data Preparation ******************

***Import CIP data
use Data/Input/input_CIP_randomized.dta, clear

***Drop China bec outlier
drop if country_code=="CHN_offshore" | country_code=="CHN"
replace country_code="CHN" if  country_code=="CHN_onshore" 
***Drop Andorra and San Marino bec use Euro (Duplicates EUR CIP)
drop if country_code == "AND" 
drop if country_code == "SMR"

***Merge to distance data
merge 1:1 Month Year country_code using Data/Interim/Paths.dta
drop _merge

***Generate time period identifier
egen period = group (Year Month)

***Tidy
cap drop country_ID
cap drop X

***Generate new country ID for event study 
egen country_ID=group(country_code)

***Order data
order country_ID period country_code Year Month Date dist_USA_bilateral dist_USA_all

**Set for event study
xtset country_ID period

***Cap distance at 5
replace dist_USA_bilateral	=5 	if dist_USA_bilateral==. 
replace dist_EA_bilateral	=5 	if dist_EA_bilateral==. 
replace dist_CHN_bilateral	=5 	if dist_CHN_bilateral==. 

***Remove CIP deviations of EA and China with oneself
foreach k in 1W 1M 3M 1Y{
	replace CIP_`k'_EA=. if dist_EA_bilateral==0
	replace CIP_`k'_CHN=. if dist_CHN_bilateral==0
}


*****************************STEP 2: Generate Empirical CDF ******************


preserve
drop if Year<2007

 winsor CIP_1M_USA, gen(CIP_1M_USA_W) p(0.001) lowonly
 winsor CIP_1M_USA_W,  gen(CIP_1M_USA_WW) p(0.02) highonly

 winsor CIP_3M_USA, gen(CIP_3M_USA_W) p(0.001) lowonly
 winsor CIP_3M_USA_W,  gen(CIP_3M_USA_WW) p(0.02) highonly

 
qui reghdfe CIP_1M_USA_WW, absorb(country_ID period) residuals(CIP_1M_USA_WW_res)
qui reghdfe CIP_3M_USA_WW, absorb(country_ID period) residuals(CIP_3M_USA_WW_res)
 
 
forvalues i=1/5{
cap drop ecd_`i'
cumul CIP_1M_USA_WW if dist_USA_bilateral==`i', gen(ecd_`i')
cumul CIP_1M_USA_WW_res if dist_USA_bilateral==`i', gen(ecd_`i'_res)
cumul CIP_3M_USA_WW if dist_USA_bilateral==`i', gen(ecd_`i'_3M)
cumul CIP_3M_USA_WW_res if dist_USA_bilateral==`i', gen(ecd_`i'_3M_res)
}
*

* Combine the higher order distribution
cumul CIP_1M_USA_WW if dist_USA_bilateral==3 | dist_USA_bilateral==4, gen(ecd_ho)
cumul CIP_1M_USA_WW_res if dist_USA_bilateral==3 | dist_USA_bilateral==4, gen(ecd_ho_res)
cumul CIP_3M_USA_WW if dist_USA_bilateral==3 | dist_USA_bilateral==4, gen(ecd_ho_3M)
cumul CIP_3M_USA_WW_res if dist_USA_bilateral==3 | dist_USA_bilateral==4, gen(ecd_ho_3M_res)


* Clean full plot - 3M
colorscheme 6, palette(YlGnBu )
twoway (line ecd_1_3M CIP_3M_USA_WW if dist_USA_bilateral==1 & CIP_3M_USA_WW>-6 & CIP_3M_USA_WW<-0.2 , sort lwidth(medthick) lcolor("`=r(color6)'")) ///
(line ecd_2_3M CIP_3M_USA_WW if dist_USA_bilateral==2 & CIP_3M_USA_WW>-6 & CIP_3M_USA_WW<-0.2, sort lwidth(medthick) lcolor("`=r(color5)'")) ///
(line ecd_ho_3M CIP_3M_USA_WW if (dist_USA_bilateral==3 | dist_USA_bilateral==4) & CIP_3M_USA_WW>-6 & CIP_3M_USA_WW<-0.2, sort lwidth(medthick) lcolor("`=r(color4)'")) ///
(line ecd_5_3M CIP_3M_USA_WW if dist_USA_bilateral==5 & CIP_3M_USA_WW>-6 & CIP_3M_USA_WW<-0.2, sort lwidth(medthick) lcolor("`=r(color2)'")), /// 
legend(order(1 "Direct connection" 2 "2nd order" 3 "Higher order" 4 "No connection")) legend(position(6) size(medlarge)) legend(rows(1)) xlabel(-6[2]0, labsize(medium)) ysc(r(0 0.6)) ylabel(0(0.2)0.6, labsize(medium))  ///
xtitle("3M IBOR CIP Deviation vs USD", size(medium)) ytitle("Empirical CDF", size(medium))
graph export "Output/temp/ecdf/clean_zoomed_ecdf_3M.pdf", replace
graph export "Output/temp/ecdf/clean_zoomed_ecdf_3M.eps", replace


* Clean full plot, residualised - 3M
colorscheme 6, palette(YlGnBu )
twoway (line ecd_1_3M_res CIP_3M_USA_WW_res if dist_USA_bilateral==1 & CIP_3M_USA_WW_res>-6 & CIP_3M_USA_WW_res<-0.2 , sort lwidth(medthick) lcolor("`=r(color6)'")) ///
(line ecd_2_3M_res CIP_3M_USA_WW_res if dist_USA_bilateral==2 & CIP_3M_USA_WW_res>-6 & CIP_3M_USA_WW_res<-0.2, sort lwidth(medthick) lcolor("`=r(color5)'")) ///
(line ecd_ho_3M_res CIP_3M_USA_WW_res if (dist_USA_bilateral==3 | dist_USA_bilateral==4) & CIP_3M_USA_WW_res>-6 & CIP_3M_USA_WW_res<-0.2, sort lwidth(medthick) lcolor("`=r(color4)'")) ///
(line ecd_5_3M_res CIP_3M_USA_WW_res if dist_USA_bilateral==5 & CIP_3M_USA_WW_res>-6 & CIP_3M_USA_WW_res<-0.2, sort lwidth(medthick) lcolor("`=r(color2)'")), /// 
legend(order(1 "Direct connection" 2 "2nd order" 3 "Higher order" 4 "No connection")) legend(position(6) size(medlarge)) legend(rows(1)) xlabel(-6[2]0, labsize(medium)) ysc(r(0 0.4)) ylabel(0(0.2)0.4, labsize(medium))  ///
xtitle("3M IBOR CIP Deviation vs USD", size(medium)) ytitle("Empirical CDF", size(medium))
graph export "Output/temp/ecdf/clean_zoomed_ecdf_residualised_3M.pdf", replace
graph export "Output/temp/ecdf/clean_zoomed_ecdf_residualised_3M.eps", replace

restore


************************* STEP 6: Compile Regression Table With Bootstrap ******
** Alternative estimators
set seed 1111

******
****** Regression table - alternative
******
drop if Year<2007

* combine 3rd and fourth order connections
gen categories_USA_bilateral = dist_USA_bilateral
replace categories_USA_bilateral=3 if dist_USA_bilateral==4
replace categories_USA_bilateral=4 if dist_USA_bilateral==5

* combine 3rd and fourth order connections
gen categories_EA_bilateral = dist_EA_bilateral
replace categories_EA_bilateral=3 if dist_EA_bilateral==4
replace categories_EA_bilateral=4 if dist_EA_bilateral==5

* combine 3rd and fourth order connections
gen categories_CHN_bilateral = dist_CHN_bilateral
replace categories_CHN_bilateral=3 if dist_CHN_bilateral==4
replace categories_CHN_bilateral=4 if dist_CHN_bilateral==5

set seed 1111
* Column 1
cap drop categories
gen categories=categories_USA_bilateral
cap drop CIP_res
qreg CIP_3M_USA i.categories, quantile(0.1) vce(robust)
cap drop CIP_res
mat robust_mat = r(table)[2..2,1..5]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col1
estadd scalar Quantile = 0.1
estadd local TimeFE  = "No"
estadd local CountryFE = "No"
*estadd local Method = "Canay(2011) quantile reg."
estadd local Counterparty= "US"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'


********** Bootstrap***********************************************************
* Set the number of bootstrap replications
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta_23 values

matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)


matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval i = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	
	cap drop categories
	gen categories=categories_USA_bilateral
	cap drop CIP_res
	qreg CIP_3M_USA i.categories, quantile(0.1) vce(robust)
	cap drop CIP_res
	matrix beta_out = e(b)

    * Store beta_23 in matrix
	
		
	matrix beta_1_store[1, `i'] = beta_out[1,2]
	matrix beta_2_store[1, `i'] = beta_out[1,3] 
	matrix beta_3_store[1, `i'] = beta_out[1,4] 
	
    matrix beta_23_store[1, `i'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `i'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}

mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))


mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :

st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])

st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col1
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'




	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se


estadd mat robust_see=robust_mat

***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col1_pct_zero_beta1",  pct1)
st_numscalar("col1_pct_zero_beta2",  pct2)
st_numscalar("col1_pct_zero_beta3",  pct3)
st_numscalar("col1_pct_zero_beta23", pct23)
st_numscalar("col1_pct_zero_beta24", pct24)
end

******************************



* Column 2: add time fixed effects
cap drop categories
gen categories=categories_USA_bilateral
cap drop CIP_res
qui reghdfe CIP_3M_USA i.categories, absorb(period) residuals(CIP_res)
matrix beta_out = e(b)
forvalues ii=2/4{
replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
}
qreg CIP_res i.categories, quantile(0.1) vce(robust)
mat robust_mat = r(table)[2..2,1..5]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col2
estadd scalar Quantile = 0.1
estadd local TimeFE  = "Yes"
estadd local CountryFE = "No"
*estadd local Method = "Canay(2011) quantile reg."
estadd local Counterparty= "US"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'




********** Bootstrap***********************************************************
* Set the number of bootstrap replications
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta_23 values

matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)


matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval i = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	cap drop categories
	gen categories=categories_USA_bilateral
	cap drop CIP_res
	qui reghdfe CIP_3M_USA i.categories, absorb(period) residuals(CIP_res)
	matrix beta_out = e(b)
	forvalues ii=2/4{
	replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
	}
	qreg CIP_res i.categories, quantile(0.1) vce(robust)
	matrix beta_out = e(b)

    * Store beta_23 in matrix
	
		
	matrix beta_1_store[1, `i'] = beta_out[1,2]
	matrix beta_2_store[1, `i'] = beta_out[1,3] 
	matrix beta_3_store[1, `i'] = beta_out[1,4] 
	
    matrix beta_23_store[1, `i'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `i'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}

mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))


mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :

st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])

st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col2
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'


	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se


estadd mat robust_see=robust_mat

***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col2_pct_zero_beta1",  pct1)
st_numscalar("col2_pct_zero_beta2",  pct2)
st_numscalar("col2_pct_zero_beta3",  pct3)
st_numscalar("col2_pct_zero_beta23", pct23)
st_numscalar("col2_pct_zero_beta24", pct24)
end

******************************


* Column 3: Quantile 0.15
cap drop CIP_res
qui reghdfe CIP_3M_USA i.categories, absorb(period) residuals(CIP_res)
matrix beta_out = e(b)
forvalues ii=2/4{
replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
}
qreg CIP_res i.categories, quantile(0.15) vce(robust)
mat robust_mat = r(table)[2..2,1..5]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col3
estadd scalar Quantile = 0.15
estadd local TimeFE  = "Yes"
estadd local CountryFE = "No"
*estadd local Method = "Canay(2011) quantile reg."
estadd local Counterparty= "US"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'


********** Bootstrap***********************************************************
* Set the number of bootstrap replications
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta_23 values

matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)


matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval i = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	cap drop CIP_res
	qui reghdfe CIP_3M_USA i.categories, absorb(period) residuals(CIP_res)
	matrix beta_out = e(b)
	forvalues ii=2/4{
	replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
	}
	qreg CIP_res i.categories, quantile(0.15) vce(robust)
	matrix beta_out = e(b)

    * Store beta_23 in matrix
		
	matrix beta_1_store[1, `i'] = beta_out[1,2]
	matrix beta_2_store[1, `i'] = beta_out[1,3] 
	matrix beta_3_store[1, `i'] = beta_out[1,4] 
	
    matrix beta_23_store[1, `i'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `i'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}


mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))

mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :

st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])

st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col3
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se

estadd local se_23=`see_23'
estadd local se_24=`see_24'

	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se


estadd mat robust_see=robust_mat

***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col3_pct_zero_beta1",  pct1)
st_numscalar("col3_pct_zero_beta2",  pct2)
st_numscalar("col3_pct_zero_beta3",  pct3)
st_numscalar("col3_pct_zero_beta23", pct23)
st_numscalar("col3_pct_zero_beta24", pct24)
end

******************************





* Column 4: Quantile 0.05
cap drop CIP_res
qui reghdfe CIP_3M_USA i.categories, absorb(period) residuals(CIP_res)
matrix beta_out = e(b)
forvalues ii=2/4{
replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
}
qreg CIP_res i.categories, quantile(0.05) vce(robust)
mat robust_mat = r(table)[2..2,1..5]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col4
estadd scalar Quantile = 0.05
estadd local TimeFE  = "Yes"
estadd local CountryFE = "No"
*estadd local Method = "Canay(2011) quantile reg."
estadd local Counterparty= "US"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'


********** Bootstrap***********************************************************
* Set the number of bootstrap replications
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta_23 values

matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)


matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval i = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	cap drop CIP_res
	qui reghdfe CIP_3M_USA i.categories, absorb(period) residuals(CIP_res)
	matrix beta_out = e(b)
	forvalues ii=2/4{
	replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
	}
	qreg CIP_res i.categories, quantile(0.05) vce(robust)
	matrix beta_out = e(b)

    * Store beta_23 in matrix
	
	matrix beta_1_store[1, `i'] = beta_out[1,2]
	matrix beta_2_store[1, `i'] = beta_out[1,3] 
	matrix beta_3_store[1, `i'] = beta_out[1,4] 

	
    matrix beta_23_store[1, `i'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `i'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}


mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))

mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :

st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])


st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col4
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'


	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se


estadd mat robust_see=robust_mat
***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col4_pct_zero_beta1",  pct1)
st_numscalar("col4_pct_zero_beta2",  pct2)
st_numscalar("col4_pct_zero_beta3",  pct3)
st_numscalar("col4_pct_zero_beta23", pct23)
st_numscalar("col4_pct_zero_beta24", pct24)
end

******************************





* Column 5: Euro Area
cap drop categories
gen categories=categories_EA_bilateral
cap drop CIP_res
qui reghdfe CIP_3M_EA i.categories, absorb(period) residuals(CIP_res)
matrix beta_out = e(b)
forvalues ii=2/4{
replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
}
qreg CIP_res i.categories, quantile(0.1) vce(robust)
mat robust_mat = r(table)[2..2,1..5]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col5
estadd scalar Quantile = 0.1
estadd local TimeFE  = "Yes"
estadd local CountryFE = "No"
*estadd local Method = "Canay(2011) quantile reg."
estadd local Counterparty= "Euro Area"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'


********** Bootstrap***********************************************************
* Set the number of bootstrap replications
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta_23 values

matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)


matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval i = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	cap drop categories
	gen categories=categories_EA_bilateral
	cap drop CIP_res
	qui reghdfe CIP_3M_EA i.categories, absorb(period) residuals(CIP_res)
	matrix beta_out = e(b)
	forvalues ii=2/4{
	replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
	}
	qreg CIP_res i.categories, quantile(0.1) vce(robust)
	matrix beta_out = e(b)

    * Store beta_23 in matrix
	matrix beta_1_store[1, `i'] = beta_out[1,2]
	matrix beta_2_store[1, `i'] = beta_out[1,3] 
	matrix beta_3_store[1, `i'] = beta_out[1,4] 

	
	
    matrix beta_23_store[1, `i'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `i'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}

mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))

mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :

st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])

st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col5
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'

	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se


estadd mat robust_see=robust_mat

***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col5_pct_zero_beta1",  pct1)
st_numscalar("col5_pct_zero_beta2",  pct2)
st_numscalar("col5_pct_zero_beta3",  pct3)
st_numscalar("col5_pct_zero_beta23", pct23)
st_numscalar("col5_pct_zero_beta24", pct24)
end

******************************




* Column 6: China
cap drop categories
gen categories=categories_CHN_bilateral
cap drop CIP_res
qui reghdfe CIP_3M_CHN i.categories, absorb(period) residuals(CIP_res)
matrix beta_out = e(b)

forvalues ii=2/4{
replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
}
qreg CIP_res i.categories, quantile(0.1) vce(robust)
mat robust_mat = r(table)[2..2,1..5]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col6
estadd scalar Quantile = 0.1
estadd local TimeFE  = "Yes"
estadd local CountryFE = "No"
*estadd local Method = "Canay(2011) quantile reg."
estadd local Counterparty= "China"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'


********** Bootstrap***********************************************************
* Set the number of bootstrap replications
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta_23 values
matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)


matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval i = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	cap drop categories
	gen categories=categories_CHN_bilateral
	cap drop CIP_res
	qui reghdfe CIP_3M_CHN i.categories, absorb(period) residuals(CIP_res)
	matrix beta_out = e(b)

	forvalues ii=2/4{
	replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
	}
	qreg CIP_res i.categories, quantile(0.1) vce(robust)
	matrix beta_out = e(b)
    * Store beta_23 in matrix
	matrix beta_1_store[1, `i'] = beta_out[1,2]
	matrix beta_2_store[1, `i'] = beta_out[1,3] 
	matrix beta_3_store[1, `i'] = beta_out[1,4] 

	
	
    matrix beta_23_store[1, `i'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `i'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}


mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))

mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :
st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])


st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col6
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'


	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se


estadd mat robust_see=robust_mat

***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col6_pct_zero_beta1",  pct1)
st_numscalar("col6_pct_zero_beta2",  pct2)
st_numscalar("col6_pct_zero_beta3",  pct3)
st_numscalar("col6_pct_zero_beta23", pct23)
st_numscalar("col6_pct_zero_beta24", pct24)
end

******************************


** Columns 8: LPM
set seed 1111
cap drop categories
gen categories=categories_USA_bilateral

cap drop cip_thres
gen cip_thres=0 if CIP_3M_USA!=.
replace cip_thres=1 if CIP_3M_USA<-1
reghdfe cip_thres i.categories if Year>2006, absorb(period) vce(robust) //cluster(country_ID period)
mat robust_mat = r(table)[2..2,1..5]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store LPM_2
estadd local CIPThreshold = -1
estadd local TimeFE  = "Yes"
estadd local CountryFE = "No"
estadd local Method = "LPM"
estadd local Counterparty= "US"
local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'


********** Bootstrap***********************************************************
* Set the number of bootstrap replications
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta_23 values

matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)



matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval i = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	
	cap drop cip_thres
	gen cip_thres=0 if CIP_3M_USA!=.
	replace cip_thres=1 if CIP_3M_USA<-1
	reghdfe cip_thres i.categories if Year>2006, absorb(period) vce(robust) //cluster(country_ID period)
	matrix beta_out = e(b)
    * Store beta_23 in matrix
	
	matrix beta_1_store[1, `i'] = beta_out[1,2]
	matrix beta_2_store[1, `i'] = beta_out[1,3] 
	matrix beta_3_store[1, `i'] = beta_out[1,4] 

    matrix beta_23_store[1, `i'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `i'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}


mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))



mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :
st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])


st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore LPM_2
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'


	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se


estadd mat robust_see=robust_mat

***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col8_pct_zero_beta1",  pct1)
st_numscalar("col8_pct_zero_beta2",  pct2)
st_numscalar("col8_pct_zero_beta3",  pct3)
st_numscalar("col8_pct_zero_beta23", pct23)
st_numscalar("col8_pct_zero_beta24", pct24)
end

******************************
** Columns 9: LPM
set seed 1111
cap drop cip_thres
gen cip_thres=0 if CIP_3M_USA!=.
replace cip_thres=1 if CIP_3M_USA<-2
reghdfe cip_thres i.categories if Year>2006, absorb(period) vce(robust) //cluster(country_ID period)
mat robust_mat = r(table)[2..2,1..5]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store LPM_4
estadd local CIPThreshold = -2
estadd local TimeFE  = "Yes"
estadd local CountryFE = "No"
estadd local Method = "LPM"
estadd local Counterparty= "US"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'


********** Bootstrap***********************************************************
* Set the number of bootstrap replications
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta_23 values

matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)

matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)


* Start the loop for bootstrap resampling
forval i = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	
	cap drop cip_thres
	gen cip_thres=0 if CIP_3M_USA!=.
	replace cip_thres=1 if CIP_3M_USA<-2
	reghdfe cip_thres i.categories if Year>2006, absorb(period) vce(robust) //cluster(country_ID period)
	matrix beta_out = e(b)
    * Store beta_23 in matrix
	matrix beta_1_store[1, `i'] = beta_out[1,2]
	matrix beta_2_store[1, `i'] = beta_out[1,3] 
	matrix beta_3_store[1, `i'] = beta_out[1,4] 

    matrix beta_24_store[1, `i'] = beta_out[1,4] - beta_out[1,2]
    matrix beta_23_store[1, `i'] = beta_out[1,3] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}


mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))


mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :
st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])


st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end



* Store standard error as a local
estimates restore LPM_4

local see_1: dis %10.3fc beta_1_se
local see_2: dis %10.3fc beta_2_se
local see_3: dis %10.3fc beta_3_se

local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se

estadd local se_23=`see_23'
estadd local se_24=`see_24'


	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se

estadd mat robust_see=robust_mat

***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col9_pct_zero_beta1",  pct1)
st_numscalar("col9_pct_zero_beta2",  pct2)
st_numscalar("col9_pct_zero_beta3",  pct3)
st_numscalar("col9_pct_zero_beta23", pct23)
st_numscalar("col9_pct_zero_beta24", pct24)
end

*/


***Bootstrapped regression table with normal and robust standard errors , without country FE
esttab qreg_col1 qreg_col2 qreg_col3 qreg_col4 qreg_col5 qreg_col6 LPM_* using Output/tables/Table_alt_Boot2.tex ///
, scalars(beta_23 se_23 beta_24 se_24 "N Obs" TimeFE Counterparty Quantile CIPThreshold) drop(1.categories _cons) ///
cells(b(fmt(3)) se(fmt(3) par) robust_see(fmt(3) par)) ///
star("+" 0.15 "*" 0.1 "**" 0.05 "***" 0.01) b(%10.3f) sfmt(%10.2f) replace

***Generate stars for bootstrapped regression
matrix pctile_mat = ( ///
    col1_pct_zero_beta1	,  col2_pct_zero_beta1	,col3_pct_zero_beta1	,col4_pct_zero_beta1	,col5_pct_zero_beta1	,col6_pct_zero_beta1 	,col8_pct_zero_beta1 	,col9_pct_zero_beta1	\ ///
    col1_pct_zero_beta2 ,  col2_pct_zero_beta2  ,col3_pct_zero_beta2  	,col4_pct_zero_beta2	,col5_pct_zero_beta2  	,col6_pct_zero_beta2 	,col8_pct_zero_beta2 	,col9_pct_zero_beta2 	\ ///
    col1_pct_zero_beta3 ,  col2_pct_zero_beta3  ,col3_pct_zero_beta3  	,col4_pct_zero_beta3	,col5_pct_zero_beta3  	,col6_pct_zero_beta3 	,col8_pct_zero_beta3 	,col9_pct_zero_beta3 	\ ///
    col1_pct_zero_beta23,  col2_pct_zero_beta23 ,col3_pct_zero_beta23 	,col4_pct_zero_beta23	,col5_pct_zero_beta23 	,col6_pct_zero_beta23	,col8_pct_zero_beta23	,col9_pct_zero_beta23	\ ///
    col1_pct_zero_beta24,  col2_pct_zero_beta24 ,col3_pct_zero_beta24 	,col4_pct_zero_beta24	,col5_pct_zero_beta24 	,col6_pct_zero_beta24 ,col8_pct_zero_beta24	,col9_pct_zero_beta24	)

esttab matrix(pctile_mat) using Output/tables/boot_percentiles.tex, replace


/*Note for stars used one sided test
Bootstrap p‐value rule:

  // Compute percentile of zero:
  //   P = 100 * (number of bootstrap draws ≤ 0) / B

  // One‐sided p‐values:
  //   If β̂ > 0:  p_one = 1 – P/100
  //   If β̂ < 0:  p_one =     P/100

  // Two‐sided p‐value:
  //   p_two = 2 * min(P/100, 1 – P/100)

Example:
  // zero at 98.5th percentile  →  P = 98.5
  // one‐sided for β̂ < 0:  p_one = 0.985
  // one‐sided for β̂ > 0:  p_one = 0.015
  // two‐sided:             p_two = 2 * 0.015 = 0.03
*/


