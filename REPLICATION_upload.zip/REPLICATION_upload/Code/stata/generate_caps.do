/*
NB: This script builds cap measures for liquidity-line agreements and prepares
cap-based inputs used by downstream MATLAB/Stata steps.

Inputs:
    - Data/liquidity_lines.xlsx (sheet: LiquidityLines)
    - Data/Input/input_macro_short.dta

Main outputs:
    - Data/Interim/cap_data.dta
    - Output/figures/cdf_cap_bilat_vs_multi_smooth_all.pdf

Workflow:
    - construct cap variables from deal-level liquidity-line data
    - produce summary statistics for the full and reciprocal-adjusted samples
    - generate the cap CDF figure by bilateral vs multilateral deals
*/

*NB: calculating committment share for pooled funds makes little sense by virtue of how data was recorded
*NB: BLR had major currency devaluation, results incorrect therefore

**************** STEP 1: Build Cap Dataset ***************************************

global liqlines "$root/Data/liquidity_lines.xlsx"
import excel "$liqlines", sheet("LiquidityLines") firstrow clear

gen multilateral=0
replace multilateral=1 if deal_type=="pooled fund"
replace multilateral=1 if initiative == "SAARC"
replace multilateral=1 if initiative == "BRICS_CRA"
replace multilateral=1 if initiative == "CMIM"
replace multilateral=1 if initiative == "ASEAN"
replace multilateral=1 if initiative == "Miyazawa"

***Keep key variables
keep collateral multilateral ISO* start_date end_date currency_of_deal source_currency_deal deal_currency_amount USD_amount unlimited deal_type Helperpair deal_ID 

***Generate year indicator 
gen Year = yofd(start_date)

***Amount in local currency whenever source_currency_deal & no other currency nominated
gen USD_deal = 1 
replace USD_deal = 0 if strpos(currency_of_deal, "USD") == 0 

***convert amount to USD if non-USD line 
replace USD_amount = "" if USD_amount == "NA"
destring USD_amount, replace

replace deal_currency_amount = "" if deal_currency_amount == "NA"
destring deal_currency_amount, replace

******
***Merge GDP of source
******
rename ISO_source country_code
merge m:1 country_code Year using Data/Input/input_macro_short.dta, keepusing(fxUSD PPPGDP LCUGDP)
keep if _merge != 2
drop _merge 

***Reset naming convention
rename country_code ISO_source
replace USD_amount = fxUSD*deal_currency_amount if mi(USD_amount) & USD_deal == 0 

***calculate USD as share of source country GDP
gen cap_of_source = USD_amount/PPPGDP

gen source_nom_gdp = LCUGDP *fxUSD
drop *GDP fx*


******
***Merge GDP of recipient
******
rename ISO_recipient country_code
merge m:1 country_code Year using Data/Input/input_macro_short.dta, keepusing(fxUSD PPPGDP LCUGDP)
keep if _merge != 2
drop _merge 

***Reset naming convention
rename country_code ISO_recipient
replace USD_amount = fxUSD*deal_currency_amount if mi(USD_amount) & USD_deal == 0 

***calculate USD as share of recipient country GDP
gen cap_of_recipient = USD_amount/PPPGDP

***calculate nominal GDP
gen NOMGDP = LCUGDP *fxUSD
gen recip_nom_gdp = LCUGDP *fxUSD

***calculate nom GDP based cap 
gen cap_of_recipient_nom = USD_amount/NOMGDP
gen cap_pct = 100*cap_of_recipient_nom

***Drop Belarus bec outlier 
drop if ISO_source == "BLR"

cd $root
save Data/Interim/cap_data.dta, replace

**************** STEP 2: Summary Statistics **************************************

***Sumstats or paper 
*NB: 	overall mean 2.43 med 1.34
sum cap_pct, detail
*		mean 2.21 median 0.78
sum cap_pct if multilateral == 0, detail
*		mean 2.64 median 1.98
sum cap_pct if multilateral == 1, detail


*NB: 	China mean 3.61 med 1.97 
sum cap_pct if ISO_source =="CHN", detail
*NB: 	EA mean 3.89 med 2.37 
sum cap_pct if ISO_source == "EA", detail
*NB: 	FEd mean 5.23 med 3.52 
sum cap_pct if ISO_source == "USA", detail

*NB: 	mean 2.82 med 1.81
sum cap_pct if ISO_recipient != "USA" & ISO_recipient != "CHN" & ISO_recipient != "EA", detail
*NB:	mean 2.77 med 1.75
sum cap_pct if ISO_recipient != "CHN", detail
*NB:	mean 0.15 med 0.05
sum cap_pct if ISO_recipient == "CHN" & multilateral == 0, detail
*		mean 0.25 med 0.27
sum cap_pct if ISO_recipient == "CHN" & multilateral == 1, detail
*--> majority of small lines due to China acting as recipient 

*** Calculate mean with only retaining largest participant 
*	NB: in reciprocal deals keep only the side where source is largest GDP country (lender line)
drop if recip_nom_gdp > source_nom_gdp &  deal_type == "reciprocal"

***Sumstats or paper 
*NB: 	overall mean 2.90 med 1.92
sum cap_pct, detail
*		mean 3.34 median 1.79
sum cap_pct if multilateral == 0, detail
*		mean 2.64 median 1.98
sum cap_pct if multilateral == 1, detail


*NB: 	China mean 3.66 med 1.99 
sum cap_pct if ISO_source =="CHN", detail
*NB: 	EA mean 4.21 med 2.59 
sum cap_pct if ISO_source == "EA", detail
*NB: 	FEd mean 5.23 med 3.52 
sum cap_pct if ISO_source == "USA", detail

*NB: 	mean 3.06 med 1.99
sum cap_pct if ISO_recipient != "USA" & ISO_recipient != "CHN" & ISO_recipient != "EA", detail
*NB:	mean 3.01 med 1.98
sum cap_pct if ISO_recipient != "CHN", detail
*NB:	mean 0.38 med 0.34
sum cap_pct if ISO_recipient == "CHN" & multilateral == 0, detail
*		mean 0.25 med 0.28
sum cap_pct if ISO_recipient == "CHN" & multilateral == 1, detail
*--> majority of small lines due to China acting as recipient 


**************** STEP 3: Cap Distribution Figure *********************************

use Data/Interim/cap_data.dta, replace
drop if recip_nom_gdp > source_nom_gdp &  deal_type == "reciprocal"

*keep if ISO_recipient != "USA" & ISO_recipient != "CHN" & ISO_recipient != "EA"
keep if !mi(cap_pct)

* Generate ranks within each group = empirical CDF
bysort multilateral (cap_pct): gen ecdf = _n / _N

lowess ecdf cap_pct if multilateral == 0 & cap_pct <= 10, gen(sm_bilat) bwidth(0.3) nograph
lowess ecdf cap_pct if multilateral == 1 & cap_pct <= 10, gen(sm_multi) bwidth(0.3) nograph

replace sm_bilat = max(0, min(1, sm_bilat))
replace sm_multi = max(0, min(1, sm_multi))

twoway (line sm_bilat cap_pct if multilateral == 0 & cap_pct <= 10, sort lcolor(navy) lwidth(medium)) ///
       (line sm_multi cap_pct if multilateral == 1 & cap_pct <= 10, sort lcolor(cranberry) lwidth(medium)), ///
    graphregion(color(white) margin(2 10 2 2)) ///
    ytitle("Cumulative probability", size(large)) ///
    xtitle("Cap as % of recipient nom GDP", size(large)) ///
    ylabel(0(0.2)1, labsize(medium)) ///
    xlabel(0(2)10, labsize(medium)) ///
    legend(order(1 "Bilateral" 2 "Multilateral") position(6) rows(1) size(medium))
graph export Output/figures/cdf_cap_bilat_vs_multi_smooth_all.pdf, replace
graph export Output/figures/cdf_cap_bilat_vs_multi_smooth_all.eps, replace
