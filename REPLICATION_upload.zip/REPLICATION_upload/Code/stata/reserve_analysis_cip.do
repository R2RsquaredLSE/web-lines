*************************** Reserve-CIP Event Study **************************

/*
NB: This script mirrors the reserve event-study pipeline while adding CIP
exposure to control-country matching and event estimation.

Inputs:
    - Data/Input/merged_CIP_reserve_data.dta
    - Data/Interim/Paths.dta
    - Data/Interim/liquidity_lines_stata.dta
    - Data/Input/GDP_data_2025.dta
    - Data/Input/POP_data_2025.dta
    - Data/Input/input_geodistance.dta

Main outputs:
    - Data/Interim/derived_reserves.dta
    - Data/Interim/reserve_working_file.dta
    - Data/event_investigation_*.dta
    - Output/figures/eventstudies/_*_CIP.pdf
    - Output/figures/eventstudies/regression_results_*.tex
*/

************************************************************************

*	STEP 1: Data Preparation

*	STEP 2: Generate Action Dummy

*	STEP 3: Standardize Reserve Measures

*	STEP 4: Generate Events

*	STEP 5: Reserve Event Study Plots (currently commented out)

*	STEP 6: Perform Stacked DiD for US Events with CIP Controls

************************************************************************

************************************************************************
* Preliminaries
************************************************************************
***Set path
cd $root

*
************************************************************************

************************************************************************
*STEP 1: Data Preparation 
************************************************************************

***Import new file
use "Data/Input/input_CIP_randomized.dta", clear
merge 1:1 country_code Year Month using "Data/Input/input_monthly_reserves.dta", nogen
keep Year Month reserves_total net_reserves SDRs reserve_import_ratio country_code goods_imports CIP_*3M_USA

* List of variables to process
local vars CIP_*3M_USA reserves_total net_reserves SDRs reserve_import_ratio goods_imports

* Loop through each variable and apply the operations
foreach var in `vars' {
    cap replace `var' = "" if `var' == "NA"
    destring `var', replace
}

***Generate new country ID for event study 
egen country_ID=group(country_code)

***Generate time period identifier
egen period = group (Year Month)

**Set for event study
xtset country_ID period

* interpolate reserves
replace reserves_total=0.5*(L.reserves_total+F.reserves_total) if reserves_total==. & L.reserves_total!=. & F.reserves_total!=.
replace reserve_import_ratio=reserves_total/goods_imports if reserve_import_ratio==.

***Merge to network distance data
merge 1:1 Month Year country_code using Data/Interim/Paths.dta
drop _merge
xtset

***Keep relevant variables only
cap drop ceiling* 

***Drop China bec outlier
drop if country_code=="CHN_offshore" | country_code=="CHN_onshore" | country_code == "CHN"

** drop Euro Area Countries bec aggregate Euro Area used instead
drop if country_code == "AUT"
drop if country_code == "FRA"
drop if country_code == "ITA"
drop if country_code == "DEU"
drop if country_code == "ESP"
drop if country_code == "NLD"
drop if country_code == "BEL"
drop if country_code == "PRT"
drop if country_code == "CYP"
drop if country_code == "FIN"
drop if country_code == "IRL"
drop if country_code == "LUX"
drop if country_code == "GRC"
drop if country_code == "SMR"
drop if country_code == "VCT"
drop if country_code == "MLT"
drop if country_code == "AND"
drop if country_code == "SVK"


***Order data
order country_ID period country_code Year Month dist_USA_bilateral dist_USA_all 
xtset country_ID period

***Generate indicators for countries never in network
bys country_ID: egen min_connection=min(dist_USA_bilateral)
gen never_connected = 0
replace never_connected = 1 if mi(min_connection)
drop min_connection

***Cap distance at 5
replace dist_USA_bilateral=5 if dist_USA_bilateral==. 
replace dist_EA_bilateral=5 if dist_EA_bilateral==. 
replace dist_CHN_bilateral=5 if dist_CHN_bilateral==. 


***Generate distance difference
gen Dconnect_us=D.dist_USA_bilateral
gen Dconnect_CHN=D.dist_CHN_bilateral
gen Dconnect_EA=D.dist_EA_bilateral

***Replace distance difference at start of observation period
replace Dconnect_us=0 if Dconnect_us==.
replace Dconnect_CHN=0 if Dconnect_CHN==.
replace Dconnect_EA=0 if Dconnect_EA==.

***Drop countries that never report reserves and recode country id
bys country_ID: egen min_reserves=min(reserve_import_ratio)
drop if min_reserves==.
drop min_reserves

***Recode country_id
drop country_ID
egen country_ID=group(country_code)

cap drop Date 
gen Date = mdy(Month, 1, Year)
format Date %td

***Save data with shocks
save Data/Interim/derived_reserves.dta, replace

************************************************************************
* STEP 2: Generate Action Dummy 
************************************************************************

** we derive four different sets of action dummies:
* 1) when the country provides a line as a source, either (i) bilaterally or (ii) any type incl multilateral.
* 2) when the country recieves a line as a recipient, either (i) bilaterally or (ii) any type incl multilateral.
* in the end, count receiving or giving any sort of line as the action

****************
**** Action based on the country being the source
***Import Data
use Data/Interim/liquidity_lines_stata.dta, clear

***Keep only the necessary columns
drop if multilateral == 1
drop if deal_action == "renew" 
keep ISO_source start_date

* Generate Year and Month columns from start_date
gen Year = year(start_date)
gen Month = month(start_date)

* Generate dummy variable for own_action
bys ISO_source Year Month: gen own_action_bilat_s = (_N > 0)
drop start_date

rename ISO_source country_code
duplicates drop 

***Merge with Initial Data
merge 1:1 Year Month country_code using Data/Interim/derived_reserves.dta
drop if _merge==1
drop _merge

***Save new reserves file
save Data/Interim/derived_reserves.dta, replace

***Repeat process for all (incl. multilateral)
***Import Data
use Data/Interim/liquidity_lines_stata.dta, clear

***Keep only the necessary columns/rows
drop if deal_action == "renew" 
keep ISO_source start_date

* Generate Year and Month columns from start_date
gen Year = year(start_date)
gen Month = month(start_date)

* Generate dummy variable for own_action
bys ISO_source Year Month: gen own_action_all_s = (_N > 0)
drop start_date

rename ISO_source country_code
duplicates drop 

***Merge with Initial Data
merge 1:1 Year Month country_code using Data/Interim/derived_reserves.dta
drop if _merge==1
drop _merge

save Data/Interim/derived_reserves.dta, replace

****************
**** Action based on the country being the recipient
***Import Data
use Data/Interim/liquidity_lines_stata.dta, clear

***Keep only the necessary columns
drop if multilateral == 1
drop if deal_action == "renew" 
keep ISO_recipient start_date

* Generate Year and Month columns from start_date
gen Year = year(start_date)
gen Month = month(start_date)

* Generate dummy variable for own_action
bys ISO_recipient Year Month: gen own_action_bilat_r = (_N > 0)
drop start_date

rename ISO_recipient country_code
duplicates drop 

***Merge with Initial Data
merge 1:1 Year Month country_code using Data/Interim/derived_reserves.dta
drop if _merge==1
drop _merge

***Save new reserves file
save Data/Interim/derived_reserves.dta, replace

***Repeat process for all (incl. multilateral)
***Import Data
use Data/Interim/liquidity_lines_stata.dta, clear

***Keep only the necessary columns/rows
drop if deal_action == "renew" 
keep ISO_recipient start_date

* Generate Year and Month columns from start_date
gen Year = year(start_date)
gen Month = month(start_date)

* Generate dummy variable for own_action
bys ISO_recipient Year Month: gen own_action_all_r = (_N > 0)
drop start_date

rename ISO_recipient country_code
duplicates drop 

***Merge with Initial Data
merge 1:1 Year Month country_code using Data/Interim/derived_reserves.dta
drop if _merge==1
drop _merge

xtset

egen own_action_all = rowmax(own_action_all_r own_action_all_s)

***Save new reserves file
save Data/Interim/derived_reserves.dta, replace


************************************************************************
* STEP 3: Standardize Reserve Measures 
************************************************************************

***MEASURE 1: Log reserve to import ratio
***Take logs
gen log_reserves_imports=log(reserve_import_ratio)

***MEASURE 2: total reserves
***Take logs
gen log_reserves=log(reserves_total)

***Save data with reserve measures
save Data/Interim/derived_reserves.dta, replace

************************************************************************
* STEP 4: Generate Events
************************************************************************

/* This code defines 12 events and creates dummy variables for their occurence */

use Data/Interim/derived_reserves.dta, clear

***Define shocks
run Code/stata/define_events.do 

***Save data with shocks
save Data/Interim/reserve_working_file.dta, replace

************************************************************************
* STEP 5: Perform Stacked DiD for US Events with CIP Controls
************************************************************************

use Data/Interim/reserve_working_file.dta, clear

* filter countries that never report CIP
bys country_code: egen cip_min = min(CIP_3M_USA) 
drop if cip_min ==.
drop cip_min

foreach jjj in improved_higher_connect_noown{

***Drop USA bec too large 
***Drop Myanmar bec major restructuring in reserve accounting in sample period 
use Data/Interim/reserve_working_file.dta, clear
drop if mi(period) & mi(reserves_total)

drop if country_code == "USA"
drop if country_code == "MMR"

gen log_imports = log(goods_imports)

gen shock=`jjj'

egen event_number = group(country_ID Date) if shock==1
qui sum event_number
local total_events=r(max)
di "number of events " `total_events' 
di "event type" `jjj'

** generate time series
global lag 12
global lead 18

** number of control countries
global control_number 4

forvalues kk=1(1)`total_events'{
********************************************************************************
preserve
** From here we focus on a specific event
gen shock_keep=0
replace shock_keep=1 if shock==1 & event_number==`kk'
gen shock_country2=country_ID if shock_keep==1 
egen shock_country=min(shock_country2) 
drop shock_country2
replace event_number=. if country_ID!=shock_country


gen time2 = 0 if shock_keep==1
forvalues i=1(1)$lead{
replace time=`i' if L`i'.shock_keep==1
}
*
forvalues i=1(1)$lag{
replace time2=-`i' if F`i'.shock_keep==1
}
*

bys Date: egen time=min(time2)
drop time2
drop if time==.

***** build control countries
* first determine country connections oer the event window
gen temp = dist_USA_bilateral if country_ID==shock_country & time==-$lag
egen shock_country_initial_connection = min(temp)
drop temp
bys country_ID: egen control_country_connection_mean=mean(dist_USA_bilateral)
bys country_ID: egen control_country_connection_min=min(dist_USA_bilateral)

* filter countries that never report CIP
bys country_code: egen cip_min = min(CIP_3M_USA) 
drop if cip_min ==.
drop cip_min


***Exclude as control countries that also move close or countries that start not at same level of connection
drop if (control_country_connection_min!=control_country_connection_mean) & shock_country!=country_ID

***Exclude always directly connected countries
drop if control_country_connection_mean==1


** calculate initial year
rename Year Year1
gen temp = Year if country_ID==shock_country & time==-$lag
egen Year = min(temp)
drop temp

*** Merge in GDP & POP
merge m:1 country_code Year using "Data/Input/input_macro_short.dta", keep(matched master) keepusing(PPPGDP POP)
drop _merge
replace PPPGDP=log(PPPGDP)
replace POP=log(POP)
drop Year
rename Year1 Year


*** merge in geographic distance
gen iso_o = country_code if shock_country==country_ID
replace iso_o="Z" if iso_o==""
sort iso_o
replace iso_o="" if iso_o=="Z"
carryforward iso_o, replace
xtset
gen iso_d = country_code
replace iso_d="ROM" if iso_d=="ROU"
replace iso_d="YUG" if iso_d=="SRB"
replace iso_d="YUG" if iso_d=="MNE"
replace iso_o="ROM" if iso_o=="ROU"
replace iso_o="YUG" if iso_o=="SRB"
replace iso_o="YUG" if iso_o=="MNE"

*cd $root
merge m:1 iso_o iso_d using "Data/Input/input_geodistance.dta", keep(matched master)
*drop if _merge==1
drop _merge
drop iso_d
replace distw=log(distw) if distw!=0
rename distw geodistw
rename iso_o shock_country_iso

** calculate country initial reserve to import ratio
gen temp = reserve_import_ratio if country_ID==shock_country & time==-$lag
egen shock_country_initial_rir = min(temp)
drop temp
gen temp = reserve_import_ratio if time==-$lag
bys country_code: egen initial_rir = min(temp)
drop temp

** calculate shock country initial GDP
gen temp = PPPGDP if country_ID==shock_country & time==-$lag
egen shock_country_GDP = min(temp)
drop temp

** calculate shock country initial POP
gen temp = POP if country_ID==shock_country & time==-$lag
egen shock_country_POP = min(temp)
drop temp

** calculate shock country internal distance
gen temp = geodistw if country_ID==shock_country & time==-$lag
egen shock_country_geodistw = min(temp)
drop temp

** calculate country initial UIP
gen temp = CIP_3M_USA if country_ID==shock_country & time==-$lag
egen shock_country_initial_cip = min(temp)
drop temp
gen temp = CIP_3M_USA if time==-$lag
bys country_code: egen initial_cip = min(temp)
drop temp


*** testing variable that will go to missing if any matching variables are missing for the shock country
gen test = shock_country_initial_rir + shock_country_GDP + shock_country_POP + shock_country_geodistw + shock_country_initial_cip

*** calculate distances
gen GDP_dist=PPPGDP-shock_country_GDP
gen POP_dist=POP-shock_country_POP
gen geo_dist=geodistw-shock_country_geodistw
gen rir_dist=initial_rir-shock_country_initial_rir
gen cip_dist=initial_cip-shock_country_initial_cip

replace GDP_dist=GDP_dist-POP_dist // convert to per capita gdp

*** normalise
foreach x in GDP_dist POP_dist geo_dist rir_dist cip_dist{
qui su `x'
replace `x'=`x'/r(sd)	
}
*

*** work out Euclidean distance_data
gen distance=(GDP_dist^2 + POP_dist^2 + geo_dist^2 + rir_dist^2 + cip_dist^2)^(1/2) if time==-$lag

if test[1]==.{
keep if country_ID==shock_country
gen drop_country=1
replace event_number = . if event_number !=`kk'
egen event_number2=min(event_number)
drop event_number
rename event_number2 event_number
drop shock_keep
drop PPPGDP POP geodistw shock_country_initial_rir initial_rir shock_country_GDP shock_country_POP shock_country_geodistw GDP_dist POP_dist geo_dist cip_dist rir_dist distance
xtset
save Data/reserve_events/event_number_`kk'.dta, replace
}
*
if test[1]!=.{
egen float temp2 = rank(distance), track
gen drop_country=0
bys country_ID: egen rir_rank=min(temp2)
drop temp*
keep if rir_rank<2+$control_number 
drop rir_rank	
drop shock_keep
replace event_number = . if event_number !=`kk'
egen event_number2=min(event_number)
drop event_number
rename event_number2 event_number
drop PPPGDP POP geodistw shock_country_initial_rir initial_rir shock_country_GDP shock_country_POP shock_country_geodistw GDP_dist POP_dist geo_dist cip_dist rir_dist distance
xtset
save Data/reserve_events/event_number_`kk'.dta, replace
}
*
********************************************************************************
restore
}
*
use Data/reserve_events/event_number_1.dta, clear
forvalues kk=2(1)`total_events'{
append using Data/reserve_events/event_number_`kk'.dta
}
*
drop test
save Data/event_`jjj'_cip.dta,replace

drop if drop_country==1

gen treated=1 if shock_country==country_ID
replace treated=0 if treated==.

gen time_regressor=time+$lag
forvalues i=1(1)$lag{
	cap drop lag`i' 
	gen lag`i'=0
	replace lag`i'=1 if treated==1 & time==-`i'
}
forvalues i=1(1)$lead{
	cap drop lead`i'
	gen lead`i'=0
	replace lead`i'=1 if treated==1 & time==`i'
}
*

global varlist lag$lag

display "$varlist"
display $lag

local lagstart=$lag-1
di `lagstart'
forvalues i=`lagstart'(-1)2{
	global varlist $varlist lag`i'	
}
*
global varlist $varlist shock	
*global varlist $varlist	

forvalues i=1(1)$lead{
	global varlist $varlist lead`i'	
}
*
display "$varlist"
*/
*

***Baseline regression 
reghdfe CIP_3M_USA $varlist log_imports, absorb(event_number#time_regressor event_number#country_ID) cluster(event_number#country_ID time_regressor) nocons

matrix beta_out = e(b)
matrix V_out = e(V)
local lagstart=$lag
cap drop zero_line
gen zero_line=0

** Baseline cofficients
cap drop beta
gen beta=.
cap drop se
gen se=.
forvalues i=1(1)$lag{
	replace beta = beta_out[1,`i'] if _n==`i'
	replace se = V_out[`i',`i']^(1/2) if _n==`i'
}
*
replace beta = 0 if _n==$lag
replace se = 0 if _n==$lag

replace beta = beta_out[1,$lag] if _n==1+$lag
replace se = V_out[$lag,$lag]^(1/2) if _n==1+$lag

forvalues i=1(1)$lead{
	local ii=`i'+$lag
	display `ii'		
	replace beta = beta_out[1,`ii'] if _n==1+`ii'
	replace se = V_out[`ii',`ii']^(1/2) if _n==1+`ii'
}
*


** CI for baseline 
cap drop ci*
gen ci_up=beta+1.64*se
gen ci_down=beta-1.64*se
gen ci_68up=beta+1*se
gen ci_68down=beta-1*se

cap drop beta_post beta_pre
gen beta_post = beta if time>-1
gen ci_up_post=beta+1.64*se if time>-1
gen ci_down_post=beta-1.64*se if time>-1
gen ci_68up_post=beta+1*se if time>-1
gen ci_68down_post=beta-1*se if time>-1

gen beta_pre = beta if time<-1
gen ci_up_pre=beta+1.64*se if time<-1
gen ci_down_pre=beta-1.64*se if time<-1
gen ci_68up_pre=beta+1*se if time<-1
gen ci_68down_pre=beta-1*se if time<-1



local x_low=-$lag
local x_high=$lead
twoway (rarea ci_68up_pre ci_68down_pre time, color(maroon)) || (rarea ci_68up_post ci_68down_post time, color(navy))  || (scatter ci_up_pre ci_down_pre beta_pre ci_up_post ci_down_post beta_post zero_line time, connect(l l l l l l l)  lwidth(thin thin thick thin thin thick vthin) lpattern(- - . - - . -) lcolor(maroon maroon cranberry navy navy dknavy gs0) msymbol(none none square none none square none) msize(medium medium medium medium medium medium medium) mcolor(gs0 gs0 cranberry gs0 gs0 dknavy)), graphregion(color(white)) ytitle("CIP Deviation %, versus USD") xtitle("months")  xlabel(`x_low'(6)`x_high') leg(off) xline(0, lwidth(vthin) lcolor(gs0))
graph export "Output/figures/eventstudies/_`jjj'_CIP.pdf", replace
graph export "Output/figures/eventstudies/_`jjj'_CIP.eps", replace

gen post=0
replace post=1 if time>=0
gen ATE=post*treated

reghdfe log_reserves ATE , absorb(event_number#time_regressor i.event_number#i.country_ID) cluster(event_number#country_ID time_regressor) nocons
}
*

*cd $root
forvalues kk=1(1)250{
sleep 20	
cap erase Data/reserve_events/event_number_`kk'.dta	
}
*


*end of do-file
