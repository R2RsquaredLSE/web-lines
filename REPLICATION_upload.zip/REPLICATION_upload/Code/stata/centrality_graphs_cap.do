*************************** Centrality Graphs (Cap Network) **************************

/*
NB: This script generates centrality figures for the bilateral network after
excluding small-cap lines.

Inputs:
    - Data/Interim/centrality_yes_USA_cap.xlsx
    - Data/Interim/centrality_yes_EA_cap.xlsx
    - Data/Interim/centrality_yes_CHN_cap.xlsx
    - Data/Interim/country_codes_ordered.dta
    - Data/Input/input_macro_short.dta (GDP)
    - Data/Interim/shortest_paths_YYYY_cap.csv

Main outputs:
    - Data/Interim/centrality_cap.dta
    - Data/Interim/all_shortest_paths_cap.dta
    - Cap-network centrality/intermediation/betweenness figures in Output/figures/
*/

************************************************************************

*	STEP 1:	Compile & Convert Data

*	STEP 2: Graph - Avg. Path Length 

*	STEP 3: Graph - Number of Countries Connected

*	STEP 4: Intermediation Graphs

*	STEP 5: Betweenness Graph
 

************************************************************************


********
*** Cap centrality
********
*****************************STEP 1: Compile & Convert Data ************

import excel "Data/Interim/centrality_yes_USA_cap.xlsx", firstrow clear
save Data/Interim/USA_centrality.dta, replace
import excel "Data/Interim/centrality_yes_EA_cap.xlsx", firstrow clear
save Data/Interim/EA_centrality.dta, replace
import excel "Data/Interim/centrality_yes_CHN_cap.xlsx", firstrow clear
save Data/Interim/CHN_centrality.dta, replace

merge 1:1 country_ID Year Month using Data/Interim/USA_centrality.dta
drop _merge
merge 1:1 country_ID Year Month using Data/Interim/EA_centrality.dta
drop _merge


merge m:1 country_ID using Data/Interim/country_codes_ordered.dta, keep(matched master)
drop _merge

gen date=mdy(Month,1,Year)
format date %td

save Data/Interim/centrality_cap.dta, replace




*****************************STEP 2: Graph - Avg. Path Length ************
*Merge to GDP data
merge m:1 country_code Year using Data/Input/input_macro_short.dta, keep(matched master) keepusing(GDP)
drop _merge
replace country_code = "EA" if country_code == "EUR"

*generate monthly total gdp & gdp share
bys date: egen date_GDP_USA = total(GDP) if country_code != "USA"
gen GDP_wgh_USA = GDP/date_GDP_USA
bys date: egen date_GDP_CHN = total(GDP) if country_code != "CHN"
gen GDP_wgh_CHN = GDP/date_GDP_CHN
bys date: egen date_GDP_EA = total(GDP) if country_code != "EA"
gen GDP_wgh_EA = GDP/date_GDP_EA

*** Graphs for avg path length - leave one out ---------------------------------

*Replace missing values with 5 (creates lower avg connection over time)
local countries USA CHN EA
foreach country of local countries {
    replace dist_`country' = 5 if missing(dist_`country')
    foreach other_country of local countries {
        if "`country'" != "`other_country'" {
            replace dist_`country'_wo`other_country' = 5 if missing(dist_`country'_wo`other_country')
        }
    }
}

*Calculate mean distance by date for each measure
local countries CHN EA USA
foreach country of local countries {
    foreach other_country of local countries {
        if "`country'" != "`other_country'" {
            bys date: egen mean_dist_`country'_wo`other_country' = mean(dist_`country'_wo`other_country') if country_code != "`country'"
			bys date: egen mean_dist_`country'_wo`other_country'_GDP = mean(dist_`country'_wo`other_country'*GDP_wgh_`country') if country_code != "`country'"
        }
    }
    bys date: egen mean_dist_`country' 		= mean(dist_`country') 			if country_code != "`country'"
	bys date: egen mean_dist_`country'_GDP 	= mean(dist_`country'*GDP_wgh_`country') 	if country_code != "`country'"
}


*Calculate distance difference
local countries CHN EA USA
foreach country of local countries {
    foreach other_country of local countries {
        if "`country'" != "`other_country'" {
            bys date: gen diff_`country'_wo`other_country' = mean_dist_`country' - mean_dist_`country'_wo`other_country'
			bys date: gen diff_`country'_wo`other_country'_GDP = mean_dist_`country'_GDP - mean_dist_`country'_wo`other_country'_GDP
        }
    }
}

*Calculate distance difference across all others (i.e. avg dist USA and EA w/o PBoC)
bys date: gen diff_woEA 		= 0.5*(diff_CHN_woEA + diff_USA_woEA)
bys date: gen diff_woCHN 		= 0.5*(diff_EA_woCHN + diff_USA_woCHN)
bys date: gen diff_woUSA 		= 0.5*(diff_CHN_woUSA + diff_EA_woUSA)

bys date: gen diff_woEA_GDP 	= 0.5*(diff_CHN_woEA_GDP + diff_USA_woEA_GDP)
bys date: gen diff_woCHN_GDP 	= 0.5*(diff_EA_woCHN_GDP + diff_USA_woCHN_GDP)
bys date: gen diff_woUSA_GDP    = 0.5*(diff_CHN_woUSA_GDP + diff_EA_woUSA_GDP)


**********
*** Shortest Path
**********

twoway (line mean_dist_USA mean_dist_EA  mean_dist_CHN date, lwidth(medthick medthick medthick) ), graphregion(margin(2 10 2 2)) xtitle("Date", size(large)) xlabel(,labsize(medium)) ytitle("Average path length",size(large)) ylabel(,labsize(medium)) legend(position(6)) legend(order(1 "FRB" 2 "ECB" 3 "PBoC") rows(1) size(medium))
graph export "Output/figures/shortest_path_cap.pdf", replace
graph export "Output/figures/shortest_path_cap.eps", replace

twoway (line mean_dist_USA_GDP mean_dist_EA_GDP  mean_dist_CHN_GDP date, lwidth(medthick medthick medthick) ), graphregion(margin(2 10 2 2)) xtitle("Date", size(large)) xlabel(,labsize(medium)) ytitle("Average GDP-weighted path length",size(large)) ylabel(,labsize(medium)) legend(position(6)) legend(order(1 "FRB" 2 "ECB" 3 "PBoC") rows(1) size(medium))
graph export "Output/figures/shortest_path_wgh_cap.pdf", replace
graph export "Output/figures/shortest_path_wgh_cap.eps", replace

**********
*** Shortest Path Difference
**********
* Averaged difference across two missing 
twoway (line diff_woUSA  diff_woEA diff_woCHN date, lwidth(medthick medthick medthick) ), graphregion(margin(2 10 2 2)) xtitle("Date", size(large)) xlabel(,labsize(medium)) ytitle("Average difference to baseline",size(large)) ylabel(,labsize(medium)) legend(position(6)) legend(order(1 "w/o FRB" 2 "w/o ECB" 3 "w/o PBoC") rows(1) size(medium))
graph export "Output/figures/bilateral_difference_avgpath_cap.pdf", replace
graph export "Output/figures/bilateral_difference_avgpath_cap.eps", replace

* Averaged difference across two missing 
twoway (line diff_woUSA_GDP  diff_woEA_GDP diff_woCHN_GDP date, lwidth(medthick medthick medthick) ), graphregion(margin(2 10 2 2)) xtitle("Date", size(large)) xlabel(,labsize(medium)) ytitle("Average difference to baseline",size(large)) ylabel(,labsize(medium)) legend(position(6)) legend(order(1 "w/o FRB" 2 "w/o ECB" 3 "w/o PBoC") rows(1) size(medium))
graph export "Output/figures/bilateral_difference_avgpath_wgh_cap.pdf", replace
graph export "Output/figures/bilateral_difference_avgpath_wgh_cap.eps", replace


*****************************STEP 3: Graph - Number of Countries Connected ************


use Data/Interim/centrality_cap.dta, replace
gen counter = 1

merge m:1 country_code Year using Data/Input/input_macro_short.dta, keep(matched master) keepusing(GDP)
drop _merge
replace country_code = "EA" if country_code == "EUR"


*Calculate countries connected by number and GDP coverage
* attention this is GDP with source USA
local countries CHN EA USA
foreach country of local countries {
    foreach other_country of local countries {
        if "`country'" != "`other_country'" {
            bys date: egen `country'_outreach_wo`other_country' = sum(counter) if !missing(dist_`country'_wo`other_country')
			bys date: egen `country'_outreachGDP_wo`other_country' = sum(GDP) if !missing(dist_`country'_wo`other_country')
        }
    }
    bys date: egen `country'_outreach = sum(counter) if !missing(dist_`country')
	bys date: egen `country'_outreachGDP = sum(GDP) if !missing(dist_`country')
}


*Calculate distance difference
local countries CHN EA USA
foreach country of local countries {
    foreach other_country of local countries {
        if "`country'" != "`other_country'" {
            bys date: gen diff_outreach_`country'_wo`other_country' = `country'_outreach - `country'_outreach_wo`other_country'
			bys date: gen diff_outreachGDP_`country'_wo`other_country' = `country'_outreachGDP - `country'_outreachGDP_wo`other_country'
        }
    }
}


twoway (line USA_outreach USA_outreach_woEA USA_outreach_woCHN date, lwidth(thick thick thick)), graphregion(margin(2 10 2 2)) xtitle("Date", size(large)) xlabel(,labsize(medium)) ytitle("Countries connected to USA",size(large)) ylabel(,labsize(medium)) legend(position(6)) legend(order(1 "baseline network" 2 "w/o ECB" 3 "w/o PBoC") rows(1) size(large))
graph export "Output/figures/bilateral_outreach_cap.pdf", replace
graph export "Output/figures/bilateral_outreach_cap.eps", replace

twoway (line USA_outreachGDP USA_outreachGDP_woEA USA_outreachGDP_woCHN date, yscale(range(0(20)100) axis(1)) lwidth(thick thick thick)), graphregion(margin(2 10 2 2)) xtitle("Date", size(large)) xlabel(,labsize(medium)) ytitle("Share GDP from countries connected to USA",size(large)) ylabel(,labsize(medium)) legend(position(6)) legend(order(1 "baseline network" 2 "w/o ECB" 3 "w/o PBoC") rows(1) size(large))
graph export "Output/figures/bilateral_outreachGDP_cap.pdf", replace
graph export "Output/figures/bilateral_outreachGDP_cap.eps", replace


********************************************************************************
* CURRENT VERSION February 13, 2026 

*****************************STEP 4: Intermediation Graphs ************

*** Figure 9a) 
*** Use centrality calculated using centrality_measures_v3.m 
*** For data continue using above measures

use Data/Interim/centrality_cap.dta, replace
gen counter = 1


merge m:1 country_code Year using Data/Input/input_macro_short.dta, keep(matched master) keepusing(GDP)
drop _merge
replace country_code = "EA" if country_code == "EUR"

**********
***Focusing on direct + indirect connections
**********


***Weigh intermediation by GDP share 
gen EA_inter_USA_wgh = (GDP/100)*EA_inter_USA
gen CHN_inter_USA_wgh = (GDP/100)*CHN_inter_USA
gen JPN_inter_USA_wgh = (GDP/100)*JPN_inter_USA
gen CHE_inter_USA_wgh = (GDP/100)*CHE_inter_USA

** By country sum totals
foreach j in EA CHE JPN CHN{
bys date: egen `j'_inter_USA_totalwgh = total(`j'_inter_USA_wgh)
}
*

***Generate indicator for connected countries
gen connected_USA = 0 
replace connected_USA = 1 if !mi(dist_USA) & dist_USA != 0 
gen wgh_connect_USA = connected_USA* (GDP/100)

bys date: egen total_USA_wgh = total(wgh_connect_USA)

** By country sum totals
foreach j in EA CHE JPN CHN{
bys date: gen `j'_inter_USA_share = `j'_inter_USA_totalwgh/total_USA_wgh
}
*

*** Graphs for intermediation
twoway (line EA_inter_USA_share CHN_inter_USA_share CHE_inter_USA_share JPN_inter_USA_share date, lwidth(thick thick thick thick thick)),graphregion(margin(2 10 2 2))  xtitle("Date",size(large)) xlabel(,labsize(medium)) ytitle("Shortest paths to USA",size(large)) ylabel(,labsize(medium)) legend(position(6)) legend(order(1 "via ECB" 2 "via PBoC" 3 "via SNB" 4 "via BoJ") rows(1) size(large))
graph export "Output/figures/bilateral_inter_to_USA_weighted_cap.pdf", replace
graph export "Output/figures/bilateral_inter_to_USA_weighted_cap.eps", replace



*************
*****Betweenness with cap size 
*************

*****************************STEP 5: Betweenness Graph ************


cd $root

***Loop over years, import, save as dta
forvalues year = 2000/2025 {
    import delimited "Data/Interim/shortest_paths_`year'_cap.csv", clear
    save "Data/Interim/shortest_paths_`year'.dta", replace
}

***Append all together
use "Data/Interim/shortest_paths_2000.dta", clear
forvalues year = 2001/2025 {
    append using "Data/Interim/shortest_paths_`year'.dta"
}

***Save combined file
save "Data/Interim/all_shortest_paths_cap.dta", replace
*save "Data/Interim/all_shortest_paths_cap_dynamic.dta", replace

***Delete individual dta files
forvalues year = 2000/2025 {
    erase "Data/Interim/shortest_paths_`year'.dta"
}


rename year Year 
rename month Month
rename path_start country_ID

merge m:1 country_ID using Data/Interim/country_codes_ordered.dta, keep(matched master)
drop _merge

rename country_code ISO_source
drop country_ID
rename path_end country_ID 
merge m:1 country_ID using Data/Interim/country_codes_ordered.dta, keep(matched master)
drop _merge country_ID
rename country_code ISO_recipient

***Generate intermediation dummies 
gen inter_EA = 0 
gen inter_CHN = 0 
gen inter_CHE = 0 
gen inter_JPN = 0 
gen inter_USA = 0 

replace inter_EA = 1 if strpos(path_sequence, "-17-") > 0
replace inter_CHN = 1 if strpos(path_sequence, "-14-") > 0
replace inter_CHE = 1 if strpos(path_sequence, "-53-") > 0
replace inter_JPN = 1 if strpos(path_sequence, "-24-") > 0
replace inter_USA = 1 if strpos(path_sequence, "-69-") > 0

***Calculate number of paths 
bys Year Month ISO_source ISO_recipient: gen num_paths = _N 
bys Year Month: gen total_paths = _N

***Scale intermediation by number of paths 
gen inter_EA_wgh = inter_EA/num_paths
gen inter_CHN_wgh = inter_CHN/num_paths
gen inter_CHE_wgh = inter_CHE/num_paths
gen inter_JPN_wgh = inter_JPN/num_paths
gen inter_USA_wgh = inter_USA/num_paths


***Quick Check: regular betweenness - correct
foreach j in EA CHE JPN CHN USA{
bys Year Month: egen total_inter_`j' = sum(inter_`j'_wgh)
}
*

drop path_sequence inter*wgh num_paths 

***Merge in GDP data 
rename ISO_source country_code
merge m:1 country_code Year using Data/Input/input_macro_short.dta, keep(matched master) nogen
rename country_code ISO_source 
rename GDP GDP_source
rename ISO_recipient country_code
merge m:1 country_code Year using Data/Input/input_macro_short.dta, keep(matched master) nogen
rename country_code ISO_recipient 
rename GDP GDP_recipient

***Generate match GDP share 
gen match_GDP = (GDP_source + GDP_recipient)/100

***Scale intermediation my match GDP
gen inter_EA_wgh_GDP  = inter_EA *match_GDP
gen inter_CHN_wgh_GDP = inter_CHN*match_GDP
gen inter_CHE_wgh_GDP = inter_CHE*match_GDP
gen inter_JPN_wgh_GDP = inter_JPN*match_GDP
gen inter_USA_wgh_GDP = inter_USA*match_GDP

***Quick Check: regular betweenness - correct
foreach j in EA CHE JPN CHN USA{
bys Year Month: egen total_GDP_inter_`j' = sum(inter_`j'_wgh_GDP)
}
*

***add GDP weighted betweenness
merge m:1 Year Month using Data/Interim/GDP_weights.dta, nogen

***express relative betweennes 
foreach j in EA CHE JPN CHN USA{
gen relative_btw_`j' = total_GDP_inter_`j'/total_wgh
}
*

gen date=mdy(Month,1,Year)
format %td date

twoway (line relative_btw_USA relative_btw_CHN relative_btw_EA relative_btw_JPN date, lwidth(thick thick thick thick thick)), graphregion(margin(2 10 2 2)) xtitle("Date", size(large)) xlabel(,labsize(medium)) ytitle("Betweenness Normalized",size(large)) ylabel(,labsize(medium)) legend(position(6)) legend(order(1 "FRB" 2 "PBoC" 3 "ECB" 4 "BoJ") rows(1) size(large))
graph display, ysize(6) xsize(10)
graph export "Output/figures/bilateral_betweenness_wgh_cap.pdf", replace
graph export "Output/figures/bilateral_betweenness_wgh_cap.eps", replace



