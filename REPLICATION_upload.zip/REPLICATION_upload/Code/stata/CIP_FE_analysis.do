*************************** CIP FE Analysis **************************

/*
NB: This script estimates CIP-distance regressions with fixed effects and
bootstrap inference for the main quantile table.

Inputs:
    - Data/Input/input_extended.dta
    - Data/Input/CountryCodes.dta
    - Data/Input/input_CIP_randomized.dta
    - Data/Interim/Paths.dta

Main outputs:
    - Data/Input/input_extended_clean.dta
    - Output/tables/Table_alt_Boot2.tex
    - Output/tables/boot_percentiles.tex
*/

************************************************************************

*	STEP 1: Data Preparation

*	STEP 2: FE Quantile Regressions and Bootstrap Tables

************************************************************************

************************************************************************
* Preliminaries
************************************************************************
***Set path

cd $root
set seed 1111
*****************************STEP 1: Data Preparation ******************

**** Prep the control database
use Data/Input/input_macro.dta, clear
sort country_code Year

*** some basic tidying
drop kaopen
rename kaopen_norm kaopen
drop if Year>2025
* Drop ZAF in 2000 because it is coded as USD-anchored; South Africa is free-floating thereafter.
drop if Year == 2000 & country_code=="ZAF" & FX_anchor == "USD"

*** Convert back to annual series
drop Month FX_anchor
duplicates drop
drop if country_code=="."
drop if country_code==""


*** Combine EURO AREA 
* gather countries
rename country_code iso3c 
merge m:1 iso3c using Data/Input/CountryCodes.dta, keep(matched master) 
drop iso2c Country
drop _merge 
rename iso3c country_code  

** recode the EA region in the data
replace PPPGDP=. if country_code=="EA"
replace Euroarea=1 if country_code=="EA"
** calculate aggregates and weights
bys Year: egen EURO_PPPGDP = sum(PPPGDP) if Euroarea ==1
bys Year: egen EURO_LCUGDP = sum(LCUGDP) if Euroarea ==1
bys Year: egen EURO_POP = sum(POP) if Euroarea ==1
gen euroweight = PPPGDP/EURO_PPPGDP if Euroarea ==1 & kaopen!=.
* replace aggregates as the region
*replace PPPGDP = EURO_PPPGDP if country_code=="EA"
*replace LCUGDP = EURO_LCUGDP if country_code=="EA"
replace POP = EURO_POP if country_code=="EA" 
* calculate weighted kopen
bys Year: egen EURO_rescale1 = sum(euroweight) if Euroarea ==1
replace euroweight=euroweight/EURO_rescale1
drop EURO_rescale1
gen EURO_kaopen_weight = euroweight *kaopen
bys Year: egen EURO_kaopen_wmean = sum(EURO_kaopen_weight) if Euroarea ==1
replace EURO_kaopen_wmean=. if EURO_kaopen_wmean==0
replace kaopen = EURO_kaopen_wmean if country_code=="EA" 
drop EURO* euroweight
* Drop other euroarea economies
drop if Euroarea==1 & country_code!="EA" 

* Define auxiliary variables
gen Ln_GDP = log(PPPGDP)
gen Ln_POP = log(POP)
gen Ln_GDPLCU = log(LCUGDP)

gen Ln_GDPPC=log(PPPGDP)-log(POP)
gen Ln_GDPPC_2=Ln_GDPPC^2
gen Ln_GDPNPC=log(LCUGDP)-log(POP)

gen Ln_RealFX=log(LCUGDP)-log(PPPGDP)

save Data/Input/input_extended_clean.dta, replace


***Import CIP data
use Data/Input/input_CIP_randomized.dta, clear

***Drop China bec outlier
drop if country_code=="CHN_offshore" | country_code=="CHN"
replace country_code="CHN" if  country_code=="CHN_onshore" 
***Drop Andorra and San Marino bec use Euro (Duplicates EUR CIP)
drop if country_code == "AND" 
drop if country_code == "SMR"

*** merge in controls
merge m:1 Year country_code using Data/Input/input_extended_clean.dta, keep(matched master)
drop _merge

***Merge to distance data
merge 1:1 Month Year country_code using Data/Interim/Paths.dta, keep(matched master)
drop _merge

***Generate time period identifier
egen period = group (Year Month)


***Tidy
cap drop country_ID
cap drop X

***Generate new country ID for event study 
egen country_ID=group(country_code)

***Order data
order country_ID period country_code Year Month Date dist_USA_bilateral dist_USA_all

**Set for event study
xtset country_ID period

***Cap distance at 5
replace dist_USA_bilateral	=5 	if dist_USA_bilateral==. 
replace dist_EA_bilateral	=5 	if dist_EA_bilateral==. 
replace dist_CHN_bilateral	=5 	if dist_CHN_bilateral==. 

***Remove CIP deviations of EA and China with oneself
foreach k in 1W 1M 3M 1Y{
	replace CIP_`k'_EA=. if dist_EA_bilateral==0
	replace CIP_`k'_CHN=. if dist_CHN_bilateral==0
}
*

*****************************STEP 2: FE Quantile Regressions and Bootstrap Tables ************

******
****** Regression table - alternative
******
drop if Year<2007

drop CIP_app*
drop *1W* *1M* *6M* *1Y* *2M*


* combine 3rd and fourth order connections
gen categories_USA_bilateral = dist_USA_bilateral
replace categories_USA_bilateral=3 if dist_USA_bilateral==4
replace categories_USA_bilateral=4 if dist_USA_bilateral==5

* combine 3rd and fourth order connections
gen categories_EA_bilateral = dist_EA_bilateral
replace categories_EA_bilateral=3 if dist_EA_bilateral==4
replace categories_EA_bilateral=4 if dist_EA_bilateral==5

* combine 3rd and fourth order connections
gen categories_CHN_bilateral = dist_CHN_bilateral
replace categories_CHN_bilateral=3 if dist_CHN_bilateral==4
replace categories_CHN_bilateral=4 if dist_CHN_bilateral==5



***************
** Column 1: Just country fixed effects
***************
cap drop categories
gen categories=categories_USA_bilateral
cap drop CIP_res
qui reghdfe CIP_3M_USA i.categories, absorb(country_ID) residuals(CIP_res)
matrix beta_out = e(b)

forvalues ii=2/4{
replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
}
qui qreg CIP_res i.categories, quantile(0.1) vce(robust)
mat robust_mat = r(table)[2..2,1..5]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col1
estadd scalar Quantile = 0.1
estadd local TimeFE  = "No"
estadd local CountryFE = "Yes"
estadd local Controls = "No"
*estadd local Method = "Canay(2011) quantile reg."
estadd local Counterparty= "US"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'


********** Bootstrap***********************************************************
* Set the number of bootstrap replications
set seed 1111
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta_23 values
matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)

matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval i = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	cap drop categories
	gen categories=categories_USA_bilateral
	cap drop CIP_res
	qui reghdfe CIP_3M_USA i.categories, absorb(country_ID) residuals(CIP_res)
	matrix beta_out = e(b)

	forvalues ii=2/4{
	replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
	}
	qui qreg CIP_res i.categories, quantile(0.1) vce(robust)
	matrix beta_out = e(b)
    * Store beta_23 in matrix
	
	matrix beta_1_store[1, `i'] = beta_out[1,2]
	matrix beta_2_store[1, `i'] = beta_out[1,3] 
	matrix beta_3_store[1, `i'] = beta_out[1,4] 

	matrix beta_23_store[1, `i'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `i'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}

mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))


mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :
st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])


st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col1
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'
	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se


estadd mat robust_see=robust_mat
***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col1_pct_zero_beta1",  pct1)
st_numscalar("col1_pct_zero_beta2",  pct2)
st_numscalar("col1_pct_zero_beta3",  pct3)
st_numscalar("col1_pct_zero_beta23", pct23)
st_numscalar("col1_pct_zero_beta24", pct24)
end

******************************

***************
** Column 2: Country Fe and Control for per capita income 
***************
local control_list "Ln_GDPNPC" 
cap drop categories
gen categories=categories_USA_bilateral
cap drop CIP_res
 reghdfe CIP_3M_USA `control_list' i.categories, absorb(country_code) residuals(CIP_res)
matrix beta_out = e(b)
local counter=1
foreach i in `control_list'{
replace CIP_res = CIP_res + beta_out[1,`counter']*`i'
local counter = `counter'+1
}
*
display `counter'
forvalues ii=2/4{
local jj = `ii' + `counter'	-1
replace CIP_res = CIP_res + beta_out[1,`jj'] if categories==`ii'
}
*
qui qreg CIP_res i.categories `control_list', quantile(0.1) vce(robust)

mat robust_mat = r(table)[2..2,1..6]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col2
estadd scalar Quantile = 0.1
estadd local TimeFE  = "No"
estadd local CountryFE = "Yes"
estadd local Controls = "Yes"
estadd local Counterparty= "US"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'

********** Bootstrap***********************************************************
* Set the number of bootstrap replications
set seed 1111
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta values
matrix beta_gdp_store = J(1, `B', .)

matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)

matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval zz = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	cap drop categories
	gen categories=categories_USA_bilateral
	cap drop CIP_res
	qui reghdfe CIP_3M_USA `control_list' i.categories, absorb(country_code) residuals(CIP_res)
	matrix beta_out = e(b)
	local counter=1
	foreach i in `control_list'{
	replace CIP_res = CIP_res + beta_out[1,`counter']*`i'
	local counter = `counter'+1
	}
	*
	display `counter'
	forvalues ii=2/4{
	local jj = `ii' + `counter'	-1
	replace CIP_res = CIP_res + beta_out[1,`jj'] if categories==`ii'
	}
	*
	qui qreg CIP_res i.categories `control_list', quantile(0.1) vce(robust)
	matrix beta_out = e(b)

    * Store beta_23 in matrix
	matrix beta_1_store[1, `zz'] = beta_out[1,2]
	matrix beta_2_store[1, `zz'] = beta_out[1,3] 
	matrix beta_3_store[1, `zz'] = beta_out[1,4] 

	matrix beta_gdp_store[1, `zz'] = beta_out[1,5]
	
	matrix beta_23_store[1, `zz'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `zz'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}

mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))

mata: beta_gdp_se = sqrt(variance(st_matrix("beta_gdp_store")'))

mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :

st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])

st_numscalar("beta_gdp_se", beta_gdp_se[1,1])

st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col2
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'

	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se
matrix robust_mat[1, 5] = beta_gdp_se

estadd mat robust_see=robust_mat

***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
bgdp = st_matrix("beta_gdp_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   	= sum(b1 :<= 0); 	pct1  = (n1   / cols(b1))  * 100
n2   	= sum(b2 :<= 0); 	pct2  = (n2   / cols(b2))  * 100
n3   	= sum(b3 :<= 0); 	pct3  = (n3   / cols(b3))  * 100
ngdp   	= sum(bgdp :<= 0); 	pctgdp  = (ngdp   / cols(bgdp))  * 100
n23  	= sum(b23:<= 0); 	pct23 = (n23  / cols(b23)) * 100
n24  	= sum(b24:<= 0); 	pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col2_pct_zero_beta1",  	pct1)
st_numscalar("col2_pct_zero_beta2",  	pct2)
st_numscalar("col2_pct_zero_beta3",  	pct3)
st_numscalar("col2_pct_zero_betagdp",  	pctgdp)
st_numscalar("col2_pct_zero_beta23", 	pct23)
st_numscalar("col2_pct_zero_beta24", 	pct24)
end

******************************

***************
** Column 3: Country Fe and Control for per capita income and capital account openess
***************
local control_list "Ln_GDPNPC kaopen" 
cap drop categories
gen categories=categories_USA_bilateral
cap drop CIP_res
qui reghdfe CIP_3M_USA `control_list' i.categories, absorb(country_code) residuals(CIP_res)
matrix beta_out = e(b)
local counter=1
foreach i in `control_list'{
replace CIP_res = CIP_res + beta_out[1,`counter']*`i'
local counter = `counter'+1
}
*
display `counter'
forvalues ii=2/4{
local jj = `ii' + `counter'	-1
replace CIP_res = CIP_res + beta_out[1,`jj'] if categories==`ii'
}
*
qui qreg CIP_res i.categories `control_list', quantile(0.1) vce(robust)

mat robust_mat = r(table)[2..2,1..6]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col3
estadd scalar Quantile = 0.1
estadd local TimeFE  = "No"
estadd local CountryFE = "Yes"
estadd local Controls = "Yes"
estadd local Counterparty= "US"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'

********** Bootstrap***********************************************************
* Set the number of bootstrap replications
set seed 1111
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta_23 values
matrix beta_gdp_store 	= J(1, `B', .)
matrix beta_ka_store 	= J(1, `B', .)

matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)

matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval zz = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	cap drop categories
	gen categories=categories_USA_bilateral
	cap drop CIP_res
	qui reghdfe CIP_3M_USA `control_list' i.categories, absorb(country_code) residuals(CIP_res)
	matrix beta_out = e(b)
	local counter=1
	foreach i in `control_list'{
	replace CIP_res = CIP_res + beta_out[1,`counter']*`i'
	local counter = `counter'+1
	}
	*
	display `counter'
	forvalues ii=2/4{
	local jj = `ii' + `counter'	-1
	replace CIP_res = CIP_res + beta_out[1,`jj'] if categories==`ii'
	}
	*
	qui qreg CIP_res i.categories `control_list', quantile(0.1) vce(robust)
	matrix beta_out = e(b)

    * Store beta_23 in matrix
	matrix beta_1_store[1, `zz'] = beta_out[1,2]
	matrix beta_2_store[1, `zz'] = beta_out[1,3] 
	matrix beta_3_store[1, `zz'] = beta_out[1,4] 

	matrix beta_gdp_store[1, `zz'] = beta_out[1,5]
	matrix beta_ka_store[1, `zz'] = beta_out[1,6]
	
	
    matrix beta_23_store[1, `zz'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `zz'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}

mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))

mata: beta_gdp_se = sqrt(variance(st_matrix("beta_gdp_store")'))
mata: beta_ka_se = sqrt(variance(st_matrix("beta_ka_store")'))

mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :

st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])

st_numscalar("beta_gdp_se", beta_gdp_se[1,1])
st_numscalar("beta_ka_se", beta_ka_se[1,1])

st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col3
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'

	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se
matrix robust_mat[1, 5] = beta_gdp_se
matrix robust_mat[1, 6] = beta_ka_se

estadd mat robust_see=robust_mat

***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
bgdp = st_matrix("beta_gdp_store")
bka = st_matrix("beta_ka_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
ngdp   	= sum(bgdp :<= 0); 	pctgdp  = (ngdp   / cols(bgdp))  * 100
nka   	= sum(bka :<= 0); 	pctka  = (nka   / cols(bka))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col3_pct_zero_beta1",  pct1)
st_numscalar("col3_pct_zero_beta2",  pct2)
st_numscalar("col3_pct_zero_beta3",  pct3)
st_numscalar("col3_pct_zero_betagdp",  	pctgdp)
st_numscalar("col3_pct_zero_betaka",  	pctka)
st_numscalar("col3_pct_zero_beta23", pct23)
st_numscalar("col3_pct_zero_beta24", pct24)
end

******************************
***************
** Column 4: Just controls no fixed effects
***************
cap drop categories
gen categories=categories_USA_bilateral
qui qreg CIP_3M_USA i.categories Ln_GDPNPC kaopen, quantile(0.1) vce(robust)
mat robust_mat = r(table)[2..2,1..7]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col4
estadd scalar Quantile = 0.1
estadd local TimeFE  = "No"
estadd local CountryFE = "No"
estadd local Controls = "Yes"
*estadd local Method = "Canay(2011) quantile reg."
estadd local Counterparty= "US"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'


********** Bootstrap***********************************************************
* Set the number of bootstrap replications
set seed 1111
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta values
matrix beta_gdp_store = J(1, `B', .)
matrix beta_ka_store = J(1, `B', .)

matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)

matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval i = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	cap drop categories
	gen categories=categories_USA_bilateral
	qui qreg CIP_3M_USA i.categories Ln_GDPNPC kaopen, quantile(0.1) vce(robust)
	matrix beta_out = e(b)
    * Store beta in matrix
	
	matrix beta_1_store[1, `i'] = beta_out[1,2]
	matrix beta_2_store[1, `i'] = beta_out[1,3] 
	matrix beta_3_store[1, `i'] = beta_out[1,4] 
	
	matrix beta_gdp_store[1, `i'] = beta_out[1,5]
	matrix beta_ka_store[1, `i'] = beta_out[1,6]

	matrix beta_23_store[1, `i'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `i'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}

mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))

mata: beta_gdp_se = sqrt(variance(st_matrix("beta_gdp_store")'))
mata: beta_ka_se = sqrt(variance(st_matrix("beta_ka_store")'))

mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :
st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])

st_numscalar("beta_gdp_se", beta_gdp_se[1,1])
st_numscalar("beta_ka_se", beta_ka_se[1,1])

st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col4
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'
	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se
matrix robust_mat[1, 5] = beta_gdp_se
matrix robust_mat[1, 6] = beta_ka_se


estadd mat robust_see=robust_mat
***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
bgdp = st_matrix("beta_gdp_store")
bka = st_matrix("beta_ka_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
ngdp   = sum(bgdp :<= 0); pctgdp  = (ngdp   / cols(bgdp))  * 100
nka   = sum(bka :<= 0); pctka  = (nka   / cols(bka))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col4_pct_zero_beta1",  pct1)
st_numscalar("col4_pct_zero_beta2",  pct2)
st_numscalar("col4_pct_zero_beta3",  pct3)
st_numscalar("col4_pct_zero_betagdp",  pctgdp)
st_numscalar("col4_pct_zero_betaka",  pctka)
st_numscalar("col4_pct_zero_beta23", pct23)
st_numscalar("col4_pct_zero_beta24", pct24)
end

******************************



***************
** Column 5: Country and time fixed effects no controls
***************
cap drop categories
gen categories=categories_USA_bilateral
cap drop CIP_res
qui reghdfe CIP_3M_USA i.categories, absorb(country_ID period) residuals(CIP_res)
matrix beta_out = e(b)

forvalues ii=2/4{
replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
}
qui qreg CIP_res i.categories, quantile(0.1) vce(robust)
mat robust_mat = r(table)[2..2,1..5]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col5
estadd scalar Quantile = 0.1
estadd local TimeFE  = "Yes"
estadd local CountryFE = "Yes"
estadd local Controls = "No"
*estadd local Method = "Canay(2011) quantile reg."
estadd local Counterparty= "US"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'

********** Bootstrap***********************************************************
* Set the number of bootstrap replications
set seed 1111
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta_23 values
matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)

matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval zz = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	cap drop categories
	gen categories=categories_USA_bilateral
	cap drop CIP_res
	qui reghdfe CIP_3M_USA i.categories, absorb(country_ID period) residuals(CIP_res)
	matrix beta_out = e(b)

	forvalues ii=2/4{
	replace CIP_res = CIP_res + beta_out[1,`ii'] if categories==`ii'
	}
	qui qreg CIP_res i.categories, quantile(0.1) vce(robust)
	matrix beta_out = e(b)
    * Store beta_23 in matrix
	
	matrix beta_1_store[1, `zz'] = beta_out[1,2]
	matrix beta_2_store[1, `zz'] = beta_out[1,3] 
	matrix beta_3_store[1, `zz'] = beta_out[1,4] 

	matrix beta_23_store[1, `zz'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `zz'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}

mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))

mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :
st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])


st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col5
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'
	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se

estadd mat robust_see=robust_mat
***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col5_pct_zero_beta1",  pct1)
st_numscalar("col5_pct_zero_beta2",  pct2)
st_numscalar("col5_pct_zero_beta3",  pct3)
st_numscalar("col5_pct_zero_beta23", pct23)
st_numscalar("col5_pct_zero_beta24", pct24)
end

******************************


***************
** Column 6: country time fixed effects and control for per capita income and capital account openess
***************
local control_list "Ln_GDPNPC kaopen" 
cap drop categories
gen categories=categories_USA_bilateral
cap drop CIP_res
qui reghdfe CIP_3M_USA `control_list' i.categories, absorb(country_code period) residuals(CIP_res)
matrix beta_out = e(b)
local counter=1
foreach i in `control_list'{
replace CIP_res = CIP_res + beta_out[1,`counter']*`i'
local counter = `counter'+1
}
*
display `counter'
forvalues ii=2/4{
local jj = `ii' + `counter'	-1
replace CIP_res = CIP_res + beta_out[1,`jj'] if categories==`ii'
}
*
qui qreg CIP_res i.categories `control_list', quantile(0.1) vce(robust)

mat robust_mat = r(table)[2..2,1..7]
matrix beta_out = e(b)
matrix V_out = e(V)
estimates store qreg_col6
estadd scalar Quantile = 0.1
estadd local TimeFE  = "Yes"
estadd local CountryFE = "Yes"
estadd local Controls = "Yes"
estadd local Counterparty= "US"

local betaa_23: dis %10.3fc beta_out[1,3]  - beta_out[1,2]
estadd local beta_23= `betaa_23'
local betaa_24: dis %10.3fc beta_out[1,4]  - beta_out[1,2]
estadd local beta_24= `betaa_24'

********** Bootstrap***********************************************************
* Set the number of bootstrap replications
set seed 1111
local B = 1000
cap drop panelsizee 

* Initialize matrix to store beta values
matrix beta_gdp_store = J(1, `B', .)
matrix beta_ka_store = J(1, `B', .)

matrix beta_1_store = J(1, `B', .)
matrix beta_2_store = J(1, `B', .)
matrix beta_3_store = J(1, `B', .)

matrix beta_23_store = J(1, `B', .)
matrix beta_24_store = J(1, `B', .)

* Start the loop for bootstrap resampling
forval zz = 1/`B' {
	preserve
    * Generate bootstrap sample
    bysort country_ID (period): gen panelsizee = _N
    bsample, cluster(country_ID) idcluster(newid) strata(panelsizee)

    * Run regressions
	cap drop categories
	gen categories=categories_USA_bilateral
	cap drop CIP_res
	qui reghdfe CIP_3M_USA `control_list' i.categories, absorb(country_code period) residuals(CIP_res)
	matrix beta_out = e(b)
	local counter=1
	foreach i in `control_list'{
	replace CIP_res = CIP_res + beta_out[1,`counter']*`i'
	local counter = `counter'+1
	}
	*
	display `counter'
	forvalues ii=2/4{
	local jj = `ii' + `counter'	-1
	replace CIP_res = CIP_res + beta_out[1,`jj'] if categories==`ii'
	}
	*
	qui qreg CIP_res i.categories `control_list', quantile(0.1) vce(robust)
	matrix beta_out = e(b)

    * Store beta in matrix
	matrix beta_1_store[1, `zz'] = beta_out[1,2]
	matrix beta_2_store[1, `zz'] = beta_out[1,3] 
	matrix beta_3_store[1, `zz'] = beta_out[1,4] 

	matrix beta_gdp_store[1, `zz'] = beta_out[1,5]
	matrix beta_ka_store[1, `zz'] = beta_out[1,6]
	
	
    matrix beta_23_store[1, `zz'] = beta_out[1,3] - beta_out[1,2]
    matrix beta_24_store[1, `zz'] = beta_out[1,4] - beta_out[1,2]

    * After each iteration, store the results or perform any desired operations
    * For example, you can store coefficients or standard errors in matrices for later analysis
	
	restore
}

mata: beta_1_se = sqrt(variance(st_matrix("beta_1_store")'))
mata: beta_2_se = sqrt(variance(st_matrix("beta_2_store")'))
mata: beta_3_se = sqrt(variance(st_matrix("beta_3_store")'))

mata: beta_gdp_se = sqrt(variance(st_matrix("beta_gdp_store")'))
mata: beta_ka_se = sqrt(variance(st_matrix("beta_ka_store")'))

mata: beta_23_se = sqrt(variance(st_matrix("beta_23_store")'))
mata: beta_24_se = sqrt(variance(st_matrix("beta_24_store")'))

mata :

st_numscalar("beta_1_se", beta_1_se[1,1])
st_numscalar("beta_2_se", beta_2_se[1,1])
st_numscalar("beta_3_se", beta_3_se[1,1])

st_numscalar("beta_gdp_se", beta_gdp_se[1,1])
st_numscalar("beta_ka_se", beta_ka_se[1,1])

st_numscalar("beta_23_se", beta_23_se[1,1])
st_numscalar("beta_24_se", beta_24_se[1,1])
end

* Store standard error as a local
estimates restore qreg_col6
local see_23: dis %10.3fc beta_23_se
local see_24: dis %10.3fc beta_24_se
estadd local se_23=`see_23'
estadd local se_24=`see_24'

	
matrix robust_mat[1, 2] = beta_1_se
matrix robust_mat[1, 3] = beta_2_se
matrix robust_mat[1, 4] = beta_3_se
matrix robust_mat[1, 5] = beta_gdp_se
matrix robust_mat[1, 6] = beta_ka_se


estadd mat robust_see=robust_mat

***Calculating percentiles of b = 0 for significance stars
***NB: gives pct of zero, equiv to p-val on one-sided hyp test against H0 of b = 0 
mata:

// Load each bootstrap draw matrix
b1 = st_matrix("beta_1_store")
b2 = st_matrix("beta_2_store")
b3 = st_matrix("beta_3_store")
bgdp = st_matrix("beta_gdp_store")
bka = st_matrix("beta_ka_store")
b23 = st_matrix("beta_23_store")
b24 = st_matrix("beta_24_store")

// Inline percentile-of-zero calculations
n1   = sum(b1 :<= 0); pct1  = (n1   / cols(b1))  * 100
n2   = sum(b2 :<= 0); pct2  = (n2   / cols(b2))  * 100
n3   = sum(b3 :<= 0); pct3  = (n3   / cols(b3))  * 100
ngdp   = sum(bgdp :<= 0); pctgdp  = (ngdp   / cols(bgdp))  * 100
nka   = sum(bka :<= 0); pctka  = (nka   / cols(bka))  * 100
n23  = sum(b23:<= 0); pct23 = (n23  / cols(b23)) * 100
n24  = sum(b24:<= 0); pct24 = (n24  / cols(b24)) * 100

// Save as Stata scalars
st_numscalar("col6_pct_zero_beta1",  pct1)
st_numscalar("col6_pct_zero_beta2",  pct2)
st_numscalar("col6_pct_zero_beta3",  pct3)
st_numscalar("col6_pct_zero_betagdp",  pctgdp)
st_numscalar("col6_pct_zero_betaka",  pctka)
st_numscalar("col6_pct_zero_beta23", pct23)
st_numscalar("col6_pct_zero_beta24", pct24)
end

******************************

esttab qreg_col1 qreg_col2 qreg_col3 qreg_col4 qreg_col5 qreg_col6 using Output/tables/Table_crossectionalvariation_Boot2.tex ///
, scalars(beta_23 se_23 beta_24 se_24 "N Obs" TimeFE CountryFE Counterparty Quantile CIPThreshold) drop(1.categories _cons) ///
cells(b(fmt(3)) se(fmt(3) par) robust_see(fmt(3) par)) ///
star("+" 0.15 "*" 0.1 "**" 0.05 "***" 0.01) b(%10.3f) sfmt(%10.2f) replace

***Generate stars for bootstrapped regression
matrix pctile_mat = ( ///
    col1_pct_zero_beta1	,  col2_pct_zero_beta1	,col3_pct_zero_beta1	,col4_pct_zero_beta1	,col5_pct_zero_beta1	,col6_pct_zero_beta1 	\ ///
    col1_pct_zero_beta2 ,  col2_pct_zero_beta2  ,col3_pct_zero_beta2  	,col4_pct_zero_beta2	,col5_pct_zero_beta2  	,col6_pct_zero_beta2 	\ ///
    col1_pct_zero_beta3 ,  col2_pct_zero_beta3  ,col3_pct_zero_beta3  	,col4_pct_zero_beta3	,col5_pct_zero_beta3  	,col6_pct_zero_beta3 	\ ///
			.			, col2_pct_zero_betagdp, col3_pct_zero_betagdp	,col4_pct_zero_betagdp	,		.				,col6_pct_zero_betagdp  \ ///
		.				, 				.		,col3_pct_zero_betaka	,col4_pct_zero_betaka	,		.				,col6_pct_zero_betaka   \ ///
    col1_pct_zero_beta23,  col2_pct_zero_beta23 ,col3_pct_zero_beta23 	,col4_pct_zero_beta23	,col5_pct_zero_beta23 	,col6_pct_zero_beta23	\ ///
    col1_pct_zero_beta24,  col2_pct_zero_beta24 ,col3_pct_zero_beta24 	,col4_pct_zero_beta24	,col5_pct_zero_beta24 	,col6_pct_zero_beta24	)

esttab matrix(pctile_mat) using Output/tables/boot_FE_percentiles.tex, replace



