*************************** LPM Chart Helper **************************

/*
NB: This helper script exports LPM threshold-comparison charts from already
prepared coefficient/SE variables in memory.

Required in-memory inputs:
    - beta_12 beta_13 beta_14 beta_23 beta_24
    - se_12 se_13 se_14 se_23 se_24
    - thres, zero_line
    - globals: root, chart_name
*/

************************************************************************

*	STEP 1: Plot 1st vs 2nd Order

*	STEP 2: Plot 1st vs Higher Order

*	STEP 3: Plot 1st vs No Connection

*	STEP 4: Plot 2nd vs Higher Order

*	STEP 5: Plot 2nd vs No Connection

************************************************************************

**************** STEP 1: Plot 1st vs 2nd Order *************************
cap drop beta
cap drop se
gen beta=beta_12
gen se=se_12
cap drop ci_*
gen ci_up=beta+1.64*se
gen ci_down=beta-1.64*se
gen ci_68up=beta+1*se
gen ci_68down=beta-1*se

cd Analysis/LPM/connection_12

twoway rarea ci_68up ci_68down thres, color(gs12)  || line ci_up beta ci_down zero_line thres,  lwidth(thin thick thin vthin) lpattern(- . - .) lcolor(gs1 gs0 gs1 gs0) graphregion(color(white)) legend(order(1 "68% CI" 2 "90% C.I." 3 "estimate")) xtitle("Basis Threshold")
graph export $chart_name, replace

cd $root

**************** STEP 2: Plot 1st vs Higher Order **********************
cap drop beta
cap drop se
gen beta=beta_13
gen se=se_13
cap drop ci_*
gen ci_up=beta+1.64*se
gen ci_down=beta-1.64*se
gen ci_68up=beta+1*se
gen ci_68down=beta-1*se

cd Analysis/LPM/connection_13

twoway rarea ci_68up ci_68down thres, color(gs12)  || line ci_up beta ci_down zero_line thres,  lwidth(thin thick thin vthin) lpattern(- . - .) lcolor(gs1 gs0 gs1 gs0) graphregion(color(white)) legend(order(1 "68% CI" 2 "90% C.I." 3 "estimate")) xtitle("Basis Threshold")
graph export $chart_name, replace

cd $root

**************** STEP 3: Plot 1st vs No Connection *********************
cap drop beta
cap drop se
gen beta=beta_14
gen se=se_14
cap drop ci_*
gen ci_up=beta+1.64*se
gen ci_down=beta-1.64*se
gen ci_68up=beta+1*se
gen ci_68down=beta-1*se

cd Analysis/LPM/connection_14

twoway rarea ci_68up ci_68down thres, color(gs12)  || line ci_up beta ci_down zero_line thres,  lwidth(thin thick thin vthin) lpattern(- . - .) lcolor(gs1 gs0 gs1 gs0) graphregion(color(white)) legend(order(1 "68% CI" 2 "90% C.I." 3 "estimate")) xtitle("Basis Threshold")
graph export $chart_name, replace

cd $root

**************** STEP 4: Plot 2nd vs Higher Order **********************
cap drop beta
cap drop se
gen beta=beta_23
gen se=se_23
cap drop ci_*
gen ci_up=beta+1.64*se
gen ci_down=beta-1.64*se
gen ci_68up=beta+1*se
gen ci_68down=beta-1*se

cd Analysis/LPM/connection_23

twoway rarea ci_68up ci_68down thres, color(gs12)  || line ci_up beta ci_down zero_line thres,  lwidth(thin thick thin vthin) lpattern(- . - .) lcolor(gs1 gs0 gs1 gs0) graphregion(color(white)) legend(order(1 "68% CI" 2 "90% C.I." 3 "estimate")) xtitle("Basis Threshold")
graph export $chart_name, replace

cd $root

**************** STEP 5: Plot 2nd vs No Connection *********************
cap drop beta
cap drop se
gen beta=beta_24
gen se=se_24
cap drop ci_*
gen ci_up=beta+1.64*se
gen ci_down=beta-1.64*se
gen ci_68up=beta+1*se
gen ci_68down=beta-1*se

cd Analysis/LPM/connection_24

twoway rarea ci_68up ci_68down thres, color(gs12)  || line ci_up beta ci_down zero_line thres,  lwidth(thin thick thin vthin) lpattern(- . - .) lcolor(gs1 gs0 gs1 gs0) graphregion(color(white)) legend(order(1 "68% CI" 2 "90% C.I." 3 "estimate")) xtitle("Basis Threshold")
graph export $chart_name, replace

cd $root
