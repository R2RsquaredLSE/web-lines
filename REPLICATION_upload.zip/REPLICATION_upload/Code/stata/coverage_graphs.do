*************************** Coverage Graphs **************************

/*
NB: This script generates coverage and distance-based figures used in the paper.

Inputs:
    - Data/Interim/stacked_adjacency_vectors.dta
    - Data/Interim/Paths.dta
    - Data/Input/input_macro_short.dta (GDP)

Main outputs:
    - Data/Interim/graphing_totallines.dta
    - Coverage line, scatter, and area figures in Output/figures/
*/

************************************************************************

*	STEP 1:	Generate Coverage Plotting Variables

*	STEP 2:	Line Graphs by Number / GDP (Sections 2.1-2.3)

*	STEP 3: Generate Distance Plotting Variables

*	STEP 4: Scatter Plots (Section 4.3)

*	STEP 5:	Area Graphs (Section 3.2)

************************************************************************



*****************************STEP 1: Generate Coverage Plotting Variables ************

***Import data
use Data/Interim/stacked_adjacency_vectors.dta, replace


gen connection_multi_only = 1 if connection_any == 1 & connection_bilat == 0 & connection_dual == 0
replace connection_multi_only = 0 if connection_any != 1 | connection_bilat != 0 | connection_dual != 0

gen connection_multi = 1 if connection_any == 1 & (connection_multi_only == 1 | connection_dual == 1)
replace connection_multi = 0 if connection_any != 1 | (connection_multi_only != 1 & connection_dual != 1)

gen connection_bilat_only = 1 if connection_bilat == 1 & connection_dual == 0
replace connection_bilat_only = 0 if connection_bilat != 1 | connection_dual != 0

gen connection_multi2 = 1 if connection_any == 1 & connection_bilat_only == 0
replace connection_multi2 = 0 if connection_any != 1 | connection_bilat_only != 0



** number of agreements: 
bys date: egen bilat_connections = sum(connection_bilat)
replace bilat_connections = bilat_connections/2

bys date: egen multi_connections = sum(connection_multi2)
replace multi_connections = multi_connections/2

bys date: egen all_connections = sum(connection_any)
replace all_connections = all_connections/2

bys date: egen multi_only_connections = sum(connection_multi_only)
replace multi_only_connections = multi_only_connections/2

bys date: egen dual_connections = sum(connection_dual)
replace dual_connections = dual_connections/2

bys date: egen bilat_only_connections = sum(connection_bilat_only)
replace bilat_only_connections = bilat_only_connections/2



** GDP shares
gen bilat_connections_GDP=connection_bilat*GDP
gen multi_connections_GDP=connection_multi_only*GDP
gen all_connections_GDP=connection_any*GDP
gen bilat_only_connections_GDP=connection_bilat_only*GDP
gen dual_connections_GDP=connection_dual*GDP

*recipient country count (incoming connections per recipient)
bys date recipient_id: egen recipient_count_bilat = sum(connection_bilat)
bys date recipient_id: egen recipient_count_multi = sum(connection_multi_only)
bys date recipient_id: egen recipient_count_any = sum(connection_any)
bys date recipient_id: egen recipient_count_bilat_only = sum(connection_bilat_only)
bys date recipient_id: egen recipient_count_dual = sum(connection_dual)


* coverage (divide by recipient count here to avoid double counting if country has multiple connections incoming)
bys date: egen total_connections_bilat_GDP = 	sum(bilat_connections_GDP/recipient_count_bilat)
bys date: egen total_connections_multi_GDP = 	sum(multi_connections_GDP/recipient_count_multi)
bys date: egen total_connections_all_GDP = 		sum(all_connections_GDP/recipient_count_any)
bys date: egen total_connections_bilat_only_GDP = 		sum(bilat_only_connections_GDP/recipient_count_bilat_only)
bys date: egen total_connections_dual_GDP = 		sum(dual_connections_GDP/recipient_count_dual)



** By country (any connection)
foreach j in USA EA CHN{
bys date: egen `j'_connections_any2 = sum(connection_any) if ISO_source=="`j'"
bys date recipient_id: egen `j'_recipient_count_any = sum(connection_any) if ISO_source=="`j'"
bys date: egen `j'_connections_any_GDP2 = sum(all_connections_GDP/`j'_recipient_count_any) if ISO_source=="`j'"

bys date: egen `j'_connections_any = min(`j'_connections_any2)
bys date: egen `j'_connections_any_GDP = min(`j'_connections_any_GDP2)

drop `j'_connections_any_GDP2 `j'_connections_any2
}
*
save Data/Interim/graphing_totallines.dta, replace

use Data/Interim/graphing_totallines.dta, replace

*****************************STEP 2: Line Graphs by number / GDP  ************


* total connections line number
twoway (line all_connections date if date < date("01Jan2026","DMY") & date >= date("01Jan2000","DMY"), yscale(range(0(50)200) axis(1)) lwidth(thick) lcolor(navy)), graphregion(color(white) margin(2 10 2 2))  xtitle(date, size(large)) ytitle(Number of connections, size(large)) ylabel(,labsize(medium)) xtitle(Date, size(large)) xlabel(,labsize(medium))
graph export "Output/figures/single_TotalConnections.pdf", replace
graph export "Output/figures/single_TotalConnections.eps", replace

* total connections GDP
twoway (line total_connections_all_GDP date if date < date("01Jan2026","DMY") & date >= date("01Jan2000","DMY"),yscale(range(0(20)80) axis(1)) lwidth(thick) lcolor(navy)), graphregion(color(white) margin(2 10 2 2))  xtitle(date, size(large)) ytitle(Share of world GDP, size(large)) ylabel(0(20)80,labsize(medium)) xtitle(Date, size(large))  xlabel(,labsize(medium))
graph export "Output/figures/single_TotalConnections_GDP.pdf", replace
graph export "Output/figures/single_TotalConnections_GDP.eps", replace


* total connections: by currency
graph twoway (line USA_connections_any EA_connections_any CHN_connections_any date if date < date("01Jan2026","DMY") & date >= date("01Jan2000","DMY"), lwidth(thick thick thick) lcolor(navy red green)), graphregion(color(white) margin(2 10 2 2))  xtitle(date, size(large)) ytitle(Number of connections, size(large)) ylabel(,labsize(medium)) xtitle(Date, size(large)) xlabel(,labsize(medium)) legend(order(1 "FRB" 2 "ECB" 3 "PBOC") rows(1) position(6) size(large))
graph export "Output/figures/single_TotalConnections_bycurrency.pdf", replace
graph export "Output/figures/single_TotalConnections_bycurrency.eps", replace

* total connections: by currency
graph twoway (line USA_connections_any_GDP EA_connections_any_GDP CHN_connections_any_GDP date if date < date("01Jan2026","DMY") & date >= date("01Jan2000","DMY"), lwidth(thick thick thick) lcolor(navy red green)), graphregion(color(white) margin(2 10 2 2))  xtitle(date, size(large)) ytitle(Share of world GDP, size(large)) ylabel(,labsize(medium)) xtitle(Date, size(large)) xlabel(,labsize(medium)) legend(order(1 "FRB" 2 "ECB" 3 "PBOC") rows(1) position(6) size(large))
graph export "Output/figures/single_TotalConnections_bycurrency_GDP.pdf", replace
graph export "Output/figures/single_TotalConnections_bycurrency_GDP.eps", replace

* total connections: by type
twoway (line bilat_only_connections multi_only_connections date if date < date("01Jan2026","DMY") & date >= date("01Jan2000","DMY"), yscale(range(0(20)120) axis(1)) lwidth(thick thick) lcolor(navy red)), graphregion(color(white) margin(2 10 2 2)) xtitle(date, size(large)) ytitle(Number of connections, size(large)) ylabel(0(20)120,labsize(medium)) xtitle(Date, size(large)) xlabel(,labsize(medium)) legend(order(1 "Bilateral" 2 "Multilateral") rows(1) position(6) size(large))
graph export "Output/figures/single_TotalConnections_bytype.pdf", replace
graph export "Output/figures/single_TotalConnections_bytype.eps", replace

* total GDP: by type
twoway (line total_connections_bilat_only_GDP total_connections_multi_GDP  date if date < date("01Jan2026","DMY") & date >= date("01Jan2000","DMY"), yscale(range(0(10)80) axis(1)) lwidth(thick thick) lcolor(navy red)), graphregion(color(white) margin(2 10 2 2))  xtitle(date, size(large)) ytitle(Share of world GDP, size(large)) ylabel(0(10)80,labsize(medium)) xtitle(Date, size(large)) xlabel(,labsize(medium)) legend(order(1 "Bilateral" 2 "Multilateral") rows(1) position(6) size(large))
graph export "Output/figures/single_TotalConnections_bytype_GDP.pdf", replace
graph export "Output/figures/single_TotalConnections_bytype_GDP.eps", replace



*****************************STEP 3: Generate Distance Plotting Variables ************

***Import data
use Data/Interim/Paths.dta, replace
replace country_code = "CHN" if country_code == "CHN_onshore"
merge m:1 country_code Year using Data/Input/input_macro_short.dta, keep(matched master) keepusing(GDP)
drop _merge
replace GDP=0 if GDP==.
gen date=mdy(Month,1,Year)
format date %td

sort country_ID date

preserve

foreach j in USA CHN EA{
	cap drop ceiling_`j'_mean
	bys dist_`j'_bilateral: egen ceiling_`j'_mean_bilat=mean(ceiling_`j'_bilateral)
	replace ceiling_`j'_mean_bilat=. if ceiling_`j'_mean_bilat==0
	bys dist_`j'_all: egen ceiling_`j'_mean_all=mean(ceiling_`j'_all)
	replace ceiling_`j'_mean_all=. if ceiling_`j'_mean_all==0
}

keep dist* ceiling*
drop ceiling_USA_bilateral ceiling_EA_bilateral ceiling_CHN_bilateral ceiling_USA_all ceiling_EA_all ceiling_CHN_all
duplicates drop


*****************************STEP 4: Scatter Plots ************

sort dist_USA_bilateral dist_EA_bilateral dist_CHN_bilateral

twoway (scatter ceiling_USA_mean_bilat dist_USA_bilateral if dist_USA_bilateral<5, msymbol(square) msize(large)) (scatter ceiling_EA_mean_bilat dist_EA_bilateral if dist_EA_bilateral<5 , msize(large)) (scatter ceiling_CHN_mean_bilat dist_CHN_bilateral if dist_CHN_bilateral<5, msymbol(diamond) msize(large)), ytitle("average implicit ceiling (bp)") legend(order(1 "FRB" 2 "ECB" 3 "China") size(medlarge)  position(6) rows(1))  xtitle("network distance")
graph display, ysize(6) xsize(10)
graph export "Output/figures/ceiling_distance_scatter3.pdf", replace
graph export "Output/figures/ceiling_distance_scatter3.eps", replace


sort dist_USA_all dist_EA_all dist_CHN_all

twoway (scatter ceiling_USA_mean_all dist_USA_all if dist_USA_all<5, msymbol(square) msize(large)) (scatter ceiling_EA_mean_all dist_EA_all if dist_EA_all<5 , msize(large)) (scatter ceiling_CHN_mean_all dist_CHN_all if dist_CHN_all<5, msymbol(diamond) msize(large)), ytitle("average implicit ceiling (bp)") legend(order(1 "FRB" 2 "ECB" 3 "China") size(medlarge)  position(6) rows(1))  xtitle("network distance")
graph display, ysize(6) xsize(10)
graph export "Output/figures/ceiling_distance_scatter3_all.pdf", replace
graph export "Output/figures/ceiling_distance_scatter3_all.eps", replace

restore

*****************************STEP 5: Area Graphs  ************

* The below is for GDP coverage
** USA
gen USAdist_noconnection_GDP=100
forvalues i=0/5{
	bys date: egen USAdist`i'_GDP2=sum(GDP) if dist_USA_bilateral==`i'
	bys date: egen USAdist`i'_GDP=min(USAdist`i'_GDP2)
	replace USAdist`i'_GDP=0 if USAdist`i'_GDP==.
	drop USAdist`i'_GDP2
	replace USAdist_noconnection_GDP=USAdist_noconnection_GDP-USAdist`i'_GDP
}
*

gen Dist_noconnection=100
gen USAdistcumsum0=USAdist0_GDP
forvalues i=1/5{
	local j=`i'-1
	gen USAdistcumsum`i'=USAdistcumsum`j'+USAdist`i'_GDP
}
*

twoway area Dist_noconnection USAdistcumsum5 USAdistcumsum3 USAdistcumsum2 USAdistcumsum1 USAdistcumsum0 date, legend(order(1 "" 2 "4+5th order" 3 "3rd order" 4 "2nd order" 5 "Direct Connection" 6 "USA") size(medlarge)) yscale(range(0 100)titlegap(1)) xtitle("Date",size(medium)) xlabel(,labsize(medium)) ytitle("Share of world GDP", size(medium)) ylabel(,labsize(medium)) aspect(.5) fcolor(white%0 eltblue midblue blue navy dknavy) lcolor(white eltblue midblue blue navy dknavy) legend(position(6)) legend(rows(2)) 
graph display, ysize(6) xsize(10) 
graph export "Output/figures/bilateral_USAcoverage_GDP.pdf", replace
graph export "Output/figures/bilateral_USAcoverage_GDP.eps", replace


** CHN
gen CHNdist_noconnection_GDP=100
forvalues i=0/5{
bys date: egen CHNdist`i'_GDP2=sum(GDP) if dist_CHN_bilateral==`i'
bys date: egen CHNdist`i'_GDP=min(CHNdist`i'_GDP2)
replace CHNdist`i'_GDP=0 if CHNdist`i'_GDP==.
drop CHNdist`i'_GDP2
replace CHNdist_noconnection_GDP=CHNdist_noconnection_GDP-CHNdist`i'_GDP
}
*

gen CHNdistcumsum0=CHNdist0_GDP
forvalues i=1/5{
local j=`i'-1
gen CHNdistcumsum`i'=CHNdistcumsum`j'+CHNdist`i'_GDP
}
*

twoway area Dist_noconnection CHNdistcumsum5 CHNdistcumsum3 CHNdistcumsum2 CHNdistcumsum1 CHNdistcumsum0 date, legend(order(1 "" 2 "4+5th order" 3 "3rd order" 4 "2nd order" 5 "Direct Connection" 6 "China") size(medlarge)) yscale(range(0 100)titlegap(1)) xtitle("Date",size(medium)) xlabel(,labsize(medium)) ytitle("Share of world GDP", size(medium)) ylabel(,labsize(medium)) aspect(.5) fcolor(white%0 eltblue midblue blue navy dknavy) lcolor(white eltblue midblue blue navy dknavy) legend(position(6)) legend(rows(2))
graph display, ysize(6) xsize(10) 
graph export "Output/figures/bilateral_CHNcoverage_GDP.pdf", replace
graph export "Output/figures/bilateral_CHNcoverage_GDP.eps", replace


** EUR
gen EAdist_noconnection_GDP=100
forvalues i=0/5{
bys date: egen EAdist`i'_GDP2=sum(GDP) if dist_EA_bilateral==`i'
bys date: egen EAdist`i'_GDP=min(EAdist`i'_GDP2)
replace EAdist`i'_GDP=0 if EAdist`i'_GDP==.
drop EAdist`i'_GDP2
replace EAdist_noconnection_GDP=EAdist_noconnection_GDP-EAdist`i'_GDP
}
*

gen EAdistcumsum0=EAdist0_GDP
forvalues i=1/5{
local j=`i'-1
gen EAdistcumsum`i'=EAdistcumsum`j'+EAdist`i'_GDP
}
*

twoway area Dist_noconnection EAdistcumsum5 EAdistcumsum3 EAdistcumsum2 EAdistcumsum1 EAdistcumsum0 date, legend(order(1 "" 2 "4+5th order" 3 "3rd order" 4 "2nd order" 5 "Direct Connection" 6 "Euro Area") size(medlarge)) yscale(range(0 100)titlegap(1)) xtitle("Date",size(medium)) xlabel(,labsize(medium)) ytitle("Share of world GDP", size(medium)) ylabel(,labsize(medium)) aspect(.5) fcolor(white%0 eltblue midblue blue navy dknavy) lcolor(white eltblue midblue blue navy dknavy) legend(position(6)) legend(rows(2))
graph display, ysize(6) xsize(10)
graph export "Output/figures/bilateral_EAcoverage_GDP.pdf", replace
graph export "Output/figures/bilateral_EAcoverage_GDP.eps", replace


*end of do-file
