*************************** Define Events **************************

/*
NB: This helper script defines 12 event indicators used in reserve/CIP event
studies. It is designed to run on the active dataset in memory.

Required in-memory inputs include:
    - Dconnect_us Dconnect_EA Dconnect_CHN
    - dist_USA_bilateral dist_EA_bilateral dist_CHN_bilateral
    - own_action_all

Main outputs:
    - improved_connect, improved_higher_connect, direct_connect, etc.
*/

*********************************************************************

*	STEP 1: Define US-Distance Events (Events 1-7)

*** EVENT 1: Countries improved connect
cap drop improved_connect
gen improved_connect=0
replace improved_connect=1 if Dconnect_us<0
replace improved_connect=0 if improved_connect==1 & L6.dist_USA_bilateral<=dist_USA_bilateral

*** EVENT 2: Countries that improve their higher order connects:
cap drop improved_higher_connect
gen improved_higher_connect=0
replace improved_higher_connect=1 if Dconnect_us<0 & dist_USA_bilateral!=1
replace improved_higher_connect=0 if improved_higher_connect==1 & L6.dist_USA_bilateral<=dist_USA_bilateral


*** EVENT 3: Countries that improve their higher order connect with own action
gen improved_higher_connect_own=0
*replace improved_higher_connect_own=1 if improved_higher_connect==1 & (own_action_bilat_s==1 | L.own_action_bilat_s==1)
replace improved_higher_connect_own=1 if improved_higher_connect==1 & (own_action_all==1 | L.own_action_all==1)
replace improved_higher_connect_own=0 if improved_higher_connect_own==1 & L6.dist_USA_bilateral<=dist_USA_bilateral


*** EVENT 4: Countries that improve their higher order connect without own action
gen improved_higher_connect_noown=0
replace improved_higher_connect_noown=1 if improved_higher_connect==1 & improved_higher_connect_own!=1
replace improved_higher_connect_noown=0 if improved_higher_connect_noown==1 & L6.dist_USA_bilateral<=dist_USA_bilateral
replace improved_higher_connect_noown=0 if improved_higher_connect_noown==1 & F.own_action_all==1 & country_code!="HKG"

*** EVENT 5: Countries get a direct connect
gen direct_connect=0
replace direct_connect=1 if Dconnect_us<0 & dist_USA_bilateral==1
replace direct_connect=0 if direct_connect==1 & L6.dist_USA_bilateral<=dist_USA_bilateral

*** EVENT 6: Direct connect lapsed
gen direct_connect_lapsed=0
replace direct_connect_lapsed=1 if Dconnect_us>0 & L.dist_USA_bilateral==1
replace direct_connect_lapsed=0 if direct_connect_lapsed==1 & L6.dist_USA_bilateral>=dist_USA_bilateral

*** EVENT 7: Countries that worsen their higher order connections:
cap drop worsen_higher_connect
gen worsen_higher_connect=0
replace worsen_higher_connect=1 if Dconnect_us>0 & L.dist_USA_bilateral!=1
replace worsen_higher_connect=0 if worsen_higher_connect==1 & L6.dist_USA_bilateral>=dist_USA_bilateral

*	STEP 2: Define EA/CHN Distance Events (Events 8-10)

*** EVENT 8: Countries that improve have improved connect with china or europe
gen improved_connect_EA=0
replace improved_connect_EA=1 if Dconnect_EA<0
replace improved_connect_EA=0 if improved_connect_EA==1 & L6.dist_EA_bilateral<=dist_EA_bilateral
gen improved_connect_CHN=0
replace improved_connect_CHN=1 if Dconnect_CHN<0
replace improved_connect_CHN=0 if improved_connect_CHN==1 & L6.dist_CHN_bilateral<=dist_CHN_bilateral

*** EVENT 9: Countries that improve have direct connect with china or europe
gen direct_connect_EA=0
replace direct_connect_EA=1 if Dconnect_EA<0 & dist_EA_bilateral==1
replace direct_connect_EA=0 if direct_connect_EA==1 & L6.dist_EA_bilateral<=dist_EA_bilateral
gen direct_connect_CHN=0
replace direct_connect_CHN=1 if Dconnect_CHN<0 & dist_CHN_bilateral==1
replace direct_connect_CHN=0 if direct_connect_CHN==1 & L6.dist_CHN_bilateral<=dist_CHN_bilateral

*** EVENT 10: Countries that improve their higher order connects with china or europe:
cap drop improved_higher_connect_EA
gen improved_higher_connect_EA=0
replace improved_higher_connect_EA=1 if Dconnect_EA<0 & dist_EA_bilateral!=1
replace improved_higher_connect_EA=0 if improved_higher_connect_EA==1 & L6.dist_EA_bilateral<=dist_EA_bilateral
cap drop improved_higher_connect_CHN
gen improved_higher_connect_CHN=0
replace improved_higher_connect_CHN=1 if Dconnect_EA<0 & dist_CHN_bilateral!=1
replace improved_higher_connect_CHN=0 if improved_higher_connect_CHN==1 & L6.dist_CHN_bilateral<=dist_CHN_bilateral


*	STEP 3: Define Own-Action Variants (Events 11-12)

*** EVENT 11: Countries that improve their higher order connect with china or europe with own action
gen improved_higher_connect_o_EA=0
replace improved_higher_connect_o_EA=1 if improved_higher_connect_EA==1 & (own_action_all==1 | L.own_action_all==1 )
replace improved_higher_connect_o_EA=0 if improved_higher_connect_o_EA==1 & L6.dist_EA_bilateral<=dist_EA_bilateral
gen improved_higher_connect_o_CHN=0
replace improved_higher_connect_o_CHN=1 if improved_higher_connect_CHN==1 & (own_action_all==1 | L.own_action_all==1)
replace improved_higher_connect_o_CHN=0 if improved_higher_connect_o_CHN==1 & L6.dist_CHN_bilateral<=dist_CHN_bilateral


*** EVENT 12: Countries that improve their higher order connect without own action
gen improved_higher_connect_no_EA=0
replace improved_higher_connect_no_EA=1 if improved_higher_connect_EA==1 & improved_higher_connect_o_EA!=1
replace improved_higher_connect_no_EA=0 if improved_higher_connect_no_EA==1 & L6.dist_EA_bilateral<=dist_EA_bilateral
replace improved_higher_connect_no_EA=0 if improved_higher_connect_no_EA==1 & F.own_action_all==1 & country_code!="HKG"
gen improved_higher_connect_noCHN=0
replace improved_higher_connect_noCHN=1 if improved_higher_connect_CHN==1 & improved_higher_connect_o_CHN!=1
replace improved_higher_connect_noCHN=0 if improved_higher_connect_noCHN==1 & L6.dist_CHN_bilateral<=dist_CHN_bilateral
replace improved_higher_connect_noCHN=0 if improved_higher_connect_noCHN==1 & F.own_action_all==1 & country_code!="HKG"

*end of do-file
